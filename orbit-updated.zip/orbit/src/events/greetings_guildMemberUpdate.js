const { Events } = require('discord.js');
const greetings = require('../functions/greetRuntime');

module.exports = {
    name: Events.GuildMemberUpdate,
    async execute(oldMember, newMember) {
        await greetings.onMemberUpdate(oldMember, newMember);
    },
};
