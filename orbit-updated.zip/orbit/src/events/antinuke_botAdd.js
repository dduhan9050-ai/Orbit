const { AuditLogEvent, EmbedBuilder } = require('discord.js');
const antinuke = require('../functions/antinukeManager');
const permit = require('../functions/permitManager');

module.exports = {
    name: 'guildMemberAdd',
    async execute(member, client) {
        try {
            if (!member.guild) return;
            if (!member.user?.bot) return; // only care about bot adds here

            const guildId = member.guild.id;
            const cfg = antinuke.getConfig(guildId);
            if (!cfg || !cfg.enabled) return;
            if (cfg.filters && cfg.filters.botAdd === false) return;

            const logs = await member.guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.BotAdd }).catch(() => null);
            const entry = logs?.entries?.first();
            const executor = entry?.executor?.id;
            if (!executor) return;
            if (Date.now() - entry.createdTimestamp > 10000) return; // stale audit entry
            if (executor === client.user.id) return;
            if (executor === member.guild.ownerId) return;
            if (cfg.whitelist && cfg.whitelist.includes(executor)) return;
            if (permit.isExtraOwner(guildId, executor) || permit.isUserInList(guildId, 'trusted', executor)) return;

            const heat = antinuke.addHeat(guildId, executor, cfg.heatPerAction || 20);

            if (cfg.loggingChannel) {
                const ch = member.guild.channels.cache.get(cfg.loggingChannel);
                if (ch) ch.send({ embeds: [new EmbedBuilder().setTitle('Antinuke: Bot Added').setDescription(`Bot **${member.user.tag}** added by <@${executor}> (${heat} heat)`).setColor('#ff5555')] }).catch(() => { });
            }

            if (cfg.panicMode && !cfg.zplus && heat >= (cfg.thresholdHeat || 100)) {
                antinuke.triggerPanic(guildId);
                if (cfg.loggingChannel) {
                    const ch = member.guild.channels.cache.get(cfg.loggingChannel);
                    if (ch) ch.send({ embeds: [new EmbedBuilder().setTitle('Panic Mode Triggered').setDescription('Server heat exceeded threshold. Z+ Config loaded automatically.').setColor('#ff0000')] }).catch(() => { });
                }
            }

            if (heat >= (cfg.thresholdHeat || 100)) {
                const actor = await member.guild.members.fetch(executor).catch(() => null);
                if (actor) {
                    if (actor.bannable) {
                        await member.guild.members.ban(executor, { reason: 'Antinuke: exceeded heat threshold (bot add)' }).catch(() => { });
                    } else {
                        await actor.kick('Antinuke: exceeded heat threshold (bot add)').catch(() => { });
                    }
                }
                if (cfg.loggingChannel) {
                    const ch = member.guild.channels.cache.get(cfg.loggingChannel);
                    if (ch) ch.send({ embeds: [new EmbedBuilder().setTitle('Antinuke Action').setDescription(`<@${executor}> was punished for exceeding antinuke threshold (bot add)`).setColor('#ff5555')] }).catch(() => { });
                }
            }
        } catch (e) {
            console.error('Antinuke botAdd handler error:', e);
        }
    }
};
