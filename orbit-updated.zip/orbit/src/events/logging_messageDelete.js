const { EmbedBuilder, Events, AuditLogEvent } = require('discord.js');
const fs = require('fs');
const path = require('path');
const loggingManager = require('../functions/loggingManager');
const snipeStore = require('../functions/snipeStore');

module.exports = {
    name: Events.MessageDelete,
    async execute(message) {
        if (!message.guild || message.author?.bot) return;

        try { snipeStore.set(message); } catch (e) { /* ignore */ }

        try {
            const dataPath = path.join(__dirname, '../data/logging.json');
            if (!fs.existsSync(dataPath)) return;

            const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            const guildConfig = data[message.guild.id];

            if (!guildConfig || !guildConfig.enabled) return;
            if (loggingManager.isMessageIgnored({ ignores: guildConfig.ignores || [] }, message)) return;

            const logChannel = guildConfig.channels?.message || guildConfig.channels?.moderation;
            if (!logChannel) return;

            const channel = message.guild.channels.cache.get(logChannel);
            if (!channel) return;

            const embed = new EmbedBuilder()
                .setTitle('🗑️ Message Deleted')
                .setColor('#ff0000')
                .addFields(
                    { name: 'Author', value: message.author ? `${message.author.tag} (${message.author.id})` : 'Unknown', inline: true },
                    { name: 'Channel', value: `<#${message.channel.id}> (${message.channel.name})`, inline: true },
                    { name: 'Content', value: message.content ? (message.content.length > 1024 ? message.content.substring(0, 1021) + '...' : message.content) : '*No content*' }
                )
                .setTimestamp();

            if (message.attachments.size > 0) {
                embed.addFields({ name: 'Attachments', value: message.attachments.map(a => a.url).join('\n') });
            }

            await channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Logging error (messageDelete):', error);
        }
    }
};
