const { EmbedBuilder, ChannelType, PermissionFlagsBits } = require('discord.js');
const automodEnforcer = require('../functions/automodEnforcer');
const permit = require('../functions/permitManager');
const afk = require('../functions/afkManager');
const automations = require('../functions/automationRuntime');


module.exports = {
    name: 'messageCreate',
    async execute(message, client) {
        if (!message.guild) return;

        // --- AUTOMATIONS: autodelete timers + sticky messages apply to every message (bots included) ---
        try {
            automations.onAnyMessage(message, client);
        } catch (e) {
            console.error('Automation error:', e);
        }

        if (message.author.bot) return;

        // --- MEDIA-ONLY channels: remove text-only messages ---
        try {
            if (await automations.enforceMedia(message)) return;
        } catch (e) {
            console.error('Media channel error:', e);
        }

        // --- AFK: Check if user is AFK and remove status ---
        const userAfk = afk.getAFK(message.author.id);
        if (userAfk) {
            afk.removeAFK(message.author.id);
            const duration = Date.now() - userAfk.timestamp;
            const minutes = Math.floor(duration / 60000);
            const timeStr = minutes > 0 ? `${minutes}m` : 'just now';
            await message.reply(`Welcome back! Your AFK status has been removed (was AFK for ${timeStr}).`).catch(() => {});
        }

        // --- AFK: Check mentions for AFK users ---
        for (const user of message.mentions.users.values()) {
            if (user.bot) continue;
            const mentionedAfk = afk.getAFK(user.id);
            if (mentionedAfk) {
                const duration = Date.now() - mentionedAfk.timestamp;
                const minutes = Math.floor(duration / 60000);
                const timeStr = minutes > 0 ? `${minutes}m ago` : 'just now';
                await message.reply(`${user.username} is currently AFK: ${mentionedAfk.reason} (${timeStr})`).catch(() => {});
                break; // Only reply once per message
            }
        }


        // --- AUTOMOD: blacklist + filters (links, invites, caps, spam, ...) ---
        try {
            if (await automodEnforcer.handleMessage(message)) return;
        } catch (e) {
            console.error('Automod error:', e);
        }

        // Get guild-specific prefixes or use default
        const fs = require('fs');
        const path = require('path');
        const prefixPath = path.join(__dirname, '../data/prefix.json');
        const defaultPrefix = process.env.PREFIX || '!';
        
        let guildPrefixes = [defaultPrefix];
        try {
            if (fs.existsSync(prefixPath)) {
                const prefixData = JSON.parse(fs.readFileSync(prefixPath, 'utf8'));
                if (prefixData[message.guild.id] && prefixData[message.guild.id].prefixes) {
                    guildPrefixes = prefixData[message.guild.id].prefixes;
                }
            }
        } catch (e) {
            // Use default prefix if there's an error
        }

        // Check if message starts with any of the guild's prefixes
        // Plain chat (not a bot command): autoreact + autoresponder
        const runPlain = async () => {
            try { await automations.onPlainMessage(message); } catch (e) { console.error('Autoresponder error:', e); }
        };

        const usedPrefix = guildPrefixes.find(prefix => message.content.startsWith(prefix));
        if (!usedPrefix) return runPlain();

        const args = message.content.slice(usedPrefix.length).trim().split(/ +/);
        const commandName = args.shift().toLowerCase();

        if (!commandName) return runPlain();

        const command = client.commands.get(commandName);
        if (!command) return runPlain();

        const gid = message.guild.id;
        const uid = message.author.id;

        // 1. Bypass check
        const isServerOwner = uid === message.guild.ownerId || permit.isExtraOwner(gid, uid);
        if (!isServerOwner && !permit.isUserInList(gid, 'ignore_bypass', uid)) {
            // 2. User ignore
            if (permit.isUserInList(gid, 'ignore_user', uid)) return;
            // 3. Channel ignore
            if (permit.isUserInList(gid, 'ignore_channel', message.channel.id)) return;
            // 4. Role ignore
            const ignoredRoles = permit.getEntries(gid, 'ignore_role');
            if (ignoredRoles.some(roleId => message.member.roles.cache.has(roleId))) return;
            // 5. Command ignore
            if (permit.isUserInList(gid, 'ignore_command', commandName)) return;
        }

        // Debug: log antinuke prefix invocations to help troubleshoot parsing
        if (commandName === 'antinuke') {
            try {
                console.log('DEBUG: antinuke invoked via prefix. args=', args);
            } catch (e) {
                console.error('DEBUG: failed to log antinuke args', e);
            }
        }

        // New Logic: If command has executeMessage, use it for prefix commands
        if (typeof command.executeMessage === 'function') {
            try {
                return await command.executeMessage(message, args);
            } catch (error) {
                console.error(`Error in executeMessage for ${commandName}:`, error);
                return message.reply({ content: 'There was an error while executing the message command!' });
            }
        }

        // If command has no executeMessage, try to use the slash command handler (fallback)
        if (!command.data) {
            return message.reply('This command is not available for prefix usage.');
        }

        // --- Helper to Shim Interaction (Fallback) ---
        try {
            const commandData = command.data.toJSON();
            const fakeInteraction = {
                user: message.author,
                member: message.member,
                guild: message.guild,
                channel: message.channel,
                client: client,
                createdTimestamp: message.createdTimestamp,

                // Helper methods
                reply: async (options) => {
                    const payload = typeof options === 'string' ? { content: options } : options;
                    // Handle ephemeral by sending a reply and deleting it after a delay (or DMing)
                    // But in message context, ephemeral doesn't technically exist. 
                    // We'll just reply normally.
                    return await message.reply(payload);
                },
                deferReply: async () => {
                    return await message.channel.sendTyping();
                },
                editReply: async (options) => {
                    // Since we don't have a real interaction hook, we can't edit the "Thinking" state easily 
                    // without tracking the sent message. using a simple send for now.
                    const payload = typeof options === 'string' ? { content: options } : options;
                    return await message.channel.send(payload);
                },
                followUp: async (options) => {
                    const payload = typeof options === 'string' ? { content: options } : options;
                    return await message.channel.send(payload);
                },

                // Options Parser (The Hard Part)
                options: {
                    getSubcommandGroup: (required = false) => {
                        // Check if command has groups
                        const groups = commandData.options?.filter(o => o.type === 2); // 2 = SubcommandGroup
                        if (groups && groups.length > 0) {
                            if (groups.some(g => g.name === args[0])) return args[0];
                        }
                        if (required) throw new Error('Subcommand group required but not found');
                        return null;
                    },
                    getSubcommand: (required = true) => {
                        // Logic depending on if there is a group
                        const groups = commandData.options?.filter(o => o.type === 2);
                        const subcommands = commandData.options?.filter(o => o.type === 1); // 1 = Subcommand

                        // Case 1: Group -> Subcommand
                        if (groups && groups.length > 0 && groups.some(g => g.name === args[0])) {
                            return args[1]; // Group is at index 0, subcommand at index 1
                        }

                        // Case 2: Just Subcommand (no group)
                        // If there are groups defined but args[0] matches a direct subcommand (rare but possible in mixed structure)
                        // OR if there are no groups defined
                        if (subcommands && subcommands.some(s => s.name === args[0])) {
                            return args[0];
                        }

                        if (required) {
                            // If required is true (default), we only return null if we really can't find it.
                            // But native behavior throws error. 
                            // However, for our mainrole check `getSubcommand(false)`, we want null.
                            // Wait, logic above returns args[0] or args[1] or undefined (implicit).
                            // If we fell through, it means not found.
                            return null;
                        }
                        return null;
                    },
                    getString: (name) => findOption(name, 'string'),
                    getUser: (name) => findOption(name, 'user'),
                    getMember: (name) => findOption(name, 'user'), // Same as user for message context usually
                    getChannel: (name) => findOption(name, 'channel'),
                    getRole: (name) => findOption(name, 'role'),
                    getInteger: (name) => findOption(name, 'integer'),
                    getNumber: (name) => findOption(name, 'number'),
                    getBoolean: (name) => findOption(name, 'boolean'),
                    getAttachment: (name) => findOption(name, 'attachment'),
                }
            };

            // Argument Mapping Helper
            function findOption(optName, type) {
                // 1. Determine structure (Group? Subcommand? Base?)
                let optionsList = commandData.options || [];
                let currentArgIndex = 0;

                const groupName = fakeInteraction.options.getSubcommandGroup(false);
                const subName = fakeInteraction.options.getSubcommand(false);

                if (groupName) {
                    const group = optionsList.find(o => o.name === groupName);
                    optionsList = group.options || [];
                    currentArgIndex++; // consume group arg
                }

                if (subName) {
                    const sub = optionsList.find(o => o.name === subName);
                    // Standard subcommand structure has options inside
                    optionsList = sub.options || [];
                    currentArgIndex++; // consume sub arg
                }

                // 2. Find the index of the requested option in the definition
                // We assume positional arguments match the order of defined options (required ones first ideally)
                // Filter out non-params? No, builders put parameters in order.
                const paramIndex = optionsList.findIndex(o => o.name === optName);

                if (paramIndex === -1) return null; // Option not found in definition

                const targetArgIndex = currentArgIndex + paramIndex;
                const rawArg = args[targetArgIndex];

                if (!rawArg) return null;

                // 3. Cast/Fetch type
                if (type === 'user') {
                    const id = rawArg.replace(/[<@!>]/g, '');
                    return message.guild.members.cache.get(id)?.user || null; // Return User object
                }
                if (type === 'channel') {
                    const id = rawArg.replace(/[<@#>]/g, '');
                    return message.guild.channels.cache.get(id) || null;
                }
                if (type === 'role') {
                    const id = rawArg.replace(/[<@&>]/g, '');
                    return message.guild.roles.cache.get(id) || null;
                }
                if (type === 'integer') {
                    return parseInt(rawArg);
                }
                if (type === 'number') {
                    return parseFloat(rawArg);
                }
                if (type === 'boolean') {
                    return rawArg === 'true' || rawArg === 'yes' || rawArg === 'on';
                }

                // string (or rest)
                return rawArg;
            }

            // Execute
            await command.execute(fakeInteraction);

        } catch (error) {
            console.error(error);
            await message.reply({ content: 'There was an error while executing this command!' });
        }
    }
};
