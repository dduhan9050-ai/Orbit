const { EmbedBuilder, Events, AuditLogEvent, ChannelType } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: Events.ChannelCreate,
    async execute(channel) {
        if (!channel.guild) return;

        try {
            const dataPath = path.join(__dirname, '../data/logging.json');
            if (!fs.existsSync(dataPath)) return;

            const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            const guildConfig = data[channel.guild.id];

            if (!guildConfig || !guildConfig.enabled) return;

            const logChannel = guildConfig.channels?.server || guildConfig.channels?.moderation;
            if (!logChannel) return;

            const logCh = channel.guild.channels.cache.get(logChannel);
            if (!logCh) return;

            let executor = null;

            try {
                const auditLogs = await channel.guild.fetchAuditLogs({
                    type: AuditLogEvent.ChannelCreate,
                    limit: 1
                });
                const createLog = auditLogs.entries.first();
                if (createLog && createLog.target.id === channel.id) {
                    executor = createLog.executor;
                }
            } catch (e) {}

            const channelTypes = {
                [ChannelType.GuildText]: 'Text',
                [ChannelType.GuildVoice]: 'Voice',
                [ChannelType.GuildCategory]: 'Category',
                [ChannelType.GuildAnnouncement]: 'Announcement',
                [ChannelType.GuildStageVoice]: 'Stage',
                [ChannelType.GuildForum]: 'Forum'
            };

            const embed = new EmbedBuilder()
                .setTitle('📝 Channel Created')
                .setColor('#00ff00')
                .addFields(
                    { name: 'Channel', value: `${channel} (${channel.name})`, inline: true },
                    { name: 'Type', value: channelTypes[channel.type] || 'Unknown', inline: true },
                    { name: 'ID', value: channel.id, inline: true },
                    { name: 'Created By', value: executor ? `${executor.tag}` : 'Unknown' }
                )
                .setTimestamp();

            await logCh.send({ embeds: [embed] });
        } catch (error) {
            console.error('Logging error (channelCreate):', error);
        }
    }
};
