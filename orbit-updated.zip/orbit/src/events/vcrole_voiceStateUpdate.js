const { Events } = require('discord.js');
const vcRoles = require('../functions/vcRoleManager');

/**
 * `vcrole set #voice @role`: members get the role while they sit in that voice channel
 * and lose it when they leave or switch away.
 */
module.exports = {
    name: Events.VoiceStateUpdate,
    async execute(oldState, newState) {
        const guild = newState.guild;
        const member = newState.member || oldState.member;
        if (!guild || !member || member.user.bot) return;
        if (oldState.channelId === newState.channelId) return;

        const map = vcRoles.get(guild.id);
        const oldRoleId = oldState.channelId ? map[oldState.channelId] : null;
        const newRoleId = newState.channelId ? map[newState.channelId] : null;
        if (!oldRoleId && !newRoleId) return;

        const usable = (id) => {
            const role = id && guild.roles.cache.get(id);
            return role && !role.managed && guild.members.me.roles.highest.comparePositionTo(role) > 0 ? role : null;
        };

        try {
            if (oldRoleId && oldRoleId !== newRoleId) {
                const role = usable(oldRoleId);
                if (role && member.roles.cache.has(role.id)) await member.roles.remove(role, 'VC role: left voice channel');
            }
            if (newRoleId) {
                const role = usable(newRoleId);
                if (role && !member.roles.cache.has(role.id)) await member.roles.add(role, 'VC role: joined voice channel');
            }
        } catch (error) {
            console.error('VC role error:', error.message);
        }
    }
};
