const { Events } = require('discord.js');
const tempRoles = require('../functions/tempRoleManager');

const giveaways = require('../functions/giveawayManager');

module.exports = {
    name: Events.ClientReady,
    once: true,
    async execute(client) {
        console.log(`Ready! Logged in as ${client.user.tag}`);
        
        // Fetch all members for cache
        try {
            for (const guild of client.guilds.cache.values()) {
                await guild.members.fetch();
            }
        } catch (error) {
            console.error('Error fetching members:', error);
        }
        
        // Check giveaways every 10 seconds
        setInterval(() => {
            giveaways.checkDue(client).catch(e => console.error('Giveaway check failed:', e));
        }, 10000);

        // Remove expired temporary roles (role temp) every 30 seconds
        tempRoles.check(client).catch(() => {});
        setInterval(() => {
            tempRoles.check(client).catch(() => {});
        }, 30000);
    },
};
