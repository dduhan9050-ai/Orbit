const { Events } = require('discord.js');
const greetings = require('../functions/greetRuntime');

module.exports = {
    name: Events.GuildMemberRemove,
    async execute(member) {
        await greetings.onMemberRemove(member);
    },
};
