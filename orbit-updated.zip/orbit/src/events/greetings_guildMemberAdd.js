const { Events } = require('discord.js');
const greetings = require('../functions/greetRuntime');

module.exports = {
    name: Events.GuildMemberAdd,
    async execute(member) {
        await greetings.onMemberAdd(member);
    },
};
