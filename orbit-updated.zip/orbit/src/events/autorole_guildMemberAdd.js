const { Events } = require('discord.js');
const automations = require('../functions/automationRuntime');

module.exports = {
    name: Events.GuildMemberAdd,
    async execute(member) {
        await automations.onMemberAdd(member);
    },
};
