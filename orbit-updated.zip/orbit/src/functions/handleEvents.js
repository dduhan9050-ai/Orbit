module.exports = (client) => {
    client.handleEvents = async (eventFiles, path) => {
        // Several event files can listen to the same Discord event (e.g. logging + antinuke + autorole
        // all on guildMemberAdd). Clear each event's listeners ONCE, then register every file.
        const cleared = new Set();
        for (const file of eventFiles) {
            const event = require(`../events/${file}`);
            if (!cleared.has(event.name)) {
                client.removeAllListeners(event.name);
                cleared.add(event.name);
            }
            const run = async (...args) => {
                try {
                    await event.execute(...args, client);
                } catch (error) {
                    console.error(`Error in event ${event.name} (${file}):`, error);
                }
            };
            if (event.once) {
                client.once(event.name, run);
            } else {
                client.on(event.name, run);
            }
        }
    };
};
