const fs = require('fs');
const path = require('path');

const DATA_PATH = path.join(__dirname, '..', 'data', 'logging.json');

/** Log categories the event listeners understand. */
const LOG_TYPES = ['message', 'member', 'voice', 'server', 'moderation'];

/**
 * Ignore list is a flat array of strings so the older data format keeps working:
 *   "<id>"         channel / user / role (snowflakes never clash)
 *   "voice_<id>"   voice channel whose join/leave/mute activity is not logged
 *   "embed_<id>"   channel whose embed messages are not logged
 */

function readAll() {
    try {
        if (!fs.existsSync(DATA_PATH)) return {};
        return JSON.parse(fs.readFileSync(DATA_PATH, 'utf8')) || {};
    } catch (e) {
        return {};
    }
}

function writeAll(data) {
    fs.mkdirSync(path.dirname(DATA_PATH), { recursive: true });
    fs.writeFileSync(DATA_PATH, JSON.stringify(data, null, 2), 'utf8');
}

const blank = () => ({ enabled: false, channels: {}, ignores: [] });

/** Config for a guild (never null; not persisted until save() is called). */
function get(guildId) {
    const cfg = readAll()[guildId] || blank();
    if (!cfg.channels) cfg.channels = {};
    if (!Array.isArray(cfg.ignores)) cfg.ignores = [];
    return cfg;
}

function save(guildId, cfg) {
    const all = readAll();
    all[guildId] = cfg;
    writeAll(all);
}

/** Convenience for event listeners: config only if logging is enabled. */
function getEnabled(guildId) {
    const cfg = get(guildId);
    return cfg.enabled ? cfg : null;
}

/** Resolve the channel an event should post to: first configured type that still exists. */
function logChannel(guild, cfg, ...types) {
    for (const t of types) {
        const id = cfg.channels[t];
        const ch = id && guild.channels.cache.get(id);
        if (ch && ch.isTextBased && ch.isTextBased()) return ch;
    }
    return null;
}

/**
 * Should a message-type event be skipped?
 * Skips ignored channels, ignored users, members holding an ignored role, and embed-only
 * messages in channels set with `logging ignore embed`.
 */
function isMessageIgnored(cfg, message) {
    const ig = cfg.ignores;
    if (!ig.length) return false;
    if (ig.includes(message.channelId || (message.channel && message.channel.id))) return true;
    if (message.author && ig.includes(message.author.id)) return true;
    const roles = message.member && message.member.roles && message.member.roles.cache;
    if (roles && roles.some(r => ig.includes(r.id))) return true;
    const chId = message.channelId || (message.channel && message.channel.id);
    if (ig.includes(`embed_${chId}`) && message.embeds && message.embeds.length) return true;
    return false;
}

/** Should a voice-state event be skipped? */
function isVoiceIgnored(cfg, oldState, newState) {
    const ig = cfg.ignores;
    if (!ig.length) return false;
    for (const id of [oldState.channelId, newState.channelId]) {
        if (id && (ig.includes(`voice_${id}`) || ig.includes(id))) return true;
    }
    const member = newState.member || oldState.member;
    if (member) {
        if (ig.includes(member.id)) return true;
        if (member.roles && member.roles.cache.some(r => ig.includes(r.id))) return true;
    }
    return false;
}

module.exports = { LOG_TYPES, get, save, getEnabled, logChannel, isMessageIgnored, isVoiceIgnored };
