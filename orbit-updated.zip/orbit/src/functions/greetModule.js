// Shared command logic for the four greeting modules (slash + prefix run the same code):
//   greet (welcomer) · joindm · leavemsg · boostgreet
// Usage in a command file:  module.exports = { data: ..., ...greetModule.create('greet') };
const { EmbedBuilder, MessageFlags } = require('discord.js');
const store = require('./automationStore');
const common = require('./automationCommon');
const runtime = require('./greetRuntime');

const KINDS = {
    greet: { title: 'Welcomer', noun: 'welcomer message', hasChannel: true, vars: '{user} {username} {server} {membercount}' },
    joindm: { title: 'Join DM', noun: 'join DM', hasChannel: false, vars: '{user} {username} {server} {membercount}' },
    leavemsg: { title: 'Leave Message', noun: 'leave message', hasChannel: true, vars: '{username} {server} {membercount}' },
    boostgreet: { title: 'Boost Greet', noun: 'boost greeting', hasChannel: true, vars: '{user} {username} {server} {boostcount} {boosttier}' },
};
const STYLES = ['text', 'embed'];

function helpText(kind, k) {
    const set = kind === 'greet' ? 'create' : 'set';
    let t = `» **${kind} ${set} <message>**\n› Set the ${k.noun}.\nVariables: ${k.vars}\n\n`;
    if (k.hasChannel) {
        t += `» **${kind} channel set <#channel>**\n› Where to send it${kind === 'greet' ? '' : ' (default: system channel)'}.\n\n`;
        t += `» **${kind} channel reset**\n› Clear the channel.\n\n`;
    }
    t += `» **${kind} ${kind === 'greet' ? 'config' : 'show'}**\n› Show the configuration.\n\n`;
    t += `» **${kind} enable/disable**\n› Turn the module on or off.\n\n`;
    t += `» **${kind} test**\n› Send a test ${k.noun} (uses you as the member).\n\n`;
    if (kind === 'greet') {
        t += `» **greet style <text/embed>**\n› Plain text or embed.\n\n`;
        t += `» **greet autodelete <time>**\n› Delete the message after e.g. \`10s\`, \`1m\` (\`off\` to disable).\n\n`;
        t += `» **greet card [on/off]**\n› Big avatar image in embed style.\n\n`;
        t += `» **greet delete**\n› Wipe the configuration.`;
    } else {
        t += `» **${kind} reset**\n› Wipe the configuration.`;
    }
    return t;
}

function create(kind) {
    const k = KINDS[kind];
    const setSub = kind === 'greet' ? 'create' : 'set';

    function configEmbed(cfg) {
        const e = new EmbedBuilder()
            .setTitle(`${k.title} Configuration`)
            .setColor('#2b2d31')
            .addFields({ name: 'Status', value: cfg.enabled ? '✅ Enabled' : '❌ Disabled', inline: true });
        if (k.hasChannel) e.addFields({ name: 'Channel', value: cfg.channel ? `<#${cfg.channel}>` : 'Not set', inline: true });
        if (kind === 'greet') {
            e.addFields(
                { name: 'Style', value: cfg.style === 'embed' ? 'embed' : 'text', inline: true },
                { name: 'Autodelete', value: cfg.autodelete ? String(cfg.autodelete) : 'Off', inline: true },
                { name: 'Card', value: cfg.card ? 'On' : 'Off', inline: true });
        }
        e.addFields({ name: 'Message', value: common.truncate(cfg.message || `*Default:* ${runtime.DEFAULT_MESSAGE[kind]}`, 1024) });
        return e;
    }

    async function run(ctx, group, sub, o) {
        const guildId = ctx.guild.id;
        const cfg = store.get(kind, guildId);
        const save = () => store.save(kind);

        if (group === 'channel') {
            if (!k.hasChannel) return ctx.fail('Unknown subcommand.');
            if (sub === 'set') {
                if (!o.channel || !common.isTextChannel(o.channel)) return ctx.fail('Please provide a text channel.');
                cfg.channel = o.channel.id;
                save();
                return ctx.ok(`${k.title} channel set to ${o.channel}.`);
            }
            if (sub === 'reset') { cfg.channel = null; save(); return ctx.ok(`${k.title} channel has been reset.`); }
            return ctx.fail('Unknown subcommand.');
        }

        switch (sub) {
            case 'enable':
                cfg.enabled = true; save();
                return ctx.ok(`${k.title} module has been enabled.${k.hasChannel && !cfg.channel && !ctx.guild.systemChannel ? `\n⚠️ Set a channel: \`${kind} channel set #channel\`` : ''}`);
            case 'disable':
                cfg.enabled = false; save();
                return ctx.ok(`${k.title} module has been disabled.`);
            case 'config':
            case 'show':
                return ctx.send({ embeds: [configEmbed(cfg)] });
            case 'reset':
            case 'delete':
                store.reset(kind, guildId); save();
                return ctx.ok(`${k.title} configuration has been reset.`);
            case 'create':
            case 'set': {
                const msg = (o.message || '').trim();
                if (!msg) return ctx.fail(`Please provide a message. Usage: \`${kind} ${setSub} <message>\`\nVariables: ${k.vars}`);
                if (msg.length > 1800) return ctx.fail('The message can be at most 1800 characters.');
                cfg.message = msg; save();
                return ctx.ok(`${k.title} message saved. Try it with \`${kind} test\`.`);
            }
            case 'style': {
                const style = String(o.style || '').toLowerCase().replace('default', 'text');
                if (!STYLES.includes(style)) return ctx.fail(`Style must be one of: ${STYLES.map(s => `\`${s}\``).join(', ')}.`);
                cfg.style = style; save();
                return ctx.ok(`${k.title} style set to **${style}**.`);
            }
            case 'autodelete': {
                const raw = String(o.time || '').trim().toLowerCase();
                if (['off', 'none', 'disable', '0'].includes(raw)) { cfg.autodelete = null; save(); return ctx.ok('Autodelete turned off.'); }
                const ms = common.parseDuration(raw);
                if (!ms) return ctx.fail('Invalid time. Examples: `10s`, `1m`, `1h` (or `off`).');
                if (ms < 3000 || ms > 24 * 3600 * 1000) return ctx.fail('Time must be between 3 seconds and 24 hours.');
                cfg.autodelete = common.formatDuration(ms).replace(/ /g, ''); save();
                return ctx.ok(`Welcome messages will be deleted after **${common.formatDuration(ms)}**.`);
            }
            case 'card': {
                cfg.card = o.flag === null || o.flag === undefined ? !cfg.card : o.flag; save();
                return ctx.ok(`Card is now **${cfg.card ? 'on' : 'off'}**${cfg.style !== 'embed' && cfg.card ? ' (only shows with `style embed`)' : ''}.`);
            }
            case 'test': {
                const res = await runtime.send(kind, ctx.guild, ctx.user);
                if (!res.ok) return ctx.fail(res.reason);
                return ctx.ok(kind === 'joindm' ? 'Test DM sent to you.' : `Test message sent${cfg.channel ? ` to <#${cfg.channel}>` : ''}.`);
            }
            default:
                return ctx.fail('Unknown subcommand.');
        }
    }

    const SUBS = ['enable', 'disable', 'test', 'reset', 'show', setSub, ...(k.hasChannel ? ['channel'] : []),
        ...(kind === 'greet' ? ['config', 'delete', 'style', 'autodelete', 'card'] : [])];

    return {
        async execute(interaction) {
            if (!interaction.member.permissions.has('ManageGuild')) {
                return interaction.reply({ content: '❌ No access', flags: MessageFlags.Ephemeral });
            }
            const sub = interaction.options.getSubcommand();
            const group = interaction.options.getSubcommandGroup(false);
            await run(common.fromInteraction(interaction), group, sub, {
                message: interaction.options.getString('message'),
                channel: interaction.options.getChannel('channel'),
                style: interaction.options.getString('style'),
                time: interaction.options.getString('time'),
                flag: interaction.options.getBoolean('enabled'),
            });
        },

        async executeMessage(message, args) {
            const first = args[0] ? args[0].toLowerCase() : 'help';
            if (first === 'help' || !SUBS.includes(first)) {
                return message.reply({ embeds: [common.helpEmbed(helpText(kind, k), message)] });
            }
            const ctx = common.fromMessage(message);
            if (!message.member.permissions.has('ManageGuild')) return ctx.fail('No access');

            if (first === 'channel') {
                const sub = args[1] ? args[1].toLowerCase() : null;
                if (!['set', 'reset'].includes(sub)) return ctx.fail(`Usage: \`${kind} channel set #channel\` or \`${kind} channel reset\``);
                const channel = sub === 'set' ? common.resolveChannel(message.guild, args[2]) : null;
                if (sub === 'set' && !channel) return ctx.fail(`Please mention a channel. Usage: \`${kind} channel set #channel\``);
                return run(ctx, 'channel', sub, { channel });
            }

            const rest = args.slice(1);
            const flagWord = (rest[0] || '').toLowerCase();
            return run(ctx, null, first, {
                message: rest.join(' '),
                style: rest[0],
                time: rest[0],
                flag: ['on', 'true', 'yes', 'enable'].includes(flagWord) ? true : ['off', 'false', 'no', 'disable'].includes(flagWord) ? false : null,
            });
        },
    };
}

module.exports = { create };
