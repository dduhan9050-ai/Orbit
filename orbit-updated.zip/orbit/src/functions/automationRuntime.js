// Runtime behaviour for the automation modules. The commands only edit config; this file is what
// actually acts on messages / new members.
const store = require('./automationStore');

// ---------- helpers ----------
const WORD = '[\\p{L}\\p{N}_]';
const regexCache = new Map();

/** Case-insensitive whole-word/phrase match (boundaries only applied on word-character edges). */
function matches(content, trigger) {
    const t = String(trigger || '').trim();
    if (!t) return false;
    let re = regexCache.get(t);
    if (!re) {
        const esc = t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const pre = new RegExp(`^${WORD}`, 'u').test(t) ? `(?<!${WORD})` : '';
        const post = new RegExp(`${WORD}$`, 'u').test(t) ? `(?!${WORD})` : '';
        re = new RegExp(`${pre}${esc}${post}`, 'iu');
        regexCache.set(t, re);
    }
    return re.test(content);
}

function toMs(value) {
    const { parseDuration } = require('./automationCommon');
    return typeof value === 'number' ? value : parseDuration(value);
}

// ---------- autodelete ----------
function handleAutodelete(message) {
    const cfg = store.peek('autodelete', message.guild.id);
    if (!cfg || !cfg.channels) return;
    const ms = toMs(cfg.channels[message.channelId]);
    if (!ms) return;

    const whitelist = cfg.whitelist || [];
    if (whitelist.includes(message.author.id)) return;
    if (message.member && message.member.roles.cache.some(r => whitelist.includes(r.id))) return;

    // never eat the sticky message, it would just be re-posted in a loop
    const sticky = store.peek('sticky', message.guild.id);
    if (sticky && sticky[message.channelId] && sticky[message.channelId].lastMessageId === message.id) return;

    setTimeout(() => {
        if (message.pinned) return;
        message.delete().catch(() => {});
    }, ms);
}

// ---------- media-only channels ----------
const MEDIA_URL = /https?:\/\/\S+\.(?:png|jpe?g|gif|gifv|webp|bmp|mp4|mov|webm|mkv|avi|mp3|wav|ogg)(?:\?\S*)?/i;
const MEDIA_HOST = /https?:\/\/(?:[\w-]+\.)?(?:tenor\.com|giphy\.com|imgur\.com|gfycat\.com|streamable\.com|youtu\.be|youtube\.com|tiktok\.com|instagram\.com|cdn\.discordapp\.com|media\.discordapp\.net|redd\.it)\//i;

function hasMedia(message) {
    if (message.attachments.size > 0) return true;
    if (message.stickers && message.stickers.size > 0) return true;
    if (message.embeds.some(e => ['image', 'gifv', 'video'].includes(e.data?.type || e.type))) return true;
    return MEDIA_URL.test(message.content) || MEDIA_HOST.test(message.content);
}

/** Returns true if the message was removed. */
async function enforceMedia(message) {
    const cfg = store.peek('media', message.guild.id);
    if (!cfg || !cfg.channels || !cfg.channels.includes(message.channelId)) return false;
    if (message.author.id === message.guild.ownerId) return false;
    if ((cfg.bypassUsers || []).includes(message.author.id)) return false;
    if (message.member && message.member.roles.cache.some(r => (cfg.bypassRoles || []).includes(r.id))) return false;
    if (hasMedia(message)) return false;

    if (!message.deletable) return false;
    await message.delete().catch(() => {});
    const warn = await message.channel.send(`${message.author}, only media (images, videos, gifs, files) is allowed in this channel.`).catch(() => null);
    if (warn) setTimeout(() => warn.delete().catch(() => {}), 4000);
    return true;
}

// ---------- sticky messages ----------
const stickyTimers = new Map();
const stickyBusy = new Set();

/** Delete the old sticky and post it again at the bottom of the channel. */
async function repostSticky(channel) {
    const data = store.peek('sticky', channel.guild.id);
    const cfg = data && data[channel.id];
    if (!cfg) return null;
    if (stickyBusy.has(channel.id)) return null;
    stickyBusy.add(channel.id);
    try {
        if (cfg.lastMessageId) {
            const old = await channel.messages.fetch(cfg.lastMessageId).catch(() => null);
            if (old) await old.delete().catch(() => {});
        }
        const sent = await channel.send({ content: cfg.message, allowedMentions: { parse: [] } });
        cfg.lastMessageId = sent.id;
        store.save('sticky');
        return sent;
    } finally {
        stickyBusy.delete(channel.id);
    }
}

function handleSticky(message, client) {
    if (client.user && message.author.id === client.user.id) return;
    const data = store.peek('sticky', message.guild.id);
    if (!data || !data[message.channelId]) return;
    if (stickyTimers.has(message.channelId)) return;
    stickyTimers.set(message.channelId, setTimeout(async () => {
        stickyTimers.delete(message.channelId);
        try { await repostSticky(message.channel); } catch (e) { console.error('Sticky repost failed:', e.message); }
    }, 1500));
}

// ---------- entry points used by messageCreate ----------
/** Runs for every guild message (bots included): autodelete + sticky. Synchronous / non-blocking. */
function onAnyMessage(message, client) {
    handleAutodelete(message);
    handleSticky(message, client);
}

function ignored(cfg, message) {
    if ((cfg.ignoreChannels || []).includes(message.channelId)) return true;
    if ((cfg.ignoreUsers || []).includes(message.author.id)) return true;
    return false;
}

async function handleAutoreact(message) {
    const cfg = store.peek('autoreact', message.guild.id);
    if (!cfg || !cfg.enabled || !cfg.reactions || !cfg.reactions.length) return;
    if (ignored(cfg, message)) return;

    const emojis = new Set();
    for (const r of cfg.reactions) {
        if (r.enabled === false) continue;
        if (!matches(message.content, r.trigger)) continue;
        for (const e of String(r.emoji).split(/\s+/).filter(Boolean)) emojis.add(e);
    }
    for (const emoji of [...emojis].slice(0, 10)) {
        await message.react(emoji).catch(() => {});
    }
}

const responderCooldown = new Map();

function fillVars(text, message) {
    return text
        .replace(/\{user\.mention\}|\{user\}/gi, `<@${message.author.id}>`)
        .replace(/\{(?:user\.name|username)\}/gi, message.author.username)
        .replace(/\{server\}/gi, message.guild.name)
        .replace(/\{channel\}/gi, `<#${message.channelId}>`)
        .replace(/\{membercount\}/gi, String(message.guild.memberCount));
}

async function handleAutoresponder(message) {
    const cfg = store.peek('autoresponder', message.guild.id);
    if (!cfg || !cfg.enabled || !cfg.responders || !cfg.responders.length) return;
    if (ignored(cfg, message)) return;

    const hit = cfg.responders.find(r => r.enabled !== false && matches(message.content, r.trigger));
    if (!hit) return;

    const key = `${message.guild.id}:${message.channelId}:${hit.trigger.toLowerCase()}`;
    if (Date.now() - (responderCooldown.get(key) || 0) < 3000) return;
    responderCooldown.set(key, Date.now());

    await message.channel.send({
        content: fillVars(hit.response, message).slice(0, 2000),
        allowedMentions: { users: [message.author.id] },
    });
}

/** Runs for normal chat messages (not prefix commands): autoreact + autoresponder. */
async function onPlainMessage(message) {
    await handleAutoreact(message).catch(e => console.error('Autoreact error:', e.message));
    await handleAutoresponder(message).catch(e => console.error('Autoresponder error:', e.message));
}

// ---------- autorole ----------
async function onMemberAdd(member) {
    const cfg = store.peek('autorole', member.guild.id);
    if (!cfg || !cfg.enabled) return;

    const isBot = member.user.bot;
    if (isBot ? cfg.botsEnabled === false : cfg.humansEnabled === false) return;

    const me = member.guild.members.me;
    if (!me || !me.permissions.has('ManageRoles')) return;

    const ids = (isBot ? cfg.botRoles : cfg.humanRoles) || [];
    const roles = ids
        .map(id => member.guild.roles.cache.get(id))
        .filter(r => r && !r.managed && r.id !== member.guild.id && me.roles.highest.comparePositionTo(r) > 0);
    if (!roles.length) return;

    await member.roles.add(roles, 'Autorole').catch(e => console.error('Autorole failed:', e.message));
}

module.exports = { onAnyMessage, onPlainMessage, enforceMedia, onMemberAdd, repostSticky, matches };
