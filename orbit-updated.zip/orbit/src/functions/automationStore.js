// Small cached JSON store shared by the automation modules (autorole, autodelete, autoreact,
// autoresponder, sticky, media). Data lives in src/data/<name>.json and is cached in memory so
// per-message checks never hit the disk.
const fs = require('fs');
const path = require('path');

const dataDir = path.join(__dirname, '../data');

const DEFAULTS = {
    autorole: () => ({ enabled: false, humansEnabled: true, botsEnabled: true, humanRoles: [], botRoles: [] }),
    autodelete: () => ({ channels: {}, whitelist: [] }),
    autoreact: () => ({ enabled: false, reactions: [], ignoreUsers: [], ignoreChannels: [] }),
    autoresponder: () => ({ enabled: false, responders: [], ignoreUsers: [], ignoreChannels: [] }),
    sticky: () => ({}),
    media: () => ({ channels: [], bypassUsers: [], bypassRoles: [] }),
    // greetings (see greetRuntime.js / greetModule.js)
    greet: () => ({ enabled: false, channel: null, message: '', style: 'text', autodelete: null, card: false }),
    joindm: () => ({ enabled: false, message: '' }),
    leavemsg: () => ({ enabled: false, channel: null, message: '' }),
    boostgreet: () => ({ enabled: false, channel: null, message: '' }),
};

const cache = {};

function file(name) {
    return path.join(dataDir, `${name}.json`);
}

function load(name) {
    if (cache[name]) return cache[name];
    try {
        cache[name] = JSON.parse(fs.readFileSync(file(name), 'utf8')) || {};
    } catch {
        cache[name] = {};
    }
    return cache[name];
}

/** Get (and create + fill in missing keys of) a guild's config. */
function get(name, guildId) {
    const all = load(name);
    const defaults = DEFAULTS[name]();
    if (!all[guildId] || typeof all[guildId] !== 'object') all[guildId] = defaults;
    for (const key of Object.keys(defaults)) {
        if (all[guildId][key] === undefined) all[guildId][key] = defaults[key];
    }
    return all[guildId];
}

/** Read a guild's config without creating it (for hot paths). */
function peek(name, guildId) {
    return load(name)[guildId];
}

/** Put a guild's config back to its defaults. */
function reset(name, guildId) {
    const all = load(name);
    all[guildId] = DEFAULTS[name]();
    return all[guildId];
}

function save(name) {
    fs.mkdirSync(dataDir, { recursive: true });
    const tmp = `${file(name)}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(load(name), null, 2));
    fs.renameSync(tmp, file(name));
}

module.exports = { get, peek, save, reset };
