// Runtime for the greeting modules: welcomer (greet), join DM, leave message, boost greeting.
// The commands (greetModule.js) only edit config; this file actually sends the messages.
const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const store = require('./automationStore');
const common = require('./automationCommon');

const DEFAULT_MESSAGE = {
    greet: 'Welcome {user} to **{server}**! You are member #{membercount}.',
    joindm: 'Welcome to **{server}**, {username}! Glad to have you here.',
    leavemsg: '**{username}** has left **{server}**. We are now {membercount} members.',
    boostgreet: '💜 Thank you {user} for boosting **{server}**!',
};
const EMBED_COLOR = { greet: '#43b581', joindm: '#5865f2', leavemsg: '#f04747', boostgreet: '#f47fff' };
const TITLE = { greet: 'Welcome!', joindm: null, leavemsg: 'Goodbye', boostgreet: 'New Boost!' };

/** Replace {placeholders}. `mention` = false prints the username instead of a ping (used for leavers). */
function fill(text, user, guild, mention = true) {
    return String(text)
        .replace(/\{user\.mention\}|\{user\}|\{mention\}/gi, mention ? `<@${user.id}>` : user.username)
        .replace(/\{user\.name\}|\{username\}/gi, user.username)
        .replace(/\{user\.id\}/gi, user.id)
        .replace(/\{user\.tag\}/gi, user.tag || user.username)
        .replace(/\{server\}|\{guild\}/gi, guild.name)
        .replace(/\{membercount\}/gi, String(guild.memberCount))
        .replace(/\{boostcount\}/gi, String(guild.premiumSubscriptionCount || 0))
        .replace(/\{boosttier\}/gi, String(guild.premiumTier || 0))
        .slice(0, 2000);
}

function resolveChannel(kind, cfg, guild) {
    const ch = (cfg.channel && guild.channels.cache.get(cfg.channel)) || guild.systemChannel || null;
    return common.isTextChannel(ch) ? ch : null;
}

function buildPayload(kind, cfg, user, guild) {
    const text = fill(cfg.message || DEFAULT_MESSAGE[kind], user, guild, kind !== 'leavemsg');
    const useEmbed = kind !== 'joindm' && cfg.style === 'embed';
    if (!useEmbed) return { content: text };

    const embed = new EmbedBuilder()
        .setColor(EMBED_COLOR[kind])
        .setDescription(text)
        .setThumbnail(user.displayAvatarURL({ size: 256 }))
        .setFooter({ text: guild.name, iconURL: guild.iconURL() || undefined })
        .setTimestamp();
    if (TITLE[kind]) embed.setTitle(TITLE[kind]);
    if (cfg.card) embed.setImage(user.displayAvatarURL({ size: 1024 })); // "card": big avatar under the text
    // mention inside an embed does not ping, so also put it in content for greet/boost
    return { content: kind === 'leavemsg' ? undefined : `<@${user.id}>`, embeds: [embed] };
}

/**
 * Send one greeting. Returns { ok: true } or { ok: false, reason }.
 * Used by the real events and by the `test` subcommands.
 */
async function send(kind, guild, user) {
    const cfg = store.get(kind, guild.id);
    const payload = buildPayload(kind, cfg, user, guild);

    if (kind === 'joindm') {
        try { await user.send(payload); return { ok: true }; }
        catch { return { ok: false, reason: 'I could not DM that user (DMs are closed).' }; }
    }

    const channel = resolveChannel(kind, cfg, guild);
    if (!channel) return { ok: false, reason: `No channel is set. Use \`${kind} channel set #channel\`.` };
    const me = guild.members.me;
    if (me && !channel.permissionsFor(me)?.has([PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages])) {
        return { ok: false, reason: `I can't send messages in ${channel}.` };
    }
    payload.allowedMentions = kind === 'leavemsg' ? { parse: [] } : { users: [user.id] };

    let sent;
    try { sent = await channel.send(payload); }
    catch (e) { return { ok: false, reason: `Sending failed: ${e.message}` }; }

    const ms = kind === 'greet' ? common.parseDuration(cfg.autodelete) : null;
    if (ms && sent) setTimeout(() => sent.delete().catch(() => {}), ms);
    return { ok: true };
}

async function fire(kind, guild, user) {
    const cfg = store.peek(kind, guild.id);
    if (!cfg || !cfg.enabled) return;
    const res = await send(kind, guild, user);
    if (!res.ok) console.error(`[${kind}] ${guild.id}: ${res.reason}`);
}

// ---------- entry points used by the event files ----------
async function onMemberAdd(member) {
    await fire('greet', member.guild, member.user);
    if (!member.user.bot) await fire('joindm', member.guild, member.user);
}

async function onMemberRemove(member) {
    await fire('leavemsg', member.guild, member.user);
}

/** A member started boosting: premiumSince went from empty to a date. */
async function onMemberUpdate(oldMember, newMember) {
    if (oldMember.partial) return; // can't tell what changed
    if (!oldMember.premiumSince && newMember.premiumSince) {
        await fire('boostgreet', newMember.guild, newMember.user);
    }
}

module.exports = { onMemberAdd, onMemberRemove, onMemberUpdate, send, fill, DEFAULT_MESSAGE };
