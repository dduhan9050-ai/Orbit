const fs = require('fs');
const path = require('path');

const DATA_PATH = path.join(__dirname, '..', 'data', 'temproles.json');

function load() {
    try { return JSON.parse(fs.readFileSync(DATA_PATH, 'utf8')) || []; } catch (e) { return []; }
}
function save(list) {
    fs.mkdirSync(path.dirname(DATA_PATH), { recursive: true });
    fs.writeFileSync(DATA_PATH, JSON.stringify(list, null, 2), 'utf8');
}

function add(guildId, userId, roleId, expires) {
    const list = load().filter(e => !(e.guildId === guildId && e.userId === userId && e.roleId === roleId));
    list.push({ guildId, userId, roleId, expires });
    save(list);
}

/** Remove expired temp roles. Called on an interval from ready.js (survives restarts). */
async function check(client) {
    const list = load();
    if (!list.length) return;
    const now = Date.now();
    const keep = [];
    for (const e of list) {
        if (e.expires > now) { keep.push(e); continue; }
        try {
            const guild = client.guilds.cache.get(e.guildId);
            const member = guild && await guild.members.fetch(e.userId).catch(() => null);
            if (member && member.roles.cache.has(e.roleId)) await member.roles.remove(e.roleId, 'Temporary role expired');
        } catch (err) {
            console.error('Temp role removal failed:', err.message);
        }
    }
    if (keep.length !== list.length) save(keep);
}

module.exports = { add, check };
