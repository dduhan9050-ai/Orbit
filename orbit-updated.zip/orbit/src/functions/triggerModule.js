// Shared implementation for the two "trigger -> action" modules:
//   autoreact     (trigger -> emoji reaction)
//   autoresponder (trigger -> text reply)
// Returns { execute, executeMessage } for a command file to spread into its module.exports.
const { EmbedBuilder, MessageFlags } = require('discord.js');
const store = require('./automationStore');
const common = require('./automationCommon');

const KINDS = {
    autoreact: { listKey: 'reactions', valueKey: 'emoji', title: 'Autoreact', noun: 'auto-reaction', valueName: 'emoji', example: '`!autoreact add gm 👋`' },
    autoresponder: { listKey: 'responders', valueKey: 'response', title: 'Autoresponder', noun: 'auto-responder', valueName: 'response', example: '`!autoresponder add "good morning" Good morning {user}!`' },
};
const MAX_ENTRIES = 50;

function helpText(kind, k) {
    const v = k.valueName;
    return (
        `» **${kind} add <trigger> <${v}>**\n› Add an ${k.noun}. Use "quotes" for multi-word triggers.\n\n` +
        `» **${kind} edit <trigger> <${v}>**\n› Change an ${k.noun}.\n\n` +
        `» **${kind} remove <trigger>**\n› Remove an ${k.noun}.\n\n` +
        `» **${kind} toggle <trigger>**\n› Turn a single ${k.noun} on/off.\n\n` +
        `» **${kind} show**\n› Show all ${k.noun}s.\n\n` +
        `» **${kind} enable/disable**\n› Enable or disable the whole module.\n\n` +
        `» **${kind} ignore <add/remove/reset/show> [@user/#channel]**\n› Users/channels the module ignores.` +
        (kind === 'autoresponder' ? `\n\nPlaceholders: {user} {username} {server} {channel} {membercount}` : '')
    );
}

/** Validate emoji tokens. Returns { ok, emojis, error }. */
function parseEmojis(client, text) {
    const tokens = String(text || '').split(/\s+/).filter(Boolean);
    if (!tokens.length) return { ok: false, error: 'Please provide an emoji.' };
    if (tokens.length > 5) return { ok: false, error: 'You can use at most 5 emojis per trigger.' };
    for (const tok of tokens) {
        const custom = tok.match(/^<a?:\w+:(\d+)>$/);
        if (custom) {
            if (!client.emojis.cache.has(custom[1])) {
                return { ok: false, error: `I can't use ${tok} — custom emojis must come from a server I'm in.` };
            }
            continue;
        }
        if (/[A-Za-z]/.test(tok) || !/\p{Extended_Pictographic}|\p{Regional_Indicator}|\u20E3/u.test(tok)) {
            return { ok: false, error: `\`${tok}\` is not a valid emoji.` };
        }
    }
    return { ok: true, emojis: tokens };
}

function create(kind) {
    const k = KINDS[kind];
    const find = (cfg, trigger) => cfg[k.listKey].find(e => e.trigger.toLowerCase() === String(trigger).toLowerCase());

    async function run(ctx, group, sub, o) {
        const cfg = store.get(kind, ctx.guild.id);
        const save = () => store.save(kind);
        const list = cfg[k.listKey];

        if (group === 'ignore') {
            switch (sub) {
                case 'add': {
                    if (!o.targets.length) return ctx.fail('Please provide a user or a channel.');
                    for (const t of o.targets) {
                        const key = t.type === 'user' ? 'ignoreUsers' : 'ignoreChannels';
                        if (!cfg[key].includes(t.id)) cfg[key].push(t.id);
                    }
                    save();
                    return ctx.ok(`Added to the ${kind} ignore list.`);
                }
                case 'remove': {
                    if (!o.targets.length) return ctx.fail('Please provide a user or a channel.');
                    for (const t of o.targets) {
                        const key = t.type === 'user' ? 'ignoreUsers' : 'ignoreChannels';
                        cfg[key] = cfg[key].filter(id => id !== t.id);
                    }
                    save();
                    return ctx.ok(`Removed from the ${kind} ignore list.`);
                }
                case 'reset':
                    cfg.ignoreUsers = [];
                    cfg.ignoreChannels = [];
                    save();
                    return ctx.ok(`Reset the ${kind} ignore list.`);
                case 'show':
                    return ctx.send({ embeds: [new EmbedBuilder()
                        .setTitle(`${k.title} Ignore List`)
                        .addFields(
                            { name: 'Users', value: common.truncate(cfg.ignoreUsers.map(id => `<@${id}>`).join(', ') || 'None', 1024) },
                            { name: 'Channels', value: common.truncate(cfg.ignoreChannels.map(id => `<#${id}>`).join(', ') || 'None', 1024) }
                        )
                        .setColor('#2b2d31')] });
                default:
                    return ctx.fail('Unknown subcommand.');
            }
        }

        switch (sub) {
            case 'enable': cfg.enabled = true; save(); return ctx.ok(`${k.title} module has been enabled.`);
            case 'disable': cfg.enabled = false; save(); return ctx.ok(`${k.title} module has been disabled.`);
            case 'show': {
                const lines = list.map(e => {
                    const v = kind === 'autoreact' ? e.emoji : `"${common.truncate(e.response.replace(/\n/g, ' '), 40)}"`;
                    return `${e.enabled === false ? '🔴' : '🟢'} \`${e.trigger}\` → ${v}`;
                });
                return ctx.send({ embeds: [new EmbedBuilder()
                    .setTitle(`${k.title} Configuration`)
                    .setDescription(common.truncate(lines.join('\n') || 'Nothing configured yet.', 4000))
                    .addFields(
                        { name: 'Status', value: cfg.enabled ? '✅ Enabled' : '❌ Disabled (run `enable`)', inline: true },
                        { name: 'Total', value: String(list.length), inline: true }
                    )
                    .setColor('#2b2d31')] });
            }
            case 'add':
            case 'edit': {
                const trigger = (o.trigger || '').trim();
                const value = (o.value || '').trim();
                if (!trigger || !value) return ctx.fail(`Usage: \`${kind} ${sub} <trigger> <${k.valueName}>\``);
                if (trigger.length > 100) return ctx.fail('The trigger can be at most 100 characters.');

                let stored = value;
                if (kind === 'autoreact') {
                    const parsed = parseEmojis(ctx.client, value);
                    if (!parsed.ok) return ctx.fail(parsed.error);
                    stored = parsed.emojis.join(' ');
                } else if (value.length > 2000) {
                    return ctx.fail('The response can be at most 2000 characters.');
                }

                const existing = find(cfg, trigger);
                if (sub === 'add') {
                    if (existing) return ctx.fail(`A ${k.noun} for \`${trigger}\` already exists. Use \`${kind} edit\` to change it.`);
                    if (list.length >= MAX_ENTRIES) return ctx.fail(`You can have at most ${MAX_ENTRIES} ${k.noun}s.`);
                    list.push({ trigger, [k.valueKey]: stored, enabled: true });
                    save();
                    return ctx.ok(`Added: **${trigger}** → ${common.truncate(stored, 200)}${cfg.enabled ? '' : '\n(The module is disabled — run `enable` to turn it on.)'}`);
                }
                if (!existing) return ctx.fail(`No ${k.noun} found for \`${trigger}\`.`);
                existing[k.valueKey] = stored;
                save();
                return ctx.ok(`Updated: **${existing.trigger}**`);
            }
            case 'remove': {
                const existing = o.trigger && find(cfg, o.trigger);
                if (!existing) return ctx.fail(`No ${k.noun} found for \`${o.trigger || ''}\`.`);
                cfg[k.listKey] = list.filter(e => e !== existing);
                save();
                return ctx.ok(`Removed: **${existing.trigger}**`);
            }
            case 'toggle': {
                const existing = o.trigger && find(cfg, o.trigger);
                if (!existing) return ctx.fail(`No ${k.noun} found for \`${o.trigger || ''}\`.`);
                existing.enabled = existing.enabled === false;
                save();
                return ctx.ok(`**${existing.trigger}** is now ${existing.enabled ? 'enabled 🟢' : 'disabled 🔴'}.`);
            }
            default:
                return ctx.fail('Unknown subcommand.');
        }
    }

    return {
        async execute(interaction) {
            if (!interaction.member.permissions.has('ManageGuild')) {
                return interaction.reply({ content: '❌ No access', flags: MessageFlags.Ephemeral });
            }
            const user = interaction.options.getUser('user');
            const channel = interaction.options.getChannel('channel');
            await run(common.fromInteraction(interaction), interaction.options.getSubcommandGroup(false), interaction.options.getSubcommand(), {
                trigger: interaction.options.getString('trigger'),
                value: interaction.options.getString(k.valueName),
                targets: [user && { type: 'user', id: user.id }, channel && { type: 'channel', id: channel.id }].filter(Boolean),
            });
        },

        async executeMessage(message, args) {
            const first = args[0] ? args[0].toLowerCase() : 'help';
            const SUBS = ['add', 'edit', 'remove', 'toggle', 'show', 'enable', 'disable', 'ignore'];
            if (first === 'help' || !SUBS.includes(first)) {
                return message.reply({ embeds: [common.helpEmbed(helpText(kind, k), message)] });
            }
            const ctx = common.fromMessage(message);
            if (!message.member.permissions.has('ManageGuild')) return ctx.fail('No access');

            if (first === 'ignore') {
                const sub = args[1] ? args[1].toLowerCase() : null;
                if (!['add', 'remove', 'reset', 'show'].includes(sub)) {
                    return ctx.fail(`Usage: \`${kind} ignore <add/remove/reset/show> [@user/#channel]\``);
                }
                const targets = [];
                if (sub === 'add' || sub === 'remove') {
                    const t = await common.resolveAny(message.guild, args[2]);
                    if (!t || (t.type !== 'user' && t.type !== 'channel')) {
                        return ctx.fail(`Please mention a user or channel. Usage: \`${kind} ignore ${sub} @user/#channel\``);
                    }
                    targets.push(t);
                }
                return run(ctx, 'ignore', sub, { targets });
            }

            const [trigger, rest] = common.takeToken(args.slice(1).join(' '));
            return run(ctx, null, first, { trigger, value: rest });
        },
    };
}

module.exports = { create };
