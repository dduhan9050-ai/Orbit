// Tiny Giphy client used by the Fun module. Needs GIPHY_API_KEY in .env
// (free key: https://developers.giphy.com/dashboard/).
//
//   const gif = await giphy.random('anime hug');   // -> { url, title, page } | null
//
// Results are cached per query for 10 minutes so spamming a command does not burn API quota.
const API = 'https://api.giphy.com/v1/gifs/search';
const TTL = 10 * 60 * 1000;
const cache = new Map(); // query -> { at, items }

class GiphyError extends Error {
    constructor(code, message) {
        super(message);
        this.code = code; // NO_KEY | HTTP | NETWORK
    }
}

const hasKey = () => !!(process.env.GIPHY_API_KEY || '').trim();

function pickUrl(g) {
    const im = g.images || {};
    // downsized_medium loads fast in chat; fall back to the original if Giphy omits it
    return (im.downsized_medium && im.downsized_medium.url)
        || (im.fixed_height && im.fixed_height.url)
        || (im.original && im.original.url)
        || null;
}

async function fetchItems(query) {
    const key = (process.env.GIPHY_API_KEY || '').trim();
    if (!key) throw new GiphyError('NO_KEY', 'GIPHY_API_KEY is not set in .env');

    const hit = cache.get(query);
    if (hit && Date.now() - hit.at < TTL) return hit.items;

    const params = new URLSearchParams({
        api_key: key,
        q: query,
        limit: '30',
        rating: process.env.GIPHY_RATING || 'pg-13',
        lang: 'en',
    });

    let res;
    try {
        res = await fetch(`${API}?${params}`, { signal: AbortSignal.timeout(6000) });
    } catch (e) {
        throw new GiphyError('NETWORK', `Could not reach Giphy (${e.message})`);
    }
    if (!res.ok) throw new GiphyError('HTTP', `Giphy returned HTTP ${res.status}${res.status === 429 ? ' (rate limited)' : ''}`);

    const json = await res.json().catch(() => ({}));
    const items = (json.data || [])
        .map(g => ({ url: pickUrl(g), title: g.title || '', page: g.url || null }))
        .filter(g => g.url);
    cache.set(query, { at: Date.now(), items });
    return items;
}

/** Random GIF for a search query, or null if Giphy has nothing. Throws GiphyError on failure. */
async function random(query) {
    const items = await fetchItems(query);
    return items.length ? items[Math.floor(Math.random() * items.length)] : null;
}

module.exports = { random, hasKey, GiphyError };
