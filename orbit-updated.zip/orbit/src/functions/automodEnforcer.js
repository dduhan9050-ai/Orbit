const { EmbedBuilder } = require('discord.js');
const automod = require('./automodManager');
const permit = require('./permitManager');

const MUTE_MS = 10 * 60 * 1000;       // timeout length used for automod "mute"
const ALERT_WINDOW_MS = 10 * 60 * 1000; // alerts older than this stop counting towards automute

// userKey -> { heat, last, lastContent }
const heatMap = new Map();
// userKey -> { count, first }
const alertMap = new Map();

const INVITE_RE = /(?:discord(?:app)?\.com\/invite|discord\.gg|discord\.me|discord\.io|dsc\.gg)\/[\w-]+/i;
const LINK_RE = /(?:https?:\/\/|www\.)\S+/i;

function escapeRegex(s) {
    return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function wordMatches(content, word) {
    const w = word.trim();
    if (!w) return false;
    // whole-word match for plain words so "ass" does not hit "class"; substring match if the entry contains symbols/spaces
    if (/^[\p{L}\p{N}_]+$/u.test(w)) {
        return new RegExp(`(?<![\\p{L}\\p{N}_])${escapeRegex(w)}(?![\\p{L}\\p{N}_])`, 'iu').test(content);
    }
    return content.toLowerCase().includes(w.toLowerCase());
}

function isExempt(message, config) {
    const { author, member, guild, channel } = message;
    if (author.id === guild.ownerId) return true;
    if (permit.isExtraOwner(guild.id, author.id)) return true;
    if (config.ignore.users.includes(author.id)) return true;
    if (config.ignore.channels.includes(channel.id) || (channel.parentId && config.ignore.channels.includes(channel.parentId))) return true;
    if (member && config.ignore.roles.some(r => member.roles.cache.has(r))) return true;
    return false;
}

function checkFilters(message, config, isEdit = false) {
    const f = config.filters;
    const content = message.content || '';

    if (f.invites.enabled && INVITE_RE.test(content)) return 'Posting server invites';
    if (f.links.enabled && LINK_RE.test(content)) return 'Posting links';

    if (f.mentions.enabled) {
        const count = message.mentions.users.size + message.mentions.roles.size + (message.mentions.everyone ? 1 : 0);
        if (count >= f.mentions.threshold) return `Mass mentions (${count})`;
    }

    if (f.caps.enabled) {
        const letters = content.replace(/[^\p{L}]/gu, '');
        if (letters.length >= 8) {
            const upper = letters.replace(/[^\p{Lu}]/gu, '').length;
            const pct = Math.round((upper / letters.length) * 100);
            if (pct >= f.caps.threshold) return `Excessive caps (${pct}%)`;
        }
    }

    if (f.spoilers.enabled) {
        const spoilers = (content.match(/\|\|[\s\S]+?\|\|/g) || []).length;
        if (spoilers >= f.spoilers.threshold) return `Excessive spoilers (${spoilers})`;
    }

    if (f.newlines.enabled) {
        const lines = (content.match(/\n/g) || []).length;
        if (lines >= f.newlines.threshold) return `Excessive new lines (${lines})`;
    }

    if (f.heat.enabled && !isEdit) {
        const key = `${message.guild.id}:${message.author.id}`;
        const now = Date.now();
        const entry = heatMap.get(key) || { heat: 0, last: now, lastContent: null };
        const decaySecs = Math.max(1, f.heat.decay || 2);
        entry.heat = Math.max(0, entry.heat - (now - entry.last) / (decaySecs * 1000));
        entry.last = now;
        let add = 1;
        if (content && entry.lastContent === content) add += 1; // repeated message costs more
        if (message.mentions.users.size > 0) add += 0.5;
        entry.heat += add;
        entry.lastContent = content;
        heatMap.set(key, entry);
        if (entry.heat >= f.heat.threshold) {
            entry.heat = 0;
            return 'Spamming (heat limit reached)';
        }
    }

    return null;
}

async function sendLog(message, config, reason, action) {
    if (!config.logging) return;
    const ch = message.guild.channels.cache.get(config.logging);
    if (!ch || !ch.isTextBased()) return;
    const embed = new EmbedBuilder()
        .setTitle('🤖 Automod Action')
        .setColor('#f04747')
        .addFields(
            { name: 'User', value: `${message.author} (${message.author.id})`, inline: true },
            { name: 'Channel', value: `${message.channel}`, inline: true },
            { name: 'Reason', value: reason },
            { name: 'Action', value: action }
        )
        .setTimestamp();
    if (message.content) embed.addFields({ name: 'Content', value: message.content.slice(0, 1000) });
    await ch.send({ embeds: [embed] }).catch(() => {});
}

async function punish(message, type, reason) {
    const member = message.member || await message.guild.members.fetch(message.author.id).catch(() => null);
    if (!member) return { done: false, text: 'member not found' };
    try {
        if (type === 'ban') {
            if (!member.bannable) return { done: false, text: 'cannot ban (role hierarchy)' };
            await member.ban({ reason: `Automod: ${reason}` });
            return { done: true, text: 'Banned' };
        }
        if (type === 'kick') {
            if (!member.kickable) return { done: false, text: 'cannot kick (role hierarchy)' };
            await member.kick(`Automod: ${reason}`);
            return { done: true, text: 'Kicked' };
        }
        if (!member.moderatable) return { done: false, text: 'cannot mute (role hierarchy / missing permission)' };
        await member.timeout(MUTE_MS, `Automod: ${reason}`);
        return { done: true, text: `Muted for ${MUTE_MS / 60000} minutes` };
    } catch (e) {
        return { done: false, text: `punishment failed: ${e.message}` };
    }
}

async function warn(message, text) {
    try {
        const w = await message.channel.send({ content: `${message.author}, ${text}`, allowedMentions: { users: [message.author.id] } });
        setTimeout(() => w.delete().catch(() => {}), 5000);
    } catch (e) { /* no send permission */ }
}

async function removeSpam(message) {
    try {
        const recent = await message.channel.messages.fetch({ limit: 25 });
        const cutoff = Date.now() - 30000;
        const mine = recent.filter(m => m.author.id === message.author.id && m.createdTimestamp >= cutoff);
        if (mine.size > 1) await message.channel.bulkDelete(mine, true);
        else if (message.deletable) await message.delete();
    } catch (e) {
        if (message.deletable) await message.delete().catch(() => {});
    }
}

/**
 * Run all automod checks on a message.
 * @returns {Promise<boolean>} true if the message was actioned (caller should stop processing it)
 */
async function handleMessage(message, opts = {}) {
    if (!message.guild || message.author.bot || !message.content && message.mentions.users.size === 0) return false;
    if (!message.member) {
        try { message.member = await message.guild.members.fetch(message.author.id); } catch (e) { return false; }
    }

    const config = automod.getGuildData(message.guild.id);

    // ---- Blacklisted words (active whenever words are configured) ----
    const bl = config.blacklist;
    if (bl.words.length > 0 && message.content) {
        const exempt =
            message.author.id === message.guild.ownerId ||
            permit.isExtraOwner(message.guild.id, message.author.id) ||
            bl.whitelisted_channels.includes(message.channel.id) ||
            bl.whitelisted_roles.some(r => message.member.roles.cache.has(r));
        if (!exempt) {
            const caught = bl.words.find(w => wordMatches(message.content, w));
            if (caught) {
                if (message.deletable) await message.delete().catch(() => {});
                const result = await punish(message, bl.punishment || 'mute', 'Blacklisted word');
                await warn(message, result.done ? `that word is not allowed here! (${result.text})` : 'that word is not allowed here!');
                await sendLog(message, config, 'Blacklisted word', result.done ? result.text : `Message deleted (${result.text})`);
                return true;
            }
        }
    }

    // ---- General automod ----
    if (!config.enabled) return false;
    if (isExempt(message, config)) return false;

    const reason = checkFilters(message, config, !!opts.isEdit);
    if (!reason) return false;

    if (reason.startsWith('Spamming')) await removeSpam(message);
    else if (message.deletable) await message.delete().catch(() => {});

    let action = 'Message deleted';
    let notice = `your message was removed: ${reason.toLowerCase()}.`;

    if (config.filters.automute.enabled) {
        const key = `${message.guild.id}:${message.author.id}`;
        const now = Date.now();
        let alerts = alertMap.get(key);
        if (!alerts || now - alerts.first > ALERT_WINDOW_MS) alerts = { count: 0, first: now };
        alerts.count += 1;
        alertMap.set(key, alerts);

        if (alerts.count >= config.filters.automute.threshold) {
            alertMap.delete(key);
            const result = await punish(message, config.punishment, reason);
            action = result.done ? `Message deleted + ${result.text}` : `Message deleted (${result.text})`;
            if (result.done) notice += ` You have been punished: ${result.text.toLowerCase()}.`;
        } else {
            action = `Message deleted (alert ${alerts.count}/${config.filters.automute.threshold})`;
        }
    }

    await warn(message, notice);
    await sendLog(message, config, reason, action);
    return true;
}

module.exports = { handleMessage };
