// Remembers the last deleted message per channel for the snipe command.
const store = new Map();
const MAX_AGE_MS = 10 * 60 * 1000;

module.exports = {
    set(message) {
        if (!message.channel || message.author?.bot) return;
        if (!message.content && !(message.attachments && message.attachments.size)) return;
        store.set(message.channel.id, {
            content: message.content || '',
            authorTag: message.author ? message.author.tag : 'Unknown',
            authorAvatar: message.author ? message.author.displayAvatarURL() : null,
            attachments: message.attachments ? [...message.attachments.values()].map(a => a.url) : [],
            deletedAt: Date.now(),
            createdAt: message.createdTimestamp
        });
    },
    get(channelId) {
        const entry = store.get(channelId);
        if (!entry) return null;
        if (Date.now() - entry.deletedAt > MAX_AGE_MS) { store.delete(channelId); return null; }
        return entry;
    }
};
