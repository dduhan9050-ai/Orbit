// Shared helpers for the automation command modules: parsing, a tiny "context" layer so slash and
// prefix commands run the exact same logic, and common embeds.
const { EmbedBuilder, MessageFlags } = require('discord.js');

const UNITS = { s: 1000, m: 60 * 1000, h: 60 * 60 * 1000, d: 24 * 60 * 60 * 1000 };

/** "10s", "5m", "1h30m", "2d" -> milliseconds (or null if invalid). */
function parseDuration(input) {
    if (typeof input === 'number') return input > 0 ? input : null;
    if (!input) return null;
    const s = String(input).trim().toLowerCase().replace(/\s+/g, '');
    if (!/^(\d+[smhd])+$/.test(s)) return null;
    let ms = 0;
    for (const m of s.matchAll(/(\d+)([smhd])/g)) ms += parseInt(m[1], 10) * UNITS[m[2]];
    return ms > 0 ? ms : null;
}

function formatDuration(ms) {
    ms = Math.round(ms / 1000);
    const parts = [];
    for (const [label, size] of [['d', 86400], ['h', 3600], ['m', 60], ['s', 1]]) {
        const n = Math.floor(ms / size);
        if (n) { parts.push(`${n}${label}`); ms -= n * size; }
    }
    return parts.join(' ') || '0s';
}

function idFrom(str) {
    const m = String(str || '').match(/\d{15,22}/);
    return m ? m[0] : null;
}

function resolveChannel(guild, str) {
    const id = idFrom(str);
    return id ? guild.channels.cache.get(id) || null : null;
}

function resolveRole(guild, str) {
    const id = idFrom(str);
    return id ? guild.roles.cache.get(id) || null : null;
}

/** Resolve a mention/ID into a role, channel or user. */
async function resolveAny(guild, str) {
    const id = idFrom(str);
    if (!id) return null;
    const role = guild.roles.cache.get(id);
    if (role) return { type: 'role', id, role };
    const channel = guild.channels.cache.get(id);
    if (channel) return { type: 'channel', id, channel };
    const member = guild.members.cache.get(id) || await guild.members.fetch(id).catch(() => null);
    if (member) return { type: 'user', id, member };
    return null;
}

/** Take the first token of a string; supports "quoted phrases". Returns [token, rest]. */
function takeToken(text) {
    text = String(text || '').trim();
    const quoted = text.match(/^["“](.+?)["”]\s*([\s\S]*)$/);
    if (quoted) return [quoted[1].trim(), quoted[2].trim()];
    const i = text.search(/\s/);
    if (i === -1) return [text, ''];
    return [text.slice(0, i), text.slice(i + 1).trim()];
}

function truncate(str, max) {
    str = String(str);
    return str.length > max ? `${str.slice(0, max - 1)}…` : str;
}

function isTextChannel(channel) {
    return !!channel && typeof channel.isTextBased === 'function' && channel.isTextBased() && !channel.isDMBased?.();
}

/** Context for prefix commands. */
function fromMessage(message) {
    return {
        isSlash: false,
        guild: message.guild,
        member: message.member,
        user: message.author,
        channel: message.channel,
        client: message.client,
        send: (payload) => message.reply(typeof payload === 'string' ? { content: payload } : payload),
        ok: async (text) => {
            const reply = await message.reply(text.startsWith('✅') ? text : `✅ ${text}`);
            setTimeout(() => reply.delete().catch(() => {}), 3000);
        },
        fail: (text) => message.reply(text.startsWith('❌') ? text : `❌ ${text}`),
    };
}

/** Context for slash commands. */
function fromInteraction(interaction) {
    const respond = (payload, ephemeral) => {
        const p = typeof payload === 'string' ? { content: payload } : { ...payload };
        if (ephemeral) p.flags = MessageFlags.Ephemeral;
        return interaction.replied || interaction.deferred ? interaction.followUp(p) : interaction.reply(p);
    };
    return {
        isSlash: true,
        guild: interaction.guild,
        member: interaction.member,
        user: interaction.user,
        channel: interaction.channel,
        client: interaction.client,
        send: (payload) => respond(payload, false),
        ok: (text) => respond(text.startsWith('✅') ? text : `✅ ${text}`, false),
        fail: (text) => respond(text.startsWith('❌') ? text : `❌ ${text}`, true),
    };
}

function helpEmbed(lines, message) {
    return new EmbedBuilder()
        .setDescription(`\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n${lines}`)
        .setColor('#2b2d31')
        .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });
}

function noAccess(ctxOrMessage) {
    return ctxOrMessage.fail ? ctxOrMessage.fail('No access. You need the required permission to use this command.') : null;
}

module.exports = {
    parseDuration, formatDuration, idFrom, resolveChannel, resolveRole, resolveAny,
    takeToken, truncate, isTextChannel, fromMessage, fromInteraction, helpEmbed, noAccess,
};
