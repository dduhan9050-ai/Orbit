/**
 * Small declarative helper so every moderation command works the same way
 * from both slash (/ban) and prefix (!ban) without duplicating logic.
 *
 * makeCommand({
 *   name, description, perms: [PermissionFlagsBits...],
 *   options: [{ name, type, description, required, choices, min, max }],
 *   subs: { subName: { description, options, perms, run } },
 *   run: async (ctx, p) => {}
 * })
 *
 * option types: user | string | rest | integer | channel | role | duration
 *  - rest     : string that swallows the remaining prefix words
 *  - duration : string such as 10m / 2h / 1d (prefix: only consumed if it parses)
 */
const { SlashCommandBuilder, EmbedBuilder, MessageFlags, PermissionsBitField } = require('discord.js');
const permit = require('./permitManager');
const { passesTopCheck } = require('./permissionChecker');

class UserError extends Error {}

const PERM_NAMES = Object.fromEntries(Object.entries(PermissionsBitField.Flags).map(([k, v]) => [v.toString(), k]));
const permName = (p) => (PERM_NAMES[p.toString()] || String(p)).replace(/([A-Z])/g, ' $1').trim();

const COLORS = { success: '#43b581', error: '#f04747', info: '#5865f2', warn: '#faa61a' };
const box = (color, text) => new EmbedBuilder().setColor(color).setDescription(text);

function isPrivileged(member, guild) {
    return member.id === guild.ownerId || permit.isExtraOwner(guild.id, member.id);
}

/** "1h30m" -> ms, bare numbers are minutes. Returns null if it doesn't parse. */
function parseDuration(str) {
    if (!str) return null;
    const re = /(\d+(?:\.\d+)?)(s|secs?|m|mins?|h|hrs?|d|days?|w|weeks?)?/gi;
    const unit = { s: 1e3, sec: 1e3, secs: 1e3, m: 6e4, min: 6e4, mins: 6e4, h: 36e5, hr: 36e5, hrs: 36e5, d: 864e5, day: 864e5, days: 864e5, w: 6048e5, week: 6048e5, weeks: 6048e5 };
    const clean = String(str).trim().toLowerCase();
    if (!/^(\d+(\.\d+)?(s|secs?|m|mins?|h|hrs?|d|days?|w|weeks?)?)+$/.test(clean)) return null;
    let total = 0, m, matched = false;
    while ((m = re.exec(clean)) !== null) {
        if (m[0] === '') { re.lastIndex++; continue; }
        const u = m[2] ? unit[m[2]] : 6e4;
        if (!u) return null;
        total += parseFloat(m[1]) * u;
        matched = true;
    }
    return matched && total > 0 ? Math.round(total) : null;
}

function formatDuration(ms) {
    const parts = [];
    const d = Math.floor(ms / 864e5); ms -= d * 864e5;
    const h = Math.floor(ms / 36e5); ms -= h * 36e5;
    const m = Math.floor(ms / 6e4); ms -= m * 6e4;
    const s = Math.floor(ms / 1e3);
    if (d) parts.push(`${d}d`);
    if (h) parts.push(`${h}h`);
    if (m) parts.push(`${m}m`);
    if (s && !d && !h) parts.push(`${s}s`);
    return parts.join(' ') || '0s';
}

const idFrom = (tok) => {
    if (!tok) return null;
    const m = String(tok).match(/^<(?:@!?|@&|#)(\d+)>$|^(\d{15,22})$/);
    return m ? (m[1] || m[2]) : null;
};

// ---------------------------------------------------------------- context
function baseCtx(guild, channel, member, client) {
    return {
        guild, channel, member, client,
        isPrivileged: () => isPrivileged(member, guild),
        requirePerms(perms = []) {
            if (isPrivileged(member, guild)) return;
            const missing = perms.filter(p => !member.permissions.has(p));
            if (missing.length) throw new UserError('❌ No access');
        },
        requireBotPerms(perms = [], channelOverride) {
            const me = guild.members.me;
            const target = channelOverride || null;
            const have = target ? target.permissionsFor(me) : me.permissions;
            const missing = perms.filter(p => !have || !have.has(p));
            if (missing.length) throw new UserError(`I need the following permission(s): **${missing.map(permName).join(', ')}**.`);
        },
        /** Throws if the executor / bot can't act on this member (hierarchy checks). */
        checkTarget(target, verb) {
            if (!target) return;
            if (target.id === member.id) throw new UserError(`You cannot ${verb} yourself.`);
            if (target.id === client.user.id) throw new UserError(`I can't ${verb} myself.`);
            if (target.id === guild.ownerId) throw new UserError(`You cannot ${verb} the server owner.`);
            if (!isPrivileged(member, guild)) {
                if (member.roles.highest.comparePositionTo(target.roles.highest) <= 0) {
                    throw new UserError(`You cannot ${verb} someone with an equal or higher role than yours.`);
                }
                if (!passesTopCheck(member, target, guild)) throw new UserError('Top check failed for this target.');
            }
            if (guild.members.me.roles.highest.comparePositionTo(target.roles.highest) <= 0) {
                throw new UserError(`I can't ${verb} that member - their top role is equal to or higher than mine.`);
            }
        },
        checkRole(role, verb = 'manage') {
            if (role.id === guild.id) throw new UserError('You cannot use the @everyone role here.');
            if (role.managed) throw new UserError('That role is managed by an integration and cannot be assigned manually.');
            if (!isPrivileged(member, guild) && member.roles.highest.comparePositionTo(role) <= 0) {
                throw new UserError(`You cannot ${verb} a role that is equal to or higher than your top role.`);
            }
            if (guild.members.me.roles.highest.comparePositionTo(role) <= 0) {
                throw new UserError(`I can't ${verb} that role - it is equal to or higher than my top role.`);
            }
        }
    };
}

function slashCtx(interaction) {
    const ctx = baseCtx(interaction.guild, interaction.channel, interaction.member, interaction.client);
    let state = 'fresh';
    const send = async (payload, ephemeral = false) => {
        const opts = { ...payload };
        if (state === 'fresh') {
            state = 'replied';
            if (ephemeral) opts.flags = MessageFlags.Ephemeral;
            return interaction.reply(opts);
        }
        if (state === 'deferred') {
            state = 'replied';
            return interaction.editReply(opts);
        }
        if (ephemeral) opts.flags = MessageFlags.Ephemeral;
        return interaction.followUp(opts);
    };
    Object.assign(ctx, {
        isSlash: true,
        interaction,
        async defer(ephemeral = false) {
            if (state !== 'fresh') return;
            await interaction.deferReply(ephemeral ? { flags: MessageFlags.Ephemeral } : {});
            state = 'deferred';
        },
        send,
        success: (t) => send({ embeds: [box(COLORS.success, t)] }),
        info: (t) => send({ embeds: [box(COLORS.info, t)] }),
        warn: (t) => send({ embeds: [box(COLORS.warn, t)] }),
        error: (t) => send({ embeds: [box(COLORS.error, t)] }, true),
        /** reply but don't reply twice - used when the channel itself is about to be destroyed */
        get replied() { return state !== 'fresh'; }
    });
    return ctx;
}

function messageCtx(message) {
    const ctx = baseCtx(message.guild, message.channel, message.member, message.client);
    let selfDeleted = false;
    const send = async (payload) => {
        try {
            if (selfDeleted) return await message.channel.send(payload);
            return await message.reply({ ...payload, allowedMentions: { repliedUser: false } });
        } catch (e) {
            return message.channel.send(payload).catch(() => null);
        }
    };
    Object.assign(ctx, {
        isSlash: false,
        message,
        async defer() { await message.channel.sendTyping().catch(() => {}); },
        send,
        success: (t) => send({ embeds: [box(COLORS.success, t)] }),
        info: (t) => send({ embeds: [box(COLORS.info, t)] }),
        warn: (t) => send({ embeds: [box(COLORS.warn, t)] }),
        error: (t) => send({ embeds: [box(COLORS.error, t)] }),
        async deleteInvocation() { selfDeleted = true; await message.delete().catch(() => {}); },
        get replied() { return false; }
    });
    return ctx;
}

/** Send a message, and remove it after `ms` (prefix commands keep chat tidy; slash replies stay). */
async function sendTemp(ctx, kind, text, ms = 4000) {
    const m = await ctx[kind](text);
    if (!ctx.isSlash && m && m.delete) setTimeout(() => m.delete().catch(() => {}), ms);
    return m;
}

// ---------------------------------------------------------------- slash building
function addOption(builder, o) {
    const common = (opt) => {
        opt.setName(o.name).setDescription((o.description || o.name).slice(0, 100)).setRequired(!!o.required);
        return opt;
    };
    switch (o.type) {
        case 'user': return builder.addUserOption(common);
        case 'channel': return builder.addChannelOption((opt) => {
            common(opt);
            if (o.channelTypes && o.channelTypes.length) opt.addChannelTypes(...o.channelTypes);
            return opt;
        });
        case 'role': return builder.addRoleOption(common);
        case 'integer': return builder.addIntegerOption((opt) => {
            common(opt);
            if (o.min !== undefined) opt.setMinValue(o.min);
            if (o.max !== undefined) opt.setMaxValue(o.max);
            return opt;
        });
        default: return builder.addStringOption((opt) => {
            common(opt);
            if (o.choices) opt.addChoices(...o.choices.map(c => ({ name: c, value: c })));
            return opt;
        });
    }
}

// Discord requires required options before optional ones
const orderOpts = (opts = []) => [...opts.filter(o => o.required), ...opts.filter(o => !o.required)];

// ---------------------------------------------------------------- param parsing
function readSlashParams(interaction, options = []) {
    const p = {};
    for (const o of options) {
        switch (o.type) {
            case 'user': {
                const user = interaction.options.getUser(o.name);
                p[o.name] = user ? { user, member: interaction.options.getMember(o.name) || null } : null;
                break;
            }
            case 'channel': p[o.name] = interaction.options.getChannel(o.name); break;
            case 'role': p[o.name] = interaction.options.getRole(o.name); break;
            case 'integer': p[o.name] = interaction.options.getInteger(o.name); break;
            case 'duration': {
                const raw = interaction.options.getString(o.name);
                p[o.name] = raw ? { raw, ms: parseDuration(raw) } : null;
                if (raw && !p[o.name].ms) throw new UserError(`Invalid duration \`${raw}\`. Examples: \`30m\`, \`2h\`, \`1d\`.`);
                break;
            }
            default: p[o.name] = interaction.options.getString(o.name);
        }
    }
    return p;
}

async function readMessageParams(message, args, options = [], usage = '') {
    const p = {};
    const guild = message.guild;
    let tokens = [...args];
    const ordered = options; // prefix order = declared order (required first, which is how we declare them)

    // "rest" followed by an integer: peel the trailing number first (e.g. clear contain <text> <amount>)
    const restIdx = ordered.findIndex(o => o.type === 'rest');
    if (restIdx !== -1 && ordered.slice(restIdx + 1).some(o => o.type === 'integer') && tokens.length > 1 && /^\d+$/.test(tokens[tokens.length - 1])) {
        const intOpt = ordered.slice(restIdx + 1).find(o => o.type === 'integer');
        p[intOpt.name] = parseInt(tokens.pop(), 10);
    }

    for (let i = 0; i < ordered.length; i++) {
        const o = ordered[i];
        if (p[o.name] !== undefined) continue;
        const isLast = ordered.slice(i + 1).every(x => p[x.name] !== undefined);
        const tok = tokens[0];
        switch (o.type) {
            case 'user': {
                const id = idFrom(tok);
                if (!id) { p[o.name] = null; break; }
                tokens.shift();
                const member = await guild.members.fetch(id).catch(() => null);
                const user = member ? member.user : await message.client.users.fetch(id).catch(() => null);
                p[o.name] = user ? { user, member } : null;
                if (!user) throw new UserError('I could not find that user.');
                break;
            }
            case 'channel': {
                const id = idFrom(tok);
                const ch = id ? guild.channels.cache.get(id) : null;
                if (ch) tokens.shift();
                p[o.name] = ch || null;
                if (!ch && tok && o.required) throw new UserError('I could not find that channel.');
                break;
            }
            case 'role': {
                let role = null;
                const id = idFrom(tok);
                if (id) { role = guild.roles.cache.get(id) || null; if (role) tokens.shift(); }
                else if (tok) {
                    const name = (isLast ? tokens.join(' ') : tok).toLowerCase();
                    role = guild.roles.cache.find(r => r.name.toLowerCase() === name) || null;
                    if (role) tokens = isLast ? [] : tokens.slice(1);
                }
                p[o.name] = role;
                if (!role && tok) throw new UserError('I could not find that role.');
                break;
            }
            case 'integer': {
                if (tok !== undefined && /^-?\d+$/.test(tok)) { p[o.name] = parseInt(tok, 10); tokens.shift(); }
                else p[o.name] = null;
                break;
            }
            case 'duration': {
                const ms = parseDuration(tok);
                if (tok && ms) { p[o.name] = { raw: tok, ms }; tokens.shift(); }
                else p[o.name] = null;
                break;
            }
            case 'rest':
                p[o.name] = tokens.length ? tokens.join(' ') : null; tokens = [];
                break;
            default: // string
                p[o.name] = tokens.length ? tokens.shift() : null;
        }
    }
    const missing = ordered.find(o => o.required && (p[o.name] === null || p[o.name] === undefined));
    if (missing) throw new UserError(`Missing **${missing.name}**. Usage: \`${usage}\``);
    return p;
}

const usageOf = (name, options = [], sub) =>
    `${name}${sub ? ' ' + sub : ''} ${options.map(o => (o.required ? `<${o.name}>` : `[${o.name}]`)).join(' ')}`.trim();

// ---------------------------------------------------------------- command factory
function makeCommand(def) {
    const { name, description, subs, groups } = def;
    const builder = new SlashCommandBuilder().setName(name).setDescription(description.slice(0, 100));

    const addSub = (target, subName, sub) => target.addSubcommand(sc => {
        sc.setName(subName).setDescription((sub.description || subName).slice(0, 100));
        for (const o of orderOpts(sub.options)) addOption(sc, o);
        return sc;
    });

    if (subs || groups) {
        for (const [subName, sub] of Object.entries(subs || {})) addSub(builder, subName, sub);
        for (const [groupName, group] of Object.entries(groups || {})) {
            builder.addSubcommandGroup(g => {
                g.setName(groupName).setDescription((group.description || groupName).slice(0, 100));
                for (const [subName, sub] of Object.entries(group.subs)) addSub(g, subName, sub);
                return g;
            });
        }
    } else {
        for (const o of orderOpts(def.options)) addOption(builder, o);
    }

    const resolve = (groupName, subName) => {
        if (!subs && !groups) return def;
        const group = groupName ? (groups || {})[groupName] : null;
        const sub = group ? group.subs[subName] : (subs || {})[subName];
        if (!sub) return null;
        return { ...sub, perms: sub.perms || (group && group.perms) || def.perms, botPerms: sub.botPerms || (group && group.botPerms) || def.botPerms };
    };

    // permission checks run BEFORE argument parsing so unauthorised users never get argument hints
    const precheck = (ctx, spec) => {
        ctx.requirePerms(spec.perms || []);
        if (spec.botPerms) ctx.requireBotPerms(spec.botPerms);
    };

    const handleError = async (ctx, e) => {
        if (e instanceof UserError) return ctx.error(e.message).catch(() => {});
        console.error(`Error in /${name}:`, e);
        const msg = e && e.message ? e.message : 'Unknown error';
        return ctx.error(`❌ Something went wrong: ${msg}`).catch(() => {});
    };

    const lines = (prefix, map) => Object.entries(map).map(([s, sub]) => `» **${prefix} ${s}**\n› ${sub.description}`);

    const helpEmbed = (message, groupName) => {
        let body;
        if (groupName) body = lines(`${name} ${groupName}`, groups[groupName].subs).join('\n\n');
        else if (def.help) body = typeof def.help === 'function' ? def.help() : def.help;
        else {
            body = [...lines(name, subs || {}), ...Object.entries(groups || {}).flatMap(([g, grp]) => lines(`${name} ${g}`, grp.subs))].join('\n\n');
        }
        return new EmbedBuilder().setColor('#2b2d31')
            .setDescription(`\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n${body}`.slice(0, 4096))
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });
    };

    return {
        data: builder,
        async execute(interaction) {
            const ctx = slashCtx(interaction);
            try {
                const groupName = groups ? interaction.options.getSubcommandGroup(false) : null;
                const subName = (subs || groups) ? interaction.options.getSubcommand() : null;
                const spec = resolve(groupName, subName);
                precheck(ctx, spec);
                const p = readSlashParams(interaction, spec.options || []);
                await spec.run(ctx, p);
            } catch (e) { await handleError(ctx, e); }
        },
        async executeMessage(message, args) {
            const ctx = messageCtx(message);
            try {
                let spec = def;
                let rest = args;
                let groupName = null;
                let subName = null;
                if (subs || groups) {
                    const first = (args[0] || '').toLowerCase();
                    if (groups && groups[first]) {
                        groupName = first;
                        subName = (args[1] || '').toLowerCase();
                        rest = args.slice(2);
                    } else {
                        subName = first;
                        rest = args.slice(1);
                    }
                    spec = resolve(groupName, subName);
                    if (!spec) return await message.reply({ embeds: [helpEmbed(message, groupName)] });
                }
                precheck(ctx, spec);
                const label = groupName ? `${groupName} ${subName}` : subName;
                const p = await readMessageParams(message, rest, spec.options || [], usageOf(name, spec.options, label));
                await spec.run(ctx, p);
            } catch (e) { await handleError(ctx, e); }
        }
    };
}

module.exports = { makeCommand, UserError, parseDuration, formatDuration, sendTemp, isPrivileged, idFrom, box, COLORS };
