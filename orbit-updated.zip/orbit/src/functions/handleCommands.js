const fs = require('fs');

module.exports = (client) => {
    client.handleCommands = async (commandFolders, path) => {
        client.commandArray = [];
        for (const folder of commandFolders) {
            const commandFiles = fs.readdirSync(`${path}/${folder}`).filter(file => file.endsWith('.js'));
            for (const file of commandFiles) {
                const commandOrArray = require(`../commands/${folder}/${file}`);

                const commands = Array.isArray(commandOrArray) ? commandOrArray : [commandOrArray];

                for (const command of commands) {
                    if (!command) {
                        continue;
                    }

                    // If command has data property, register it as slash command
                    if (command.data && command.data.name) {
                        command.folder = folder;
                        client.commands.set(command.data.name, command);
                        client.commandArray.push(command.data.toJSON());
                    } 
                    // If command has name but no data, register for prefix only (no slash)
                    else if (command.name) {
                        command.folder = folder;
                        client.commands.set(command.name, command);
                    }
                }
            }
        }
    };
};
