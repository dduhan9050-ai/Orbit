// Giveaway logic shared by the giveaway commands and the "check every 10s" timer in ready.js.
const fs = require('fs');
const path = require('path');
const { EmbedBuilder } = require('discord.js');

const giveawayPath = path.join(__dirname, '../data/giveaways.json');
const ending = new Set();

function load() {
    try { return JSON.parse(fs.readFileSync(giveawayPath, 'utf8')) || {}; } catch { return {}; }
}

function save(data) {
    fs.writeFileSync(giveawayPath, JSON.stringify(data, null, 2));
}

function pick(list, count) {
    const pool = [...list];
    const winners = [];
    while (winners.length < count && pool.length) {
        winners.push(pool.splice(Math.floor(Math.random() * pool.length), 1)[0]);
    }
    return winners;
}

async function fetchEntrants(message) {
    const reaction = message.reactions.cache.get('🎉');
    if (!reaction) return [];
    const users = [];
    let after;
    for (;;) {
        const batch = await reaction.users.fetch({ limit: 100, after });
        if (!batch.size) break;
        for (const u of batch.values()) if (!u.bot) users.push(u);
        after = batch.last().id;
        if (batch.size < 100) break;
    }
    return users;
}

function runningEmbed(prize, winners, hostId, endTime) {
    return new EmbedBuilder()
        .setTitle('New Giveaway 🎉')
        .setDescription(
            `✅ **${prize}**\n\n` +
            `• Winner Count : ${winners}\n` +
            `• Hosted By : <@${hostId}>\n\n` +
            `• React with 🎉 to Participate\n\n` +
            `Ends at • <t:${Math.floor(endTime / 1000)}:R>`
        )
        .setColor('#2b2d31');
}

function endedEmbed(prize, winnerList, hostId) {
    return new EmbedBuilder()
        .setTitle('Giveaway Ended 🎉')
        .setDescription(
            `✅ **${prize}**\n\n` +
            `• Winner(s): ${winnerList}\n` +
            `• Hosted By: <@${hostId}>`
        )
        .setColor('#ff0000');
}

async function create(channel, hostId, durationMs, durationLabel, winners, prize) {
    const endTime = Date.now() + durationMs;
    const msg = await channel.send({ embeds: [runningEmbed(prize, winners, hostId, endTime)] });
    await msg.react('🎉');
    const data = load();
    if (!data[channel.guild.id]) data[channel.guild.id] = {};
    data[channel.guild.id][msg.id] = {
        prize, winners, duration: durationLabel, channelId: channel.id, hostId, endTime, ended: false,
    };
    save(data);
    return msg;
}

/** End a giveaway now. Returns { ok, error?, winners? }. */
async function end(client, guildId, messageId) {
    const key = `${guildId}:${messageId}`;
    if (ending.has(key)) return { ok: false, error: 'This giveaway is already being ended.' };
    ending.add(key);
    try {
        const data = load();
        const g = data[guildId] && data[guildId][messageId];
        if (!g) return { ok: false, error: 'Giveaway not found.' };
        if (g.ended) return { ok: false, error: 'This giveaway has already ended. Use the reroll command to pick new winners.' };

        const guild = client.guilds.cache.get(guildId);
        const channel = guild && guild.channels.cache.get(g.channelId);
        if (!channel) return { ok: false, error: 'Giveaway channel not found.' };

        const msg = await channel.messages.fetch(messageId).catch(() => null);
        if (!msg) {
            g.ended = true; // message was deleted, stop checking it
            save(data);
            return { ok: false, error: 'The giveaway message no longer exists.' };
        }

        const entrants = await fetchEntrants(msg);
        const winners = pick(entrants, Math.min(g.winners, entrants.length));
        const list = winners.map(w => w.toString()).join(', ');

        await msg.edit({ embeds: [endedEmbed(g.prize, winners.length ? list : 'No valid entries', g.hostId)] }).catch(() => {});
        await channel.send({
            content: winners.length
                ? `Congratulations ${list}! You won **${g.prize}**! 🎉`
                : `No one entered the giveaway for **${g.prize}**!`,
            allowedMentions: { users: winners.map(w => w.id) },
        });

        g.ended = true;
        g.winnerIds = winners.map(w => w.id);
        save(data);
        return { ok: true, winners };
    } catch (error) {
        console.error('Error ending giveaway:', error);
        return { ok: false, error: 'Failed to end the giveaway.' };
    } finally {
        ending.delete(key);
    }
}

async function reroll(client, guildId, messageId) {
    const data = load();
    const g = data[guildId] && data[guildId][messageId];
    if (!g) return { ok: false, error: 'Giveaway not found.' };
    if (!g.ended) return { ok: false, error: 'This giveaway has not ended yet. Use the end command first.' };

    const guild = client.guilds.cache.get(guildId);
    const channel = guild && guild.channels.cache.get(g.channelId);
    if (!channel) return { ok: false, error: 'Giveaway channel not found.' };
    const msg = await channel.messages.fetch(messageId).catch(() => null);
    if (!msg) return { ok: false, error: 'The giveaway message no longer exists.' };

    const entrants = await fetchEntrants(msg);
    if (!entrants.length) return { ok: false, error: 'No valid entries to reroll.' };
    const winners = pick(entrants, Math.min(g.winners, entrants.length));
    await channel.send({
        content: `🎉 New winner(s): ${winners.map(w => w.toString()).join(', ')}! You won **${g.prize}**!`,
        allowedMentions: { users: winners.map(w => w.id) },
    });
    return { ok: true, winners };
}

async function remove(client, guildId, messageId) {
    const data = load();
    const g = data[guildId] && data[guildId][messageId];
    if (!g) return { ok: false, error: 'Giveaway not found.' };
    const guild = client.guilds.cache.get(guildId);
    const channel = guild && guild.channels.cache.get(g.channelId);
    if (channel) {
        const msg = await channel.messages.fetch(messageId).catch(() => null);
        if (msg) await msg.delete().catch(() => {});
    }
    delete data[guildId][messageId];
    save(data);
    return { ok: true };
}

function listActive(guildId) {
    const data = load();
    return Object.entries(data[guildId] || {}).filter(([, g]) => !g.ended);
}

/** Called every 10s from ready.js: ends anything that is due. */
async function checkDue(client) {
    const data = load();
    for (const guildId of Object.keys(data)) {
        for (const [messageId, g] of Object.entries(data[guildId])) {
            if (g.ended || !g.endTime || Date.now() < g.endTime) continue;
            await end(client, guildId, messageId);
        }
    }
}

module.exports = { create, end, reroll, remove, listActive, checkDue };
