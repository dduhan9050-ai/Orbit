const fs = require('fs');
const path = require('path');

const DATA_PATH = path.join(__dirname, '..', 'data', 'vcrole.json');

function readAll() {
    try {
        if (fs.existsSync(DATA_PATH)) return JSON.parse(fs.readFileSync(DATA_PATH, 'utf8')) || {};
    } catch (e) { /* ignore corrupt file */ }
    return {};
}

function writeAll(data) {
    fs.mkdirSync(path.dirname(DATA_PATH), { recursive: true });
    fs.writeFileSync(DATA_PATH, JSON.stringify(data, null, 2), 'utf8');
}

/** { [voiceChannelId]: roleId } for a guild */
function get(guildId) {
    return readAll()[guildId] || {};
}

function set(guildId, channelId, roleId) {
    const all = readAll();
    all[guildId] = { ...(all[guildId] || {}), [channelId]: roleId };
    writeAll(all);
}

function clear(guildId) {
    const all = readAll();
    const had = Object.keys(all[guildId] || {}).length;
    delete all[guildId];
    writeAll(all);
    return had;
}

module.exports = { get, set, clear };
