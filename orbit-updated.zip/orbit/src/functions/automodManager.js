const fs = require('fs');
const path = require('path');

const DATA_PATH = path.join(__dirname, '..', 'data', 'automod.json');

function ensureDataFile() {
    const dir = path.dirname(DATA_PATH);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(DATA_PATH)) fs.writeFileSync(DATA_PATH, JSON.stringify({}), 'utf8');
}

ensureDataFile();

let store = {};
try {
    store = JSON.parse(fs.readFileSync(DATA_PATH, 'utf8')) || {};
} catch (e) {
    store = {};
}

function saveStore() {
    fs.writeFileSync(DATA_PATH, JSON.stringify(store, null, 2), 'utf8');
}

function defaultGuildData() {
    return {
        enabled: false,
        punishment: 'mute', // ban, mute, kick
        logging: null,
        filters: {
            heat: { enabled: false, threshold: 5, decay: 2 },
            automute: { enabled: false, threshold: 10 },
            links: { enabled: false },
            invites: { enabled: false },
            mentions: { enabled: false, threshold: 5 },
            caps: { enabled: false, threshold: 70 },
            spoilers: { enabled: false, threshold: 3 },
            newlines: { enabled: false, threshold: 10 }
        },
        ignore: { channels: [], roles: [], users: [] },
        blacklist: {
            words: [],
            punishment: 'mute',
            whitelisted_channels: [],
            whitelisted_roles: []
        }
    };
}

// Fill in anything missing (older saved configs / partial resets) without touching existing values
function normalize(data) {
    const def = defaultGuildData();
    for (const key of Object.keys(def)) {
        if (data[key] === undefined || data[key] === null && key !== 'logging') data[key] = def[key];
    }
    for (const f of Object.keys(def.filters)) {
        data.filters[f] = { ...def.filters[f], ...(data.filters[f] || {}) };
    }
    for (const k of Object.keys(def.ignore)) {
        if (!Array.isArray(data.ignore[k])) data.ignore[k] = [];
    }
    for (const k of Object.keys(def.blacklist)) {
        if (data.blacklist[k] === undefined) data.blacklist[k] = def.blacklist[k];
    }
    return data;
}

function getGuildData(guildId) {
    if (!store[guildId]) {
        store[guildId] = defaultGuildData();
        saveStore();
    } else {
        normalize(store[guildId]);
    }
    return store[guildId];
}

function setConfig(guildId, config) {
    const data = getGuildData(guildId);
    store[guildId] = { ...data, ...config };
    saveStore();
}

function setFilter(guildId, filterName, settings) {
    const data = getGuildData(guildId);
    data.filters[filterName] = { ...data.filters[filterName], ...settings };
    saveStore();
}

function resetGuild(guildId) {
    store[guildId] = defaultGuildData();
    saveStore();
    return store[guildId];
}

module.exports = {
    getGuildData,
    setConfig,
    setFilter,
    resetGuild,
    defaultGuildData
};
