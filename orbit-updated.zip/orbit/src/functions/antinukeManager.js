const fs = require('fs');
const path = require('path');

const DATA_PATH = path.join(__dirname, '..', 'data', 'antinuke.json');

function ensureDataFile() {
    const dir = path.dirname(DATA_PATH);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(DATA_PATH)) fs.writeFileSync(DATA_PATH, JSON.stringify({}), 'utf8');
}

ensureDataFile();

let store = {};
try {
    store = JSON.parse(fs.readFileSync(DATA_PATH, 'utf8')) || {};
} catch (e) {
    store = {};
}

// In-memory heat map: { guildId: { userId: { heat: number, last: timestamp } } }
const heatMap = {};

const DEFAULT_CONFIG = {
    enabled: false,
    loggingChannel: null,
    whitelist: [],
    // filters: keys representing protected actions
    filters: {},
    minuteLimit: 10,
    hourLimit: 50,
    thresholdHeat: 100,
    heatPerAction: 10,
    decayIntervalSec: 60,
    decayAmount: 1,
    zplus: false,
    panicMode: false,
    panicDuration: 300, // seconds Z+ stays active after panic mode triggers
    mainRoles: [],
    autoRecovery: false
};

const clone = (o) => JSON.parse(JSON.stringify(o));

// Initialize default filter set
const DEFAULT_FILTERS = {
    ban: false,
    kick: false,
    prune: false,
    memberUpdate: false,
    roleCreate: false,
    roleDelete: false,
    roleUpdate: false,
    channelCreate: false,
    channelDelete: false,
    channelUpdate: false,
    webhookCreate: false,
    webhookDelete: false,
    webhookUpdate: false,
    botAdd: false,
    guildUpdate: false,
    mentionSpam: false
};

function saveStore() {
    fs.writeFileSync(DATA_PATH, JSON.stringify(store, null, 2), 'utf8');
}

function getConfig(guildId) {
    // deep clone so guilds never share the same arrays/objects as DEFAULT_CONFIG
    if (!store[guildId]) store[guildId] = clone(DEFAULT_CONFIG);
    // ensure filters exist
    if (!store[guildId].filters || Object.keys(store[guildId].filters).length === 0) {
        store[guildId].filters = Object.assign({}, DEFAULT_FILTERS);
        saveStore();
    }
    if (!Array.isArray(store[guildId].whitelist)) store[guildId].whitelist = [];
    return store[guildId];
}

function setConfig(guildId, partial) {
    const cfg = getConfig(guildId);
    store[guildId] = Object.assign({}, cfg, clone(partial));
    saveStore();
    return store[guildId];
}

function resetConfig(guildId) {
    store[guildId] = clone(DEFAULT_CONFIG);
    store[guildId].filters = Object.assign({}, DEFAULT_FILTERS);
    saveStore();
    return store[guildId];
}

// Z+ lockdown: tighten limits, remember the previous limits so they can be restored
function toggleZplus(guildId) {
    const cfg = getConfig(guildId);
    if (!cfg.zplus) {
        const backup = {
            minuteLimit: cfg.minuteLimit,
            hourLimit: cfg.hourLimit,
            heatPerAction: cfg.heatPerAction,
            thresholdHeat: cfg.thresholdHeat
        };
        setConfig(guildId, { zplus: true, prevBackup: backup, minuteLimit: 1, hourLimit: 1, heatPerAction: 100, thresholdHeat: 100 });
        return true;
    }
    const prev = cfg.prevBackup || {
        minuteLimit: DEFAULT_CONFIG.minuteLimit,
        hourLimit: DEFAULT_CONFIG.hourLimit,
        heatPerAction: DEFAULT_CONFIG.heatPerAction,
        thresholdHeat: DEFAULT_CONFIG.thresholdHeat
    };
    setConfig(guildId, Object.assign({}, prev, { zplus: false }));
    delete store[guildId].prevBackup;
    saveStore();
    return false;
}

const panicTimers = {};

// Called by antinuke handlers when heat crosses the threshold while panic mode is on
function triggerPanic(guildId) {
    const cfg = getConfig(guildId);
    if (cfg.zplus) return false;
    toggleZplus(guildId);
    clearTimeout(panicTimers[guildId]);
    panicTimers[guildId] = setTimeout(() => {
        delete panicTimers[guildId];
        if (getConfig(guildId).zplus) toggleZplus(guildId);
    }, Math.max(10, getConfig(guildId).panicDuration || 300) * 1000);
    if (panicTimers[guildId].unref) panicTimers[guildId].unref();
    return true;
}

function addToWhitelist(guildId, userId) {
    const cfg = getConfig(guildId);
    if (!cfg.whitelist) cfg.whitelist = [];
    if (!cfg.whitelist.includes(userId)) cfg.whitelist.push(userId);
    saveStore();
}

function removeFromWhitelist(guildId, userId) {
    const cfg = getConfig(guildId);
    if (!cfg.whitelist) return;
    cfg.whitelist = cfg.whitelist.filter(id => id !== userId);
    saveStore();
}

function toggleFilter(guildId, filterName) {
    const cfg = getConfig(guildId);
    if (!cfg.filters) cfg.filters = Object.assign({}, DEFAULT_FILTERS);
    cfg.filters[filterName] = !cfg.filters[filterName];
    saveStore();
    return cfg.filters[filterName];
}

function isFilterEnabled(guildId, filterName) {
    const cfg = getConfig(guildId);
    if (!cfg.filters) return false;
    return !!cfg.filters[filterName];
}

function addHeat(guildId, userId, amount) {
    if (!heatMap[guildId]) heatMap[guildId] = {};
    if (!heatMap[guildId][userId]) heatMap[guildId][userId] = { heat: 0, last: Date.now() };

    // Apply decay since last
    const now = Date.now();
    const entry = heatMap[guildId][userId];
    const cfg = getConfig(guildId);
    const elapsedSec = Math.floor((now - entry.last) / 1000);
    if (elapsedSec >= cfg.decayIntervalSec) {
        const steps = Math.floor(elapsedSec / cfg.decayIntervalSec);
        const decay = steps * cfg.decayAmount;
        entry.heat = Math.max(0, entry.heat - decay);
    }

    entry.heat += amount;
    entry.last = now;
    return entry.heat;
}

function getHeat(guildId, userId) {
    if (!heatMap[guildId] || !heatMap[guildId][userId]) return 0;
    // apply decay on read
    const entry = heatMap[guildId][userId];
    const now = Date.now();
    const cfg = getConfig(guildId);
    const elapsedSec = Math.floor((now - entry.last) / 1000);
    if (elapsedSec >= cfg.decayIntervalSec) {
        const steps = Math.floor(elapsedSec / cfg.decayIntervalSec);
        const decay = steps * cfg.decayAmount;
        entry.heat = Math.max(0, entry.heat - decay);
        entry.last = now;
    }
    return entry.heat;
}

module.exports = {
    getConfig,
    setConfig,
    resetConfig,
    toggleZplus,
    triggerPanic,
    addToWhitelist,
    removeFromWhitelist,
    addHeat,
    getHeat,
    toggleFilter,
    isFilterEnabled,
    DEFAULT_CONFIG,
    DEFAULT_FILTERS
};
