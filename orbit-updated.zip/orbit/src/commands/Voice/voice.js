const { EmbedBuilder, PermissionFlagsBits: P, ChannelType, OverwriteType } = require('discord.js');
const { makeCommand, UserError, sendTemp } = require('../../functions/commandKit');
const { passesTopCheck } = require('../../functions/permissionChecker');
const vcRoles = require('../../functions/vcRoleManager');

const VOICE_TYPES = [ChannelType.GuildVoice, ChannelType.GuildStageVoice];
const isVoice = (ch) => !!ch && VOICE_TYPES.includes(ch.type);
const MSG_TTL = 3000;

// ------------------------------------------------------------------ helpers
const userOpt = { name: 'user', type: 'user', description: 'The user', required: true };
const channelOpt = (description = 'The channel', required = false) =>
    ({ name: 'channel', type: 'channel', description, required, channelTypes: VOICE_TYPES });

/** The voice channel the invoker is sitting in. */
function ownChannel(ctx) {
    const ch = ctx.member.voice && ctx.member.voice.channel;
    if (!ch) throw new UserError('You must be in a voice channel.');
    return ch;
}

/** Explicit channel option, else the invoker's own channel. */
function pickChannel(ctx, ch) {
    const channel = ch || (ctx.member.voice && ctx.member.voice.channel);
    if (!isVoice(channel)) throw new UserError('Invalid voice channel. You must be in a voice channel or mention one.');
    return channel;
}

/** Member option -> guild member who is currently in voice. */
function connectedMember(p) {
    const member = p.user.member;
    if (!member) throw new UserError('That user is not in this server.');
    if (!member.voice.channel) throw new UserError('This user is not in a voice channel.');
    return member;
}

/** Hierarchy guard for disruptive single-user actions (kick / mute / deafen / ban). */
function guardTarget(ctx, member, verb) {
    if (member.id === ctx.member.id) throw new UserError(`You cannot ${verb} yourself.`);
    if (member.id === ctx.client.user.id) throw new UserError(`I can't ${verb} myself.`);
    if (!canActOn(ctx, member)) throw new UserError(`You cannot ${verb} someone with an equal or higher role than yours.`);
}

function canActOn(ctx, member) {
    if (ctx.isPrivileged()) return member.id !== ctx.guild.ownerId || ctx.member.id === ctx.guild.ownerId;
    if (member.id === ctx.guild.ownerId) return false;
    if (ctx.member.roles.highest.comparePositionTo(member.roles.highest) <= 0) return false;
    return passesTopCheck(ctx.member, member, ctx.guild);
}

/** Run `apply` for every member of `channel` except the invoker (and the bot). */
async function bulk(ctx, channel, { hierarchy, apply, done }) {
    await ctx.defer();
    let ok = 0, skipped = 0, failed = 0;
    for (const member of channel.members.values()) {
        if (member.id === ctx.member.id || member.id === ctx.client.user.id) continue;
        if (hierarchy && !canActOn(ctx, member)) { skipped++; continue; }
        try { await apply(member); ok++; } catch (e) { failed++; }
    }
    const extra = (skipped ? ` (${skipped} skipped — equal/higher role)` : '') + (failed ? ` (${failed} failed)` : '');
    await sendTemp(ctx, 'success', `${done(ok, channel)}${extra}`, MSG_TTL);
}

/** Edit @everyone's overwrite on a channel (value false = deny, null = reset). */
async function setEveryone(ctx, channel, perm, value) {
    ctx.requireBotPerms([P.ManageRoles], channel);
    await channel.permissionOverwrites.edit(ctx.guild.roles.everyone, { [perm]: value }, { reason: `Voice command by ${ctx.member.user.tag}` });
}

const MOVE = { perms: [P.MoveMembers], botPerms: [P.MoveMembers] };
const MUTE = { perms: [P.MuteMembers], botPerms: [P.MuteMembers] };
const DEAFEN = { perms: [P.DeafenMembers], botPerms: [P.DeafenMembers] };
const CHANNEL = { perms: [P.ManageChannels], botPerms: [P.ManageRoles] };

// ------------------------------------------------------------------ /voice
const voice = makeCommand({
    name: 'voice',
    description: 'Voice channel moderation and management',
    help:
        '» **voice lock/unlock**\n› Lock/unlock your VC.\n\n' +
        '» **voice private/unprivate**\n› Hide/show your VC.\n\n' +
        '» **voice kick/kickall**\n› Kick user(s) from VC.\n\n' +
        '» **voice mute/unmute/muteall/unmuteall**\n› Mute controls.\n\n' +
        '» **voice deafen/undeafen/deafenall/undeafenall**\n› Deafen controls.\n\n' +
        '» **voice move/pull/moveall/pullall**\n› Move users between VCs.\n\n' +
        '» **voice ban/unban/banlist**\n› Ban users from specific VC.',
    subs: {
        // ---- bulk actions
        moveall: {
            description: 'Move all members to another channel', ...MOVE,
            options: [channelOpt('Target channel', true)],
            async run(ctx, p) {
                const source = ownChannel(ctx);
                const target = p.channel;
                if (!isVoice(target)) throw new UserError('Invalid voice channel provided.');
                if (target.id === source.id) throw new UserError('Those members are already in that channel.');
                await bulk(ctx, source, {
                    apply: m => m.voice.setChannel(target),
                    done: (n) => `✅ Moved **${n}** member(s) to ${target.name}`
                });
            }
        },
        pullall: {
            description: 'Pull all members from all VCs to your current VC', ...MOVE,
            async run(ctx) {
                const target = ownChannel(ctx);
                await ctx.defer();
                let ok = 0, failed = 0;
                for (const channel of ctx.guild.channels.cache.filter(c => isVoice(c) && c.id !== target.id).values()) {
                    for (const member of channel.members.values()) {
                        if (member.id === ctx.client.user.id) continue;
                        try { await member.voice.setChannel(target); ok++; } catch (e) { failed++; }
                    }
                }
                await sendTemp(ctx, 'success', `✅ Pulled **${ok}** member(s) to ${target.name}${failed ? ` (${failed} failed)` : ''}`, MSG_TTL);
            }
        },
        kickall: {
            description: 'Kick all members from your current VC', ...MOVE,
            async run(ctx) {
                await bulk(ctx, ownChannel(ctx), {
                    hierarchy: true,
                    apply: m => m.voice.disconnect(),
                    done: (n, ch) => `✅ Kicked **${n}** member(s) from ${ch.name}`
                });
            }
        },
        muteall: {
            description: 'Mute all members in your current VC', ...MUTE,
            async run(ctx) {
                await bulk(ctx, ownChannel(ctx), {
                    hierarchy: true, apply: m => m.voice.setMute(true),
                    done: (n, ch) => `🔇 Muted **${n}** member(s) in ${ch.name}`
                });
            }
        },
        unmuteall: {
            description: 'Unmute all members in your current VC', ...MUTE,
            async run(ctx) {
                await bulk(ctx, ownChannel(ctx), {
                    apply: m => m.voice.setMute(false),
                    done: (n, ch) => `🔊 Unmuted **${n}** member(s) in ${ch.name}`
                });
            }
        },
        deafenall: {
            description: 'Deafen all members in your current VC', ...DEAFEN,
            async run(ctx) {
                await bulk(ctx, ownChannel(ctx), {
                    hierarchy: true, apply: m => m.voice.setDeaf(true),
                    done: (n, ch) => `🔇 Deafened **${n}** member(s) in ${ch.name}`
                });
            }
        },
        undeafenall: {
            description: 'Undeafen all members in your current VC', ...DEAFEN,
            async run(ctx) {
                await bulk(ctx, ownChannel(ctx), {
                    apply: m => m.voice.setDeaf(false),
                    done: (n, ch) => `🔊 Undeafened **${n}** member(s) in ${ch.name}`
                });
            }
        },

        // ---- channel bans
        ban: {
            description: 'Ban a user from a voice channel', ...CHANNEL,
            options: [userOpt, channelOpt()],
            async run(ctx, p) {
                const member = p.user.member;
                if (!member) throw new UserError('That user is not in this server.');
                guardTarget(ctx, member, 'ban');
                const channel = pickChannel(ctx, p.channel);
                ctx.requireBotPerms([P.ManageRoles], channel);
                await channel.permissionOverwrites.edit(member, { Connect: false }, { reason: `Voice ban by ${ctx.member.user.tag}` });
                let note = '';
                if (member.voice.channelId === channel.id) {
                    try { await member.voice.disconnect(); } catch (e) { note = ' (I could not disconnect them — missing Move Members)'; }
                }
                await sendTemp(ctx, 'success', `🚫 Banned **${member.user.username}** from ${channel.name}${note}`, MSG_TTL);
            }
        },
        unban: {
            description: 'Unban a user from a voice channel', ...CHANNEL,
            options: [userOpt, channelOpt()],
            async run(ctx, p) {
                const member = p.user.member;
                if (!member) throw new UserError('That user is not in this server.');
                const channel = pickChannel(ctx, p.channel);
                ctx.requireBotPerms([P.ManageRoles], channel);
                const existing = channel.permissionOverwrites.cache.get(member.id);
                if (!existing || !existing.deny.has(P.Connect)) throw new UserError(`**${member.user.username}** is not banned from ${channel.name}.`);
                await channel.permissionOverwrites.edit(member, { Connect: null }, { reason: `Voice unban by ${ctx.member.user.tag}` });
                // drop the overwrite entirely if nothing else is left in it
                const after = channel.permissionOverwrites.cache.get(member.id);
                if (after && after.allow.bitfield === 0n && after.deny.bitfield === 0n) await after.delete().catch(() => {});
                await sendTemp(ctx, 'success', `✅ Unbanned **${member.user.username}** from ${channel.name}`, MSG_TTL);
            }
        },
        banlist: {
            description: 'Show the voice ban list',
            options: [channelOpt()],
            async run(ctx, p) {
                const channel = pickChannel(ctx, p.channel);
                const banned = channel.permissionOverwrites.cache.filter(o => o.type === OverwriteType.Member && o.deny.has(P.Connect));
                if (!banned.size) return ctx.info(`No banned users in ${channel.name}`);
                const embed = new EmbedBuilder()
                    .setTitle(`Banned Users in ${channel.name}`)
                    .setDescription(banned.map(o => `<@${o.id}>`).join(', ').slice(0, 4096))
                    .setColor('#2b2d31');
                await ctx.send({ embeds: [embed] });
            }
        },

        // ---- single user actions
        move: {
            description: 'Move a user to another channel', ...MOVE,
            options: [userOpt, channelOpt('Target channel', true)],
            async run(ctx, p) {
                const member = connectedMember(p);
                if (!isVoice(p.channel)) throw new UserError('Invalid voice channel provided.');
                if (member.voice.channelId === p.channel.id) throw new UserError('That user is already in that channel.');
                await member.voice.setChannel(p.channel);
                await sendTemp(ctx, 'success', `✅ Moved **${member.user.username}** to ${p.channel.name}`, MSG_TTL);
            }
        },
        pull: {
            description: 'Pull a user to your current VC', ...MOVE,
            options: [userOpt],
            async run(ctx, p) {
                const own = ownChannel(ctx);
                const member = connectedMember(p);
                if (member.id === ctx.member.id) throw new UserError('You cannot pull yourself.');
                if (member.voice.channelId === own.id) throw new UserError('That user is already in your voice channel.');
                await member.voice.setChannel(own);
                await sendTemp(ctx, 'success', `✅ Pulled **${member.user.username}** to your voice channel`, MSG_TTL);
            }
        },
        mute: {
            description: 'Mute a user in voice', ...MUTE,
            options: [userOpt],
            async run(ctx, p) {
                const member = connectedMember(p);
                guardTarget(ctx, member, 'mute');
                await member.voice.setMute(true);
                await sendTemp(ctx, 'success', `🔇 Muted **${member.user.username}**`, MSG_TTL);
            }
        },
        unmute: {
            description: 'Unmute a user in voice', ...MUTE,
            options: [userOpt],
            async run(ctx, p) {
                const member = connectedMember(p);
                await member.voice.setMute(false);
                await sendTemp(ctx, 'success', `🔊 Unmuted **${member.user.username}**`, MSG_TTL);
            }
        },
        deafen: {
            description: 'Deafen a user in voice', ...DEAFEN,
            options: [userOpt],
            async run(ctx, p) {
                const member = connectedMember(p);
                guardTarget(ctx, member, 'deafen');
                await member.voice.setDeaf(true);
                await sendTemp(ctx, 'success', `🔇 Deafened **${member.user.username}**`, MSG_TTL);
            }
        },
        undeafen: {
            description: 'Undeafen a user in voice', ...DEAFEN,
            options: [userOpt],
            async run(ctx, p) {
                const member = connectedMember(p);
                await member.voice.setDeaf(false);
                await sendTemp(ctx, 'success', `🔊 Undeafened **${member.user.username}**`, MSG_TTL);
            }
        },
        kick: {
            description: 'Kick a user from voice', ...MOVE,
            options: [userOpt],
            async run(ctx, p) {
                const member = connectedMember(p);
                guardTarget(ctx, member, 'kick');
                await member.voice.disconnect();
                await sendTemp(ctx, 'success', `✅ Kicked **${member.user.username}** from voice`, MSG_TTL);
            }
        },

        // ---- channel state
        lock: {
            description: 'Lock a voice channel', ...CHANNEL,
            options: [channelOpt()],
            async run(ctx, p) {
                const channel = pickChannel(ctx, p.channel);
                await setEveryone(ctx, channel, 'Connect', false);
                await sendTemp(ctx, 'success', `🔒 Locked ${channel.name}`, MSG_TTL);
            }
        },
        unlock: {
            description: 'Unlock a voice channel', ...CHANNEL,
            options: [channelOpt()],
            async run(ctx, p) {
                const channel = pickChannel(ctx, p.channel);
                await setEveryone(ctx, channel, 'Connect', null);
                await sendTemp(ctx, 'success', `🔓 Unlocked ${channel.name}`, MSG_TTL);
            }
        },
        private: {
            description: 'Make a voice channel private', ...CHANNEL,
            options: [channelOpt()],
            async run(ctx, p) {
                const channel = pickChannel(ctx, p.channel);
                await setEveryone(ctx, channel, 'ViewChannel', false);
                await sendTemp(ctx, 'success', `👁️ Made ${channel.name} private`, MSG_TTL);
            }
        },
        unprivate: {
            description: 'Make a voice channel public', ...CHANNEL,
            options: [channelOpt()],
            async run(ctx, p) {
                const channel = pickChannel(ctx, p.channel);
                await setEveryone(ctx, channel, 'ViewChannel', null);
                await sendTemp(ctx, 'success', `👁️ Made ${channel.name} public`, MSG_TTL);
            }
        }
    }
});

// ------------------------------------------------------------------ /vcrole
const vcrole = makeCommand({
    name: 'vcrole',
    description: 'Configure roles rewarded for joining voice channels',
    perms: [P.ManageRoles],
    help:
        '» **vcrole set #voice @role**\n› Give a role to members while they are in a voice channel.\n\n' +
        '» **vcrole show**\n› Show the current VC role configuration.\n\n' +
        '» **vcrole clear**\n› Remove all VC role configurations.',
    subs: {
        clear: {
            description: 'Clear all VC role configurations',
            async run(ctx) {
                const n = vcRoles.clear(ctx.guild.id);
                if (!n) throw new UserError('There are no VC roles configured.');
                await ctx.success(`Cleared **${n}** VC role configuration(s).`);
            }
        },
        show: {
            description: 'Show current VC role configurations',
            async run(ctx) {
                const entries = Object.entries(vcRoles.get(ctx.guild.id));
                if (!entries.length) return ctx.info('No VC roles are configured. Use `vcrole set #voice @role`.');
                const lines = entries.map(([chId, roleId]) => {
                    const ch = ctx.guild.channels.cache.has(chId) ? `<#${chId}>` : `~~${chId}~~ *(deleted)*`;
                    const role = ctx.guild.roles.cache.has(roleId) ? `<@&${roleId}>` : `~~${roleId}~~ *(deleted)*`;
                    return `${ch} → ${role}`;
                });
                await ctx.send({ embeds: [new EmbedBuilder().setTitle('🎤 VC Roles').setColor('#2b2d31').setDescription(lines.join('\n').slice(0, 4096))] });
            }
        },
        set: {
            description: 'Set a role for a voice channel',
            botPerms: [P.ManageRoles],
            options: [
                { name: 'channel', type: 'channel', description: 'The voice channel', required: true, channelTypes: VOICE_TYPES },
                { name: 'role', type: 'role', description: 'The role to award', required: true }
            ],
            async run(ctx, p) {
                if (!isVoice(p.channel)) throw new UserError('Please choose a voice channel.');
                ctx.checkRole(p.role, 'award');
                vcRoles.set(ctx.guild.id, p.channel.id, p.role.id);
                await ctx.success(`Members joining ${p.channel} will now receive ${p.role}.`);
            }
        }
    }
});

module.exports = [vcrole, voice];
