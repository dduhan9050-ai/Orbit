const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, MessageFlags } = require('discord.js');
const automod = require('../../functions/automodManager');
const permit = require('../../functions/permitManager');

// filter name -> { label, option (name of the number option, or null), min, max, unit }
const FILTERS = {
    heat: { label: 'Anti-spam (heat)', option: 'limit', desc: 'Max heat before trigger (a message ≈ 1 heat, decays over time)', min: 1, max: 100, unit: 'heat' },
    automute: { label: 'Automute', option: 'threshold', desc: 'Alerts before the punishment is applied', min: 1, max: 100, unit: 'alerts' },
    links: { label: 'Links', option: null },
    invites: { label: 'Invites', option: null },
    mentions: { label: 'Mass mentions', option: 'threshold', desc: 'Max mentions per message', min: 2, max: 50, unit: 'mentions' },
    caps: { label: 'Caps', option: 'percent', desc: 'Max percentage of capital letters', min: 10, max: 100, unit: '%' },
    spoilers: { label: 'Spoilers', option: 'threshold', desc: 'Max spoilers per message', min: 1, max: 50, unit: 'spoilers' },
    newlines: { label: 'New lines', option: 'threshold', desc: 'Max new lines per message', min: 2, max: 100, unit: 'lines' }
};

const IGNORE_TYPES = ['user', 'role', 'channel'];

function buildSlash() {
    const b = new SlashCommandBuilder()
        .setName('automod')
        .setDescription('Automod: Configure server automation filters')
        .addSubcommand(s => s.setName('enable').setDescription('Enable automod'))
        .addSubcommand(s => s.setName('disable').setDescription('Disable automod'))
        .addSubcommand(s => s.setName('config').setDescription('Show automod configuration'))
        .addSubcommand(s => s.setName('reset').setDescription('Reset automod settings'))
        .addSubcommand(s => s.setName('logging').setDescription('Configure logging channel').addChannelOption(o => o.setName('channel').setDescription('The channel').setRequired(true)))
        .addSubcommand(s => s.setName('punishment').setDescription('Configure punishment').addStringOption(o => o.setName('type').setDescription('The type').addChoices({ name: 'Ban', value: 'ban' }, { name: 'Mute', value: 'mute' }, { name: 'Kick', value: 'kick' }).setRequired(true)));

    for (const [name, f] of Object.entries(FILTERS)) {
        b.addSubcommandGroup(g => {
            g.setName(name).setDescription(`Configure ${f.label.toLowerCase()} filter`);
            g.addSubcommand(s => s.setName('enable').setDescription(`Enable ${f.label.toLowerCase()}`));
            g.addSubcommand(s => s.setName('disable').setDescription(`Disable ${f.label.toLowerCase()}`));
            if (f.option) {
                g.addSubcommand(s => s.setName('set').setDescription(`Set ${f.label.toLowerCase()} limit`)
                    .addIntegerOption(o => o.setName(f.option).setDescription(f.desc).setMinValue(f.min).setMaxValue(f.max).setRequired(true)));
            }
            return g;
        });
    }

    b.addSubcommandGroup(g => {
        g.setName('ignore').setDescription('Configure ignored targets');
        for (const t of IGNORE_TYPES) {
            const addOpt = (s) => {
                const fn = { user: 'addUserOption', role: 'addRoleOption', channel: 'addChannelOption' }[t];
                return s[fn](o => o.setName(t).setDescription(`The ${t}`).setRequired(true));
            };
            g.addSubcommand(s => addOpt(s.setName(`add_${t}`).setDescription(`Ignore a ${t}`)));
            g.addSubcommand(s => addOpt(s.setName(`remove_${t}`).setDescription(`Unignore a ${t}`)));
        }
        g.addSubcommand(s => s.setName('show').setDescription('Show ignored targets'));
        g.addSubcommand(s => s.setName('reset').setDescription('Reset ignored targets'));
        return g;
    });
    return b;
}

function configEmbed(guild, client) {
    const data = automod.getGuildData(guild.id);
    const f = data.filters;
    const line = (name) => {
        const x = f[name];
        const val = FILTERS[name].option ? ` — ${x.threshold}${FILTERS[name].unit === '%' ? '%' : ''}` : '';
        return `${x.enabled ? '✅' : '❌'} ${FILTERS[name].label}${val}`;
    };
    return new EmbedBuilder()
        .setTitle('Automod Configuration')
        .setColor('#2b2d31')
        .addFields(
            { name: 'Status', value: data.enabled ? '✅ Enabled' : '❌ Disabled', inline: true },
            { name: 'Punishment', value: data.punishment.charAt(0).toUpperCase() + data.punishment.slice(1), inline: true },
            { name: 'Logging', value: data.logging ? `<#${data.logging}>` : 'None', inline: true },
            { name: 'Filters', value: Object.keys(FILTERS).map(line).join('\n') },
            { name: 'Ignored', value: `${data.ignore.users.length} user(s), ${data.ignore.roles.length} role(s), ${data.ignore.channels.length} channel(s)`, inline: true },
            { name: 'Blacklist', value: `${data.blacklist.words.length} word(s) — ${data.blacklist.punishment}`, inline: true }
        )
        .setFooter({ text: 'Orbit™ Automod System', iconURL: client.user.displayAvatarURL() });
}

function ignoreEmbed(data) {
    return new EmbedBuilder()
        .setTitle('Automod Ignore Lists')
        .setColor('#2b2d31')
        .addFields(
            { name: 'Users', value: data.ignore.users.length ? data.ignore.users.map(id => `<@${id}>`).join(', ') : 'None' },
            { name: 'Roles', value: data.ignore.roles.length ? data.ignore.roles.map(id => `<@&${id}>`).join(', ') : 'None' },
            { name: 'Channels', value: data.ignore.channels.length ? data.ignore.channels.map(id => `<#${id}>`).join(', ') : 'None' }
        );
}

/**
 * Shared implementation for slash + prefix.
 * io.say(text, {embed}) sends the reply. `val` holds already-parsed values.
 * Returns nothing; throws string messages via io.say.
 */
async function apply(io, guild, client, group, sub, val) {
    const guildId = guild.id;

    if (!group) {
        switch (sub) {
            case 'enable': automod.setConfig(guildId, { enabled: true }); return io.say('✅ Successfully enabled automod.');
            case 'disable': automod.setConfig(guildId, { enabled: false }); return io.say('✅ Successfully disabled automod.');
            case 'reset': automod.resetGuild(guildId); return io.say('✅ Successfully reset automod settings to default.');
            case 'config': return io.say(null, configEmbed(guild, client));
            case 'logging': {
                if (!val.channel || !val.channel.isTextBased()) return io.say('❌ Please provide a text channel.');
                automod.setConfig(guildId, { logging: val.channel.id });
                return io.say(`✅ Successfully set logging channel to ${val.channel}.`);
            }
            case 'punishment': {
                if (!['ban', 'kick', 'mute'].includes(val.type)) return io.say('❌ Please provide a valid punishment type: `ban`, `kick`, or `mute`.');
                automod.setConfig(guildId, { punishment: val.type });
                return io.say(`✅ Set punishment to: **${val.type}**`);
            }
            case 'filters': {
                const data = automod.getGuildData(guildId);
                const text = Object.entries(FILTERS).map(([n, f]) => `${data.filters[n].enabled ? '✅' : '❌'} **${n}** — ${f.label}`).join('\n');
                return io.say(null, new EmbedBuilder().setTitle('Automod Filters').setDescription(text).setColor('#2b2d31'));
            }
        }
        return;
    }

    if (FILTERS[group]) {
        const f = FILTERS[group];
        if (sub === 'enable') { automod.setFilter(guildId, group, { enabled: true }); return io.say(`✅ Enabled **${f.label}**.`); }
        if (sub === 'disable') { automod.setFilter(guildId, group, { enabled: false }); return io.say(`✅ Disabled **${f.label}**.`); }
        if (sub === 'set' && f.option) {
            const n = val.number;
            if (!Number.isInteger(n) || n < f.min || n > f.max) return io.say(`❌ Please provide a number between ${f.min} and ${f.max}.`);
            automod.setFilter(guildId, group, { threshold: n });
            return io.say(`✅ Set **${f.label}** limit to **${n}${f.unit === '%' ? '%' : ''}**.`);
        }
        return;
    }

    if (group === 'ignore') {
        const data = automod.getGuildData(guildId);
        if (sub === 'show') return io.say(null, ignoreEmbed(data));
        if (sub === 'reset') { automod.setConfig(guildId, { ignore: { channels: [], roles: [], users: [] } }); return io.say('✅ Successfully reset ignored targets.'); }
        const m = /^(add|remove)_(user|role|channel)$/.exec(sub);
        if (!m) return;
        const [, action, type] = m;
        const id = val.id;
        if (!id) return io.say(`❌ Please provide a valid ${type}.`);
        const list = data.ignore[`${type}s`];
        if (action === 'add') {
            if (list.includes(id)) return io.say(`❌ Already in ignored ${type}s.`);
            list.push(id);
            automod.setConfig(guildId, { ignore: data.ignore });
            return io.say(`✅ Added to ignored ${type}s.`);
        }
        if (!list.includes(id)) return io.say(`❌ Not in ignored ${type}s.`);
        data.ignore[`${type}s`] = list.filter(x => x !== id);
        automod.setConfig(guildId, { ignore: data.ignore });
        return io.say(`✅ Removed from ignored ${type}s.`);
    }
}

const hasAccess = (guild, userId) => userId === guild.ownerId || permit.isExtraOwner(guild.id, userId);

module.exports = {
    data: buildSlash(),
    FILTERS,
    apply,

    async execute(interaction) {
        const guild = interaction.guild;
        if (!hasAccess(guild, interaction.user.id)) {
            return interaction.reply({ content: '❌ No access', flags: MessageFlags.Ephemeral });
        }
        const group = interaction.options.getSubcommandGroup(false);
        const sub = interaction.options.getSubcommand();

        const val = {};
        if (!group && sub === 'logging') val.channel = interaction.options.getChannel('channel');
        if (!group && sub === 'punishment') val.type = interaction.options.getString('type');
        if (FILTERS[group] && sub === 'set') val.number = interaction.options.getInteger(FILTERS[group].option);
        if (group === 'ignore') {
            const t = sub.split('_')[1];
            if (t) val.id = interaction.options.get(t)?.value;
        }

        const io = {
            say: (text, embed) => interaction.reply(embed ? { embeds: [embed], flags: MessageFlags.Ephemeral } : { content: text, flags: MessageFlags.Ephemeral })
        };
        await apply(io, guild, interaction.client, group, sub, val);
    },

    async executeMessage(message, args) {
        const guild = message.guild;
        const page = args[0] === '2' ? 2 : 1;

        const helpEmbed1 = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **automod enable / disable**\n› Turn automod on or off.\n\n` +
                `» **automod config**\n› View current automod settings.\n\n` +
                `» **automod filters**\n› List all filters and their state.\n\n` +
                `» **automod <filter> <enable|disable|set <n>>**\n› Filters: ${Object.keys(FILTERS).map(f => `\`${f}\``).join(', ')}\n\n` +
                `» **automod ignore <user|role|channel> <target>**\n› Ignore a target (also \`ignore show\` / \`ignore reset\`).`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/2 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        const helpEmbed2 = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **automod unignore <user|role|channel> <target>**\n› Stop ignoring a target.\n\n` +
                `» **automod logging <#channel>**\n› Configure automod log channel.\n\n` +
                `» **automod punishment <ban|kick|mute>**\n› Punishment applied by automute.\n\n` +
                `» **automod reset**\n› Reset all automod settings to default.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 2/2 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        const getButtons = (p) => new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('first').setLabel('«').setStyle(ButtonStyle.Secondary).setDisabled(p === 1),
            new ButtonBuilder().setCustomId('prev').setLabel('‹').setStyle(ButtonStyle.Secondary).setDisabled(p === 1),
            new ButtonBuilder().setCustomId('next').setLabel('›').setStyle(ButtonStyle.Secondary).setDisabled(p === 2),
            new ButtonBuilder().setCustomId('last').setLabel('»').setStyle(ButtonStyle.Secondary).setDisabled(p === 2),
            new ButtonBuilder().setCustomId('delete').setEmoji('🗑️').setStyle(ButtonStyle.Danger)
        );

        const sub0 = args[0] ? args[0].toLowerCase() : 'help';
        const valid = ['enable', 'disable', 'config', 'reset', 'logging', 'punishment', 'filters', 'ignore', 'unignore', ...Object.keys(FILTERS)];

        if (sub0 === 'help' || sub0 === '2' || !valid.includes(sub0)) {
            const msg = await message.reply({ embeds: [page === 1 ? helpEmbed1 : helpEmbed2], components: [getButtons(page)] });
            const collector = msg.createMessageComponentCollector({ componentType: ComponentType.Button, time: 60000 });
            let currentPage = page;
            collector.on('collect', async i => {
                if (i.user.id !== message.author.id) return i.reply({ content: 'This is not for you.', flags: MessageFlags.Ephemeral });
                if (i.customId === 'delete') { collector.stop(); return msg.delete().catch(() => { }); }
                if (i.customId === 'first' || i.customId === 'prev') currentPage = 1;
                else if (i.customId === 'next' || i.customId === 'last') currentPage = 2;
                await i.update({ embeds: [currentPage === 1 ? helpEmbed1 : helpEmbed2], components: [getButtons(currentPage)] });
            });
            collector.on('end', () => msg.edit({ components: [] }).catch(() => { }));
            return;
        }

        if (!hasAccess(guild, message.author.id)) return message.reply('❌ No access');

        const io = {
            say: async (text, embed) => {
                const sent = await message.reply(embed ? { embeds: [embed] } : { content: text, allowedMentions: { repliedUser: false } });
                if (!embed) setTimeout(() => sent.delete().catch(() => { }), 4000);
                return sent;
            }
        };
        const idOf = (tok) => (tok ? tok.replace(/[<@!&#>]/g, '') : null);

        let group = null, sub = sub0, val = {};

        if (['enable', 'disable', 'config', 'reset', 'filters'].includes(sub0)) {
            // simple
        } else if (sub0 === 'logging') {
            const id = idOf(args[1]);
            const ch = id ? guild.channels.cache.get(id) : null;
            if (!ch) return message.reply('Please mention a channel. Usage: `automod logging #channel`');
            val.channel = ch;
        } else if (sub0 === 'punishment') {
            val.type = args[1] ? args[1].toLowerCase() : null;
            if (!val.type) return message.reply('Usage: `automod punishment <ban|kick|mute>`');
        } else if (FILTERS[sub0]) {
            group = sub0;
            sub = args[1] ? args[1].toLowerCase() : null;
            const f = FILTERS[sub0];
            if (!sub || !['enable', 'disable', ...(f.option ? ['set'] : [])].includes(sub)) {
                return message.reply(`Usage: \`automod ${sub0} <enable|disable${f.option ? '|set <number>' : ''}>\``);
            }
            if (sub === 'set') {
                val.number = parseInt(args[2], 10);
                if (isNaN(val.number)) return message.reply(`Please provide a number. Usage: \`automod ${sub0} set <number>\``);
            }
        } else if (sub0 === 'ignore' || sub0 === 'unignore') {
            group = 'ignore';
            const tokens = args.slice(1);
            let action = sub0 === 'unignore' ? 'remove' : 'add';
            if (sub0 === 'ignore' && ['show', 'reset'].includes((tokens[0] || '').toLowerCase())) {
                sub = tokens[0].toLowerCase();
            } else {
                if (['add', 'remove'].includes((tokens[0] || '').toLowerCase())) action = tokens.shift().toLowerCase();
                const type = (tokens[0] || '').toLowerCase();
                if (!IGNORE_TYPES.includes(type)) {
                    return message.reply(`Usage: \`automod ${sub0} <user|role|channel> <target>\` (or \`automod ignore show|reset\`)`);
                }
                const id = idOf(tokens[1]);
                if (!id) return message.reply(`Please provide a ${type}. Usage: \`automod ${sub0} ${type} <target>\``);
                if (type === 'role' && !guild.roles.cache.has(id)) return message.reply('I could not find that role.');
                if (type === 'channel' && !guild.channels.cache.has(id)) return message.reply('I could not find that channel.');
                if (type === 'user' && !(await guild.members.fetch(id).catch(() => null))) return message.reply('I could not find that user.');
                sub = `${action}_${type}`;
                val.id = id;
            }
        }

        await apply(io, guild, message.client, group, sub, val);
    }
};
