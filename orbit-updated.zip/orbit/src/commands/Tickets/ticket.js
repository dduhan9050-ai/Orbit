const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');
const embedHelper = require('../../functions/embedHelper');
const permissionChecker = require('../../functions/permissionChecker');

const dataPath = path.join(__dirname, '../../data/tickets.json');

// Helper to check support roles
function isSupportMember(member, guildData) {
    return !!(guildData && Array.isArray(guildData.supportRoles) && guildData.supportRoles.some(id => member.roles.cache.has(id)));
}

function getTicketData() {
    if (!fs.existsSync(dataPath)) {
        fs.writeFileSync(dataPath, JSON.stringify({}));
    }
    return JSON.parse(fs.readFileSync(dataPath, 'utf8'));
}

function setTicketData(data) {
    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ticket')
        .setDescription('Ticket system management')
        .addSubcommand(sub => sub.setName('category').setDescription('Set ticket category').addChannelOption(opt => opt.setName('category').setDescription('The category').setRequired(true)))
        .addSubcommand(sub => sub.setName('delete').setDescription('Delete a ticket').addChannelOption(opt => opt.setName('channel').setDescription('The ticket channel')))
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove a user from a ticket').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)))
        .addSubcommand(sub => sub.setName('logging').setDescription('Set ticket logging channel').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
        .addSubcommand(sub => sub.setName('transcript').setDescription('Generate a ticket transcript'))
        .addSubcommand(sub => sub.setName('panel').setDescription('Send the ticket creation panel').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
        .addSubcommand(sub => sub.setName('rename').setDescription('Rename a ticket').addStringOption(opt => opt.setName('name').setDescription('New name').setRequired(true)))
        .addSubcommand(sub => sub.setName('greetmsg').setDescription('Set ticket greeting message').addStringOption(opt => opt.setName('message').setDescription('The message').setRequired(true)))
        .addSubcommand(sub => sub.setName('autotranscript').setDescription('Toggle auto-transcript on close'))
        .addSubcommand(sub => sub.setName('list').setDescription('List all current tickets'))
        .addSubcommand(sub => sub.setName('add').setDescription('Add a user to a ticket').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)))
        .addSubcommand(sub => sub.setName('maxtickets').setDescription('Set max tickets per user').addIntegerOption(opt => opt.setName('amount').setDescription('Amount').setRequired(true)))
        .addSubcommand(sub => sub.setName('close').setDescription('Close a ticket'))
        .addSubcommand(sub => sub.setName('reopen').setDescription('Reopen a closed ticket'))
        .addSubcommandGroup(group => group.setName('support').setDescription('Manage ticket support roles')
            .addSubcommand(sub => sub.setName('add').setDescription('Add a support role').addRoleOption(opt => opt.setName('role').setDescription('The role').setRequired(true)))
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove a support role').addRoleOption(opt => opt.setName('role').setDescription('The role').setRequired(true)))
            .addSubcommand(sub => sub.setName('reset').setDescription('Reset support roles'))
            .addSubcommand(sub => sub.setName('show').setDescription('Show support roles')))
        .addSubcommandGroup(group => group.setName('type').setDescription('Manage ticket types/categories')
            .addSubcommand(sub => sub.setName('create').setDescription('Create a ticket type').addStringOption(opt => opt.setName('name').setDescription('Name').setRequired(true)))
            .addSubcommand(sub => sub.setName('delete').setDescription('Delete a ticket type').addStringOption(opt => opt.setName('name').setDescription('Name').setRequired(true)))
            .addSubcommand(sub => sub.setName('edit').setDescription('Edit a ticket type').addStringOption(opt => opt.setName('name').setDescription('Name').setRequired(true)))),
    async execute(interaction) {
        const group = interaction.options.getSubcommandGroup();
        const sub = interaction.options.getSubcommand();
        const path = group ? `${group} ${sub}` : sub;
        await interaction.reply({ embeds: [new EmbedBuilder().setTitle('Ticket System').setDescription(`Executed ticket command: **${path}**`).setColor('#000000')] });
    },
    async executeMessage(message, args) {
        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        const secondArg = args[1] ? args[1].toLowerCase() : null;

        const mainHelp = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **ticket panel #channel**\n› Send ticket panel.\n\n` +
                `» **ticket category #category**\n› Set ticket category.\n\n` +
                `» **ticket support**\n› Manage support roles.\n\n` +
                `» **ticket close/reopen**\n› Close/reopen ticket.\n\n` +
                `» **ticket add/remove @user**\n› Manage users.\n\n` +
                `» **ticket list**\n› List active tickets.\n\n` +
                `» **ticket logging #channel**\n› Set logging channel.\n\n` +
                `» **ticket greetmsg <message>**\n› Set greeting.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        const supportHelp = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **ticket support add @role**\n› Add support role.\n\n` +
                `» **ticket support remove @role**\n› Remove support role.\n\n` +
                `» **ticket support show**\n› Show support roles.\n\n` +
                `» **ticket support reset**\n› Reset support roles.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        if (subcommand === 'help' || !['panel', 'category', 'support', 'add', 'remove', 'close', 'reopen', 'delete', 'rename', 'logging', 'list', 'maxtickets', 'greetmsg'].includes(subcommand)) {
            return message.reply({ embeds: [mainHelp] });
        }

        // If user types !ticket support @role, treat it as !ticket support add @role
        if (subcommand === 'support' && secondArg && !['add', 'remove', 'show', 'reset'].includes(secondArg)) {
            // Check if secondArg is a role mention or ID
            const roleId = secondArg.replace(/[<@&>]/g, '');
            const role = message.guild.roles.cache.get(roleId);
            if (role) {
                // Auto-add the role
                args.splice(1, 0, 'add'); // Insert 'add' at index 1
            } else {
                return message.reply({ embeds: [supportHelp] });
            }
        }

        if (subcommand === 'support' && (!secondArg || (secondArg && !['add', 'remove', 'show', 'reset'].includes(secondArg) && !message.guild.roles.cache.get(secondArg.replace(/[<@&>]/g, ''))))) {
            return message.reply({ embeds: [supportHelp] });
        }

        const guildId = message.guild.id;
        const data = getTicketData();
        if (!data[guildId]) {
            data[guildId] = {
                category: null,
                logging: null,
                supportRoles: [],
                tickets: [],
                greetMsg: 'Thank you for creating a ticket! Support will be with you shortly.',
                maxTickets: 1
            };
        }

        // Admin-only: Panel command
        if (subcommand === 'panel') {
            if (!permissionChecker.hasAdminPermission(message.member, message.guild)) {
                return message.reply({ embeds: [embedHelper.error('❌ Only server owner, extra owners, or administrators can use this command.')] });
            }

            const channelId = args[1] ? args[1].replace(/[<#>]/g, '') : null;
            if (!channelId) {
                return message.reply({ embeds: [embedHelper.error('Please mention a channel. Usage: `!ticket panel #channel`')] });
            }
            const channel = message.guild.channels.cache.get(channelId);
            if (!channel) {
                return message.reply({ embeds: [embedHelper.error('Invalid channel provided.')] });
            }

            const panelEmbed = new EmbedBuilder()
                .setTitle('🎫 Support Tickets')
                .setDescription('Click the button below to create a support ticket.')
                .setColor('#2b2d31');

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('create_ticket')
                        .setLabel('Create Ticket')
                        .setEmoji('🎫')
                        .setStyle(ButtonStyle.Primary)
                );

            await channel.send({ embeds: [panelEmbed], components: [row] });
            const reply = await message.reply({ embeds: [embedHelper.success(`✅ Ticket panel sent to ${channel}`)] });
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        // Admin-only: Category command
        if (subcommand === 'category') {
            if (!permissionChecker.hasAdminPermission(message.member, message.guild)) {
                return message.reply({ embeds: [embedHelper.error('❌ Only server owner, extra owners, or administrators can use this command.')] });
            }

            const input = args[1];
            if (!input) {
                return message.reply({ embeds: [embedHelper.error('Please mention a category channel. Usage: `!ticket category #category` or `!ticket category CategoryName`')] });
            }
            
            // Try to get channel by ID/mention first
            let channelId = input.replace(/[<#>]/g, '');
            let category = message.guild.channels.cache.get(channelId);
            
            // If not found, try to find by name
            if (!category) {
                category = message.guild.channels.cache.find(ch => 
                    ch.type === ChannelType.GuildCategory && 
                    ch.name.toLowerCase() === input.toLowerCase()
                );
            }
            
            if (!category || category.type !== ChannelType.GuildCategory) {
                return message.reply({ embeds: [embedHelper.error('Please provide a valid category channel. Make sure it\'s a category, not a text channel.')] });
            }
            
            data[guildId].category = category.id;
            setTicketData(data);
            const reply = await message.reply({ embeds: [embedHelper.success(`✅ Ticket category set to: ${category.name}`)] });
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        // Admin-only: Logging command
        if (subcommand === 'logging') {
            if (!permissionChecker.hasAdminPermission(message.member, message.guild)) {
                return message.reply({ embeds: [embedHelper.error('❌ Only server owner, extra owners, or administrators can use this command.')] });
            }

            const channelId = args[1] ? args[1].replace(/[<#>]/g, '') : null;
            if (!channelId) {
                return message.reply({ embeds: [embedHelper.error('Please mention a channel. Usage: `!ticket logging #channel`')] });
            }
            const channel = message.guild.channels.cache.get(channelId);
            if (!channel) {
                return message.reply({ embeds: [embedHelper.error('Invalid channel provided.')] });
            }
            data[guildId].logging = channelId;
            setTicketData(data);
            const reply = await message.reply({ embeds: [embedHelper.success(`✅ Ticket logging set to: ${channel}`)] });
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            return;
        }

        // Admin-only: Greeting message command
        if (subcommand === 'greetmsg') {
            if (!permissionChecker.hasAdminPermission(message.member, message.guild)) {
                return message.reply({ embeds: [embedHelper.error('❌ Only server owner, extra owners, or administrators can use this command.')] });
            }

            const msg = args.slice(1).join(' ');
            if (!msg) {
                const currentMsg = data[guildId].greetMsg || 'Thank you for creating a ticket! Support will be with you shortly.';
                const embed = new EmbedBuilder()
                    .setTitle('Current Greeting Message')
                    .setDescription(currentMsg)
                    .setColor('#2b2d31')
                    .setFooter({ text: 'Use: !ticket greetmsg <message> to change' });
                return message.reply({ embeds: [embed] });
            }
            data[guildId].greetMsg = msg;
            setTicketData(data);
            const reply = await message.reply({ embeds: [embedHelper.success(`✅ Greeting message updated to:\n${msg}`)] });
            setTimeout(() => reply.delete().catch(() => {}), 5000);
            return;
        }

        // Admin-only: Support role management
        if (subcommand === 'support') {
            if (!permissionChecker.hasAdminPermission(message.member, message.guild)) {
                return message.reply({ embeds: [embedHelper.error('❌ Only server owner, extra owners, or administrators can use this command.')] });
            }

            const action = args[1] ? args[1].toLowerCase() : null;

            if (action === 'add') {
                const roleId = args[2] ? args[2].replace(/[<@&>]/g, '') : null;
                if (!roleId) {
                    return message.reply({ embeds: [embedHelper.error('Please mention a role. Usage: `!ticket support add @role`')] });
                }
                const role = message.guild.roles.cache.get(roleId);
                if (!role) {
                    return message.reply({ embeds: [embedHelper.error('Invalid role provided.')] });
                }
                if (!data[guildId].supportRoles.includes(roleId)) {
                    data[guildId].supportRoles.push(roleId);
                    setTicketData(data);
                    const reply = await message.reply({ embeds: [embedHelper.success(`✅ Added ${role} as support role`)] });
                    setTimeout(() => reply.delete().catch(() => {}), 3000);
                } else {
                    return message.reply({ embeds: [embedHelper.warning('This role is already a support role.')] });
                }
                return;
            }

            if (action === 'remove') {
                const roleId = args[2] ? args[2].replace(/[<@&>]/g, '') : null;
                data[guildId].supportRoles = data[guildId].supportRoles.filter(id => id !== roleId);
                setTicketData(data);
                const reply = await message.reply({ embeds: [embedHelper.success('✅ Removed role from support')] });
                setTimeout(() => reply.delete().catch(() => {}), 3000);
                return;
            }

            if (action === 'show') {
                const roles = data[guildId].supportRoles.length > 0
                    ? data[guildId].supportRoles.map(id => `<@&${id}>`).join(', ')
                    : 'None';
                const embed = new EmbedBuilder()
                    .setTitle('Support Roles')
                    .setDescription(roles)
                    .setColor('#2b2d31');
                return message.reply({ embeds: [embed] });
            }

            if (action === 'reset') {
                data[guildId].supportRoles = [];
                setTicketData(data);
                const reply = await message.reply({ embeds: [embedHelper.success('✅ Reset support roles')] });
                setTimeout(() => reply.delete().catch(() => {}), 3000);
                return;
            }
        }

        // Admin-only: List tickets
        if (subcommand === 'list') {
            if (!permissionChecker.hasAdminPermission(message.member, message.guild)) {
                return message.reply({ embeds: [embedHelper.error('❌ Only server owner, extra owners, or administrators can use this command.')] });
            }

            let tickets = data[guildId].tickets || [];
            
            // Clean up deleted channels
            const validTickets = [];
            for (const ticket of tickets) {
                const channel = message.guild.channels.cache.get(ticket.channelId);
                if (channel) {
                    validTickets.push(ticket);
                }
            }
            
            // Update database if tickets were removed
            if (validTickets.length !== tickets.length) {
                data[guildId].tickets = validTickets;
                setTicketData(data);
                tickets = validTickets;
            }
            
            if (!tickets.length) {
                return message.reply({ embeds: [embedHelper.info('No active tickets.')] });
            }
            
            const list = tickets.map(t => `<#${t.channelId}> - ${t.userName}`).join('\n');
            const embed = new EmbedBuilder()
                .setTitle('Active Tickets')
                .setDescription(list)
                .setColor('#2b2d31')
                .setFooter({ text: `Total: ${tickets.length}` });
            return message.reply({ embeds: [embed] });
        }

        // Close ticket (support-only inside ticket channels)
        if (subcommand === 'close') {
            if (!message.channel.name.startsWith('ticket-')) {
                return message.reply({ embeds: [embedHelper.error('This command can only be used in ticket channels.')] });
            }
            const ticket = data[guildId].tickets.find(t => t.channelId === message.channel.id);
            if (!ticket) {
                return message.reply({ embeds: [embedHelper.error('Ticket not found in database.')] });
            }

            const isSupport = isSupportMember(message.member, data[guildId]);
            if (!isSupport && !message.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
                return message.reply({ embeds: [embedHelper.error('Only support roles or admins can close tickets.')] });
            }

            const reason = args.slice(1).join(' ').trim();

            if (!reason) {
                // Prompt user to provide reason via modal button
                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('ticket_close').setLabel('Provide reason & Close').setStyle(ButtonStyle.Danger).setEmoji('🔒')
                );
                await message.reply({ content: 'Please provide a reason to close the ticket by clicking the button below.', components: [row] });
                return;
            }

            // Proceed with closure using provided reason
            try {
                // Fetch messages for transcript
                let fetched = [];
                try {
                    const msgs = await message.channel.messages.fetch({ limit: 100 });
                    fetched = Array.from(msgs.values()).reverse(); // oldest first
                } catch (err) {
                    console.error('Failed to fetch messages for transcript', err);
                }

                const lines = [];
                lines.push(`Guild: ${message.guild.name} (${message.guild.id})`);
                lines.push(`Channel: ${message.channel.name} (${message.channel.id})`);
                lines.push(`Ticket owner: ${ticket.userName} (${ticket.userId})`);
                lines.push(`Closed by: ${message.author.tag} (${message.author.id})`);
                lines.push(`Reason: ${reason}`);
                lines.push(`Closed at: ${new Date().toISOString()}`);
                lines.push('---');

                for (const m of fetched) {
                    const time = new Date(m.createdTimestamp).toISOString();
                    const author = `${m.author.tag} (${m.author.id})`;
                    const content = m.content ? m.content.replace(/```/g, '`\u200b``') : '';
                    lines.push(`[${time}] ${author}: ${content}`);
                    if (m.attachments && m.attachments.size > 0) {
                        for (const att of m.attachments.values()) {
                            lines.push(`--> Attachment: ${att.url}`);
                        }
                    }
                }

                const transcriptText = lines.join('\n');
                const buffer = Buffer.from(transcriptText, 'utf8');

                // Send to logging channel if configured
                if (data[guildId].logging) {
                    const logCh = message.guild.channels.cache.get(data[guildId].logging);
                    if (logCh) {
                        const embed = new EmbedBuilder()
                            .setTitle('📋 Ticket Closed')
                            .setDescription(`Ticket closed by ${message.author}\nChannel: <#${message.channel.id}>\nReason: ${reason}`)
                            .addFields({ name: 'Owner', value: `<@${ticket.userId}>`, inline: true }, { name: 'Ticket ID', value: `${message.channel.id}`, inline: true })
                            .setColor('#2b2d31')
                            .setTimestamp();
                        try {
                            await logCh.send({ embeds: [embed], files: [{ attachment: buffer, name: `${message.channel.name}-transcript.txt` }] });
                        } catch (err) {
                            console.error('Failed to send transcript to logging channel', err);
                            const tDir = path.join(__dirname, '../../data/transcripts');
                            if (!fs.existsSync(tDir)) fs.mkdirSync(tDir, { recursive: true });
                            const fname = `${guildId}_${message.channel.id}_${Date.now()}.txt`;
                            fs.writeFileSync(path.join(tDir, fname), transcriptText);
                        }
                    }
                } else {
                    const tDir = path.join(__dirname, '../../data/transcripts');
                    if (!fs.existsSync(tDir)) fs.mkdirSync(tDir, { recursive: true });
                    const fname = `${guildId}_${message.channel.id}_${Date.now()}.txt`;
                    fs.writeFileSync(path.join(tDir, fname), transcriptText);
                }

                await message.channel.send('🔒 Closing ticket in 5 seconds...');
                setTimeout(async () => {
                    try {
                        const cid = message.channel.id;
                        await message.channel.delete();
                        data[guildId].tickets = data[guildId].tickets.filter(t => t.channelId !== cid);
                        setTicketData(data);
                    } catch (err) {
                        console.error('Failed to delete ticket channel via message close', err);
                    }
                }, 5000);

            } catch (error) {
                console.error(error);
                return message.reply({ embeds: [embedHelper.error('Failed to close ticket.')] });
            }

            return;
        }

        // Add user (support-only inside ticket channels)
        if (subcommand === 'add') {
            if (!message.channel.name.startsWith('ticket-')) {
                return message.reply({ embeds: [embedHelper.error('This command can only be used in ticket channels.')] });
            }
            const ticket = data[guildId].tickets.find(t => t.channelId === message.channel.id);
            if (!ticket) return message.reply({ embeds: [embedHelper.error('Ticket not found in database.')] });

            const isSupport = isSupportMember(message.member, data[guildId]);
            if (!isSupport && !message.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
                return message.reply({ embeds: [embedHelper.error('Only support roles or admins can add users to tickets.')] });
            }

            const userId = args[1] ? args[1].replace(/[<@!>]/g, '') : null;
            if (!userId) {
                return message.reply({ embeds: [embedHelper.error('Please mention a user. Usage: `!ticket add @user`')] });
            }
            try {
                const member = await message.guild.members.fetch(userId);
                await message.channel.permissionOverwrites.edit(member, {
                    ViewChannel: true,
                    SendMessages: true,
                    ReadMessageHistory: true
                });
                const reply = await message.reply({ embeds: [embedHelper.success(`✅ Added ${member} to ticket`)] });
                setTimeout(() => reply.delete().catch(() => {}), 3000);
            } catch (error) {
                console.error(error);
                return message.reply({ embeds: [embedHelper.error('Failed to add user.')] });
            }
            return;
        }

        // Remove user (support-only inside ticket channels)
        if (subcommand === 'remove') {
            if (!message.channel.name.startsWith('ticket-')) {
                return message.reply({ embeds: [embedHelper.error('This command can only be used in ticket channels.')] });
            }
            const ticket = data[guildId].tickets.find(t => t.channelId === message.channel.id);
            if (!ticket) return message.reply({ embeds: [embedHelper.error('Ticket not found in database.')] });

            const isSupport = isSupportMember(message.member, data[guildId]);
            if (!isSupport && !message.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
                return message.reply({ embeds: [embedHelper.error('Only support roles or admins can remove users from tickets.')] });
            }

            const userId = args[1] ? args[1].replace(/[<@!>]/g, '') : null;
            if (!userId) {
                return message.reply({ embeds: [embedHelper.error('Please mention a user. Usage: `!ticket remove @user`')] });
            }
            try {
                const member = await message.guild.members.fetch(userId);
                await message.channel.permissionOverwrites.delete(member);
                const reply = await message.reply({ embeds: [embedHelper.success(`✅ Removed ${member} from ticket`)] });
                setTimeout(() => reply.delete().catch(() => {}), 3000);
            } catch (error) {
                console.error(error);
                return message.reply({ embeds: [embedHelper.error('Failed to remove user.')] });
            }
            return;
        }

        return message.reply({ embeds: [embedHelper.info(`Subcommand \`${subcommand}\` is available. Use the help menu for more info.`)] });
    },
    async handleComponent(interaction) {
        if (interaction.customId === 'create_ticket') {
            const guildId = interaction.guild.id;
            const data = getTicketData();
            
            if (!data[guildId]) {
                data[guildId] = {
                    category: null,
                    logging: null,
                    supportRoles: [],
                    tickets: [],
                    greetMsg: 'Thank you for creating a ticket! Support will be with you shortly.',
                    maxTickets: 1
                };
            }

            const guildData = data[guildId];

            // Defer reply because creating a channel and setting perms can take time
            await interaction.deferReply({ ephemeral: true }).catch(() => {});

            // Check if user already has max tickets
            const userTickets = guildData.tickets.filter(t => t.userId === interaction.user.id);
            if (userTickets.length >= guildData.maxTickets) {
                return interaction.editReply({ content: `You already have ${guildData.maxTickets} ticket(s) open.` }).catch(() => {});
            }

            // Check if category is set (optional)
            let parentId = null;
            if (guildData.category) {
                const category = interaction.guild.channels.cache.get(guildData.category);
                if (category) {
                    parentId = category.id;
                }
            }

            try {
                // Create ticket channel
                const ticketChannel = await interaction.guild.channels.create({
                    name: `ticket-${interaction.user.username}`,
                    type: ChannelType.GuildText,
                    parent: parentId,
                    permissionOverwrites: [
                        {
                            id: interaction.guild.id,
                            deny: [PermissionFlagsBits.ViewChannel]
                        },
                        {
                            id: interaction.user.id,
                            allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory]
                        },
                        {
                            id: interaction.client.user.id,
                            allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks, PermissionFlagsBits.ManageChannels]
                        },
                        ...guildData.supportRoles.map(roleId => ({
                            id: roleId,
                            allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory]
                        }))
                    ]
                });

                // Add ticket to database
                guildData.tickets.push({
                    channelId: ticketChannel.id,
                    userId: interaction.user.id,
                    userName: interaction.user.username,
                    createdAt: Date.now()
                });
                setTicketData(data);

                // Enforce explicit permission overwrites so only creator, support roles and bot can see the channel
                try {
                    const overwrites = [
                        { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                        { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
                        { id: interaction.client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks, PermissionFlagsBits.ManageChannels] },
                        ...guildData.supportRoles.map(roleId => ({ id: roleId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] }))
                    ];
                    await ticketChannel.permissionOverwrites.set(overwrites);
                } catch (permErr) {
                    console.error('Failed to set permission overwrites for ticket channel:', permErr);
                }

                // Send greeting message
                const createdAt = Math.floor(Date.now() / 1000);
                const greetEmbed = new EmbedBuilder()
                    .setTitle('🎫 Ticket Created')
                    .setDescription(`${guildData.greetMsg}\n\n**Created:** <t:${createdAt}:R>`) 
                    .setColor('#2b2d31')
                    .setFooter({ text: `Created by ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL() })
                    .setTimestamp(createdAt * 1000);

                const supportMentions = guildData.supportRoles.length > 0 ? guildData.supportRoles.map(id => `<@&${id}>`).join(' ') : 'None';

                // Add fields to embed showing creator and support roles, then send without an extra mention (keeps channel clean)
                greetEmbed.addFields(
                    { name: 'Opened by', value: `<@${interaction.user.id}>`, inline: true },
                    { name: 'Support', value: supportMentions, inline: true }
                );

                // Set channel topic for clarity (best-effort)
                try {
                    await ticketChannel.setTopic(`Ticket for ${interaction.user.tag}`);
                } catch (err) {
                    console.log('Could not set channel topic', err?.message ?? err);
                }

                await ticketChannel.send({ embeds: [greetEmbed] });

                // Log if logging is set
                if (guildData.logging) {
                    const logChannel = interaction.guild.channels.cache.get(guildData.logging);
                    if (logChannel) {
                        const logEmbed = new EmbedBuilder()
                            .setTitle('📋 Ticket Created')
                            .setDescription(`Ticket created by ${interaction.user}\nChannel: <#${ticketChannel.id}>\nOwner: <@${interaction.user.id}>`)
                            .addFields({ name: 'Ticket ID', value: `${ticketChannel.id}`, inline: true })
                            .setColor('#2b2d31')
                            .setTimestamp();
                        await logChannel.send({ embeds: [logEmbed] });
                    }
                }

                // Inform the user via the deferred reply
                await interaction.editReply({ content: `✅ Ticket created: ${ticketChannel}` }).catch(() => {});
                setTimeout(async () => {
                    try {
                        await interaction.deleteReply();
                    } catch (err) {
                        console.log('Could not delete ticket creation message');
                    }
                }, 3000);
            } catch (error) {
                console.error(error);
                await interaction.editReply({ content: 'Failed to create ticket. Please contact an administrator.' }).catch(() => {});
            }
        }

        // When close button pressed, show modal to collect reason
        if (interaction.customId === 'ticket_close') {
            const guildId = interaction.guild.id;
            const data = getTicketData();
            const guildData = data[guildId];

            if (!guildData) {
                return interaction.editReply({ content: 'Ticket system not configured for this server.' }).catch(() => {});
            }

            const channelId = interaction.channelId || (interaction.channel && interaction.channel.id);
            const ticket = guildData.tickets.find(t => t.channelId === channelId);
            if (!ticket) {
                return interaction.reply({ content: 'This is not a ticket channel.', ephemeral: true });
            }

            const member = interaction.member;
            const isSupport = guildData.supportRoles && guildData.supportRoles.some(id => member.roles.cache.has(id));
            if (!isSupport && !member.permissions.has(PermissionFlagsBits.ManageGuild)) {
                return interaction.reply({ content: 'Only support roles or admins can close tickets.', ephemeral: true });
            }

            // Show modal to collect reason
            try {
                const modal = new ModalBuilder()
                    .setCustomId('ticket_close_modal')
                    .setTitle('Close Ticket - Reason');

                const input = new TextInputBuilder()
                    .setCustomId('close_reason')
                    .setLabel('Reason for closure (optional)')
                    .setStyle(TextInputStyle.Paragraph)
                    .setRequired(false)
                    .setPlaceholder('E.g., Issue resolved, duplicate ticket, spam, etc.');

                modal.addComponents(new ActionRowBuilder().addComponents(input));
                await interaction.showModal(modal);
            } catch (err) {
                console.error('Failed to show close modal', err);
                return interaction.reply({ content: 'Failed to open reason modal. Please try the close command with a reason instead: `!ticket close <reason>`', ephemeral: true });
            }

            return;
        }
    },
    // Modal submit handler
    async handleModal(interaction) {
        if (!interaction.isModalSubmit()) return;
        if (interaction.customId !== 'ticket_close_modal') return;

        // Defer reply to allow time for transcript generation
        await interaction.deferReply({ ephemeral: true }).catch(() => {});

        const guildId = interaction.guild.id;
        const data = getTicketData();
        const guildData = data[guildId];
        if (!guildData) {
            return interaction.editReply({ content: 'Ticket system not configured for this server.' }).catch(() => {});
        }

        const channel = interaction.channel;
        if (!channel) {
            return interaction.editReply({ content: 'Could not find ticket channel context.' }).catch(() => {});
        }

        const ticket = guildData.tickets.find(t => t.channelId === channel.id);
        if (!ticket) {
            return interaction.editReply({ content: 'This is not a ticket channel.' }).catch(() => {});
        }

        const isSupport = isSupportMember(interaction.member, guildData);
        if (!isSupport && !interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
            return interaction.editReply({ content: 'Only support roles or admins can close tickets.' }).catch(() => {});
        }

        const reason = interaction.fields.getTextInputValue('close_reason') || 'No reason provided';

        await interaction.editReply({ content: 'Closing ticket and saving transcript...' }).catch(() => {});

        // Fetch messages
        let fetched = [];
        try {
            const msgs = await channel.messages.fetch({ limit: 100 });
            fetched = Array.from(msgs.values()).reverse(); // oldest first
        } catch (err) {
            console.error('Failed to fetch messages for transcript', err);
        }

        // Build transcript text
        const lines = [];
        lines.push(`Guild: ${interaction.guild.name} (${interaction.guild.id})`);
        lines.push(`Channel: ${channel.name} (${channel.id})`);
        lines.push(`Ticket owner: ${ticket.userName} (${ticket.userId})`);
        lines.push(`Closed by: ${interaction.user.tag} (${interaction.user.id})`);
        lines.push(`Reason: ${reason}`);
        lines.push(`Closed at: ${new Date().toISOString()}`);
        lines.push('---');

        for (const m of fetched) {
            const time = new Date(m.createdTimestamp).toISOString();
            const author = `${m.author.tag} (${m.author.id})`;
            // Replace triple backticks to avoid breaking transcript formatting
            const content = m.content ? m.content.replace(/```/g, '`\u200b``') : '';
            lines.push(`[${time}] ${author}: ${content}`);
            if (m.attachments && m.attachments.size > 0) {
                for (const att of m.attachments.values()) {
                    lines.push(`--> Attachment: ${att.url}`);
                }
            }
        }

        const transcriptText = lines.join('\n');
        const buffer = Buffer.from(transcriptText, 'utf8');

        // Send to logging channel if configured, else save to disk
        if (guildData.logging) {
            const logCh = interaction.guild.channels.cache.get(guildData.logging);
            if (logCh) {
                const embed = new EmbedBuilder()
                    .setTitle('📋 Ticket Closed')
                    .setDescription(`Ticket closed by ${interaction.user}\nChannel: <#${channel.id}>\nReason: ${reason}`)
                    .addFields(
                        { name: 'Owner', value: `<@${ticket.userId}>`, inline: true },
                        { name: 'Ticket ID', value: `${channel.id}`, inline: true }
                    )
                    .setColor('#2b2d31')
                    .setTimestamp();
                try {
                    await logCh.send({ embeds: [embed], files: [{ attachment: buffer, name: `${channel.name}-transcript.txt` }] });
                } catch (err) {
                    console.error('Failed to send transcript to logging channel', err);
                    // fallback to disk save
                    const tDir = path.join(__dirname, '../../data/transcripts');
                    if (!fs.existsSync(tDir)) fs.mkdirSync(tDir, { recursive: true });
                    const fname = `${guildId}_${channel.id}_${Date.now()}.txt`;
                    fs.writeFileSync(path.join(tDir, fname), transcriptText);
                }
            } else {
                // logging channel missing
                const tDir = path.join(__dirname, '../../data/transcripts');
                if (!fs.existsSync(tDir)) fs.mkdirSync(tDir, { recursive: true });
                const fname = `${guildId}_${channel.id}_${Date.now()}.txt`;
                fs.writeFileSync(path.join(tDir, fname), transcriptText);
            }
        } else {
            const tDir = path.join(__dirname, '../../data/transcripts');
            if (!fs.existsSync(tDir)) fs.mkdirSync(tDir, { recursive: true });
            const fname = `${guildId}_${channel.id}_${Date.now()}.txt`;
            fs.writeFileSync(path.join(tDir, fname), transcriptText);
        }

        // Final close: announce in channel then delete and cleanup DB
        try {
            await channel.send('🔒 Closing ticket in 5 seconds...');
            setTimeout(async () => {
                try {
                    const cid = channel.id;
                    await channel.delete();
                    data[guildId].tickets = data[guildId].tickets.filter(t => t.channelId !== cid);
                    setTicketData(data);
                } catch (err) {
                    console.error('Failed to delete channel after modal close', err);
                }
            }, 5000);
        } catch (err) {
            console.error('Failed to send closing message in channel', err);
        }
    }
};
