const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const common = require('../../functions/automationCommon');
const store = require('../../functions/automationStore');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('autodelete')
        .setDescription('Configure auto-deletion for messages')
        .addSubcommand(sub => sub.setName('add').setDescription('Add a channel to auto-delete').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)).addStringOption(opt => opt.setName('time').setDescription('Time before deletion (e.g. 10s, 1m)').setRequired(true)))
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset auto-delete settings for a channel').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove a channel from auto-delete').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
        .addSubcommand(sub => sub.setName('show').setDescription('Show auto-delete configurations'))
        .addSubcommandGroup(group => group.setName('whitelist').setDescription('Manage auto-delete whitelist')
            .addSubcommand(sub => sub.setName('add').setDescription('Add to whitelist').addUserOption(opt => opt.setName('user').setDescription('User')).addRoleOption(opt => opt.setName('role').setDescription('Role')))
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove from whitelist').addUserOption(opt => opt.setName('user').setDescription('User')).addRoleOption(opt => opt.setName('role').setDescription('Role')))
            .addSubcommand(sub => sub.setName('reset').setDescription('Reset whitelist'))
            .addSubcommand(sub => sub.setName('show').setDescription('Show whitelist'))),
    async execute(interaction) {
        if (!interaction.member.permissions.has('ManageMessages')) {
            return interaction.reply({ content: '❌ No access', flags: MessageFlags.Ephemeral });
        }
        const user = interaction.options.getUser('user');
        const role = interaction.options.getRole('role');
        await run(common.fromInteraction(interaction), interaction.options.getSubcommandGroup(false), interaction.options.getSubcommand(), {
            channel: interaction.options.getChannel('channel'),
            time: interaction.options.getString('time'),
            targets: [user && { type: 'user', id: user.id }, role && { type: 'role', id: role.id }].filter(Boolean),
        });
    },

    async executeMessage(message, args) {
        const first = args[0] ? args[0].toLowerCase() : 'help';
        if (first === 'help' || !['add', 'remove', 'reset', 'show', 'whitelist'].includes(first)) {
            return message.reply({ embeds: [common.helpEmbed(HELP, message)] });
        }
        const ctx = common.fromMessage(message);
        if (!message.member.permissions.has('ManageMessages')) return ctx.fail('No access');

        if (first === 'whitelist') {
            const sub = args[1] ? args[1].toLowerCase() : null;
            if (!['add', 'remove', 'reset', 'show'].includes(sub)) {
                return ctx.fail('Usage: `autodelete whitelist <add/remove/reset/show> [@user/@role]`');
            }
            const targets = [];
            if (sub === 'add' || sub === 'remove') {
                const t = await common.resolveAny(message.guild, args[2]);
                if (!t || (t.type !== 'user' && t.type !== 'role')) {
                    return ctx.fail(`Please mention a user or role. Usage: \`autodelete whitelist ${sub} @user/@role\``);
                }
                targets.push(t);
            }
            return run(ctx, 'whitelist', sub, { targets });
        }

        const channel = args[1] ? common.resolveChannel(message.guild, args[1]) : null;
        if ((first === 'add' || first === 'remove') && !channel) {
            return ctx.fail(`Please mention a channel. Usage: \`autodelete ${first} #channel${first === 'add' ? ' <time>' : ''}\``);
        }
        if (first === 'reset' && args[1] && !channel) return ctx.fail('Invalid channel provided.');
        return run(ctx, null, first, { channel, time: args[2] });
    },
};

const HELP =
    `» **autodelete add #channel <time>**\n› Auto-delete messages in a channel after a delay (e.g. 10s, 5m, 1h).\n\n` +
    `» **autodelete remove #channel**\n› Stop auto-deleting a channel.\n\n` +
    `» **autodelete reset [#channel]**\n› Reset one channel, or every channel if none is given.\n\n` +
    `» **autodelete show**\n› Show auto-delete configurations.\n\n` +
    `» **autodelete whitelist <add/remove/reset/show> [@user/@role]**\n› Messages from whitelisted users/roles are never deleted.`;

const MIN_MS = 2000;
const MAX_MS = 7 * 24 * 60 * 60 * 1000;

async function run(ctx, group, sub, o) {
    const cfg = store.get('autodelete', ctx.guild.id);
    const save = () => store.save('autodelete');

    if (group === 'whitelist') {
        switch (sub) {
            case 'add': {
                const t = o.targets[0];
                if (!t) return ctx.fail('Please provide a user or role.');
                if (cfg.whitelist.includes(t.id)) return ctx.fail('This user/role is already whitelisted.');
                cfg.whitelist.push(t.id);
                save();
                return ctx.ok(`Added ${t.type === 'role' ? `<@&${t.id}>` : `<@${t.id}>`} to the autodelete whitelist.`);
            }
            case 'remove': {
                const t = o.targets[0];
                if (!t) return ctx.fail('Please provide a user or role.');
                if (!cfg.whitelist.includes(t.id)) return ctx.fail('That user/role is not whitelisted.');
                cfg.whitelist = cfg.whitelist.filter(id => id !== t.id);
                save();
                return ctx.ok('Removed from the autodelete whitelist.');
            }
            case 'reset':
                cfg.whitelist = [];
                save();
                return ctx.ok('Reset the autodelete whitelist.');
            case 'show': {
                const text = cfg.whitelist.map(id => (ctx.guild.roles.cache.has(id) ? `<@&${id}>` : `<@${id}>`)).join(', ') || 'None';
                return ctx.send({ embeds: [new EmbedBuilder().setTitle('Autodelete Whitelist').setDescription(common.truncate(text, 4000)).setColor('#2b2d31')] });
            }
            default:
                return ctx.fail('Unknown subcommand.');
        }
    }

    switch (sub) {
        case 'add': {
            const channel = o.channel;
            if (!common.isTextChannel(channel)) return ctx.fail('Please choose a text channel.');
            const ms = common.parseDuration(o.time);
            if (!ms) return ctx.fail('Invalid time. Use s/m/h/d, e.g. `10s`, `5m`, `1h30m`.');
            if (ms < MIN_MS || ms > MAX_MS) return ctx.fail('Time must be between 2 seconds and 7 days.');
            cfg.channels[channel.id] = ms;
            save();
            const me = ctx.guild.members.me;
            const canDelete = me && channel.permissionsFor(me)?.has('ManageMessages');
            return ctx.ok(`Messages in ${channel} will be deleted after **${common.formatDuration(ms)}**.${canDelete ? '' : ' ⚠️ I am missing the Manage Messages permission there, so I cannot delete anything yet.'}`);
        }
        case 'remove':
        case 'reset': {
            if (!o.channel) {
                if (sub === 'remove') return ctx.fail('Please choose a channel.');
                cfg.channels = {};
                cfg.whitelist = [];
                save();
                return ctx.ok('Reset all autodelete settings.');
            }
            if (!cfg.channels[o.channel.id]) return ctx.fail(`${o.channel} is not set up for autodelete.`);
            delete cfg.channels[o.channel.id];
            save();
            return ctx.ok(sub === 'remove' ? `Removed ${o.channel} from autodelete.` : `Autodelete settings for ${o.channel} have been reset.`);
        }
        case 'show': {
            const lines = Object.entries(cfg.channels).map(([id, v]) => `<#${id}> — ${common.formatDuration(common.parseDuration(v) || 0)}`);
            return ctx.send({ embeds: [new EmbedBuilder()
                .setTitle('Autodelete Configuration')
                .setDescription(common.truncate(lines.join('\n') || 'No channels configured.', 4000))
                .addFields({ name: 'Whitelisted users/roles', value: String(cfg.whitelist.length), inline: true })
                .setColor('#2b2d31')] });
        }
        default:
            return ctx.fail('Unknown subcommand.');
    }
}
