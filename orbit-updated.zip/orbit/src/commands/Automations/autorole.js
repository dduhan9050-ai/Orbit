const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const common = require('../../functions/automationCommon');
const store = require('../../functions/automationStore');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('autorole')
        .setDescription('Configure auto-roles for new members and bots')
        .addSubcommand(sub => sub.setName('enable').setDescription('Enable auto-role module'))
        .addSubcommand(sub => sub.setName('disable').setDescription('Disable auto-role module'))
        .addSubcommand(sub => sub.setName('show').setDescription('Show auto-role settings'))
        .addSubcommandGroup(group => group.setName('humans').setDescription('Manage auto-roles for humans')
            .addSubcommand(sub => sub.setName('add').setDescription('Add a role for humans').addRoleOption(opt => opt.setName('role').setDescription('Role').setRequired(true)))
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove a role for humans').addRoleOption(opt => opt.setName('role').setDescription('Role').setRequired(true)))
            .addSubcommand(sub => sub.setName('reset').setDescription('Reset human auto-roles'))
            .addSubcommand(sub => sub.setName('show').setDescription('Show human auto-roles'))
            .addSubcommand(sub => sub.setName('enable').setDescription('Enable human auto-roles'))
            .addSubcommand(sub => sub.setName('disable').setDescription('Disable human auto-roles')))
        .addSubcommandGroup(group => group.setName('bots').setDescription('Manage auto-roles for bots')
            .addSubcommand(sub => sub.setName('add').setDescription('Add a role for bots').addRoleOption(opt => opt.setName('role').setDescription('Role').setRequired(true)))
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove a role for bots').addRoleOption(opt => opt.setName('role').setDescription('Role').setRequired(true)))
            .addSubcommand(sub => sub.setName('reset').setDescription('Reset bot auto-roles'))
            .addSubcommand(sub => sub.setName('show').setDescription('Show bot auto-roles'))
            .addSubcommand(sub => sub.setName('enable').setDescription('Enable bot auto-roles'))
            .addSubcommand(sub => sub.setName('disable').setDescription('Disable bot auto-roles'))),
    async execute(interaction) {
        if (!interaction.member.permissions.has('ManageRoles')) {
            return interaction.reply({ content: '❌ No access', flags: MessageFlags.Ephemeral });
        }
        const role = interaction.options.getRole('role');
        await run(common.fromInteraction(interaction), interaction.options.getSubcommandGroup(false), interaction.options.getSubcommand(), {
            role,
            roleId: role ? role.id : null,
        });
    },

    async executeMessage(message, args) {
        const first = args[0] ? args[0].toLowerCase() : 'help';
        if (first === 'help' || !['enable', 'disable', 'show', 'humans', 'bots'].includes(first)) {
            return message.reply({ embeds: [common.helpEmbed(HELP, message)] });
        }
        const ctx = common.fromMessage(message);
        if (!message.member.permissions.has('ManageRoles')) return ctx.fail('No access');

        if (first === 'humans' || first === 'bots') {
            const sub = args[1] ? args[1].toLowerCase() : null;
            if (!['add', 'remove', 'reset', 'show', 'enable', 'disable'].includes(sub)) {
                return ctx.fail(`Usage: \`autorole ${first} <add/remove/reset/show/enable/disable> [@role]\``);
            }
            let role = null;
            let roleId = null;
            if (sub === 'add' || sub === 'remove') {
                roleId = common.idFrom(args[2]);
                role = common.resolveRole(message.guild, args[2]);
                if (!roleId) return ctx.fail(`Please mention a role. Usage: \`autorole ${first} ${sub} @role\``);
            }
            return run(ctx, first, sub, { role, roleId });
        }
        return run(ctx, null, first, {});
    },
};

const HELP =
    `» **autorole enable/disable**\n› Enable or disable the auto-role module.\n\n` +
    `» **autorole show**\n› Show auto-role settings.\n\n` +
    `» **autorole humans <add/remove/reset/show/enable/disable> [@role]**\n› Manage auto-roles for humans.\n\n` +
    `» **autorole bots <add/remove/reset/show/enable/disable> [@role]**\n› Manage auto-roles for bots.`;

function rolesText(ids) {
    return ids.length ? ids.map(id => `<@&${id}>`).join(', ') : 'None';
}

async function run(ctx, group, sub, o) {
    const cfg = store.get('autorole', ctx.guild.id);
    const save = () => store.save('autorole');

    if (!group) {
        if (sub === 'enable') { cfg.enabled = true; save(); return ctx.ok('Autorole module has been enabled.'); }
        if (sub === 'disable') { cfg.enabled = false; save(); return ctx.ok('Autorole module has been disabled.'); }
        if (sub === 'show') {
            const embed = new EmbedBuilder()
                .setTitle('Autorole Configuration')
                .addFields(
                    { name: 'Module', value: cfg.enabled ? '✅ Enabled' : '❌ Disabled', inline: true },
                    { name: `Humans ${cfg.humansEnabled ? '✅' : '❌'}`, value: rolesText(cfg.humanRoles) },
                    { name: `Bots ${cfg.botsEnabled ? '✅' : '❌'}`, value: rolesText(cfg.botRoles) }
                )
                .setColor('#2b2d31');
            return ctx.send({ embeds: [embed] });
        }
        return ctx.fail('Unknown subcommand.');
    }

    const humans = group === 'humans';
    const rolesKey = humans ? 'humanRoles' : 'botRoles';
    const enabledKey = humans ? 'humansEnabled' : 'botsEnabled';
    const list = cfg[rolesKey];

    switch (sub) {
        case 'add': {
            const role = o.role;
            if (!role) return ctx.fail('That role was not found.');
            if (role.id === ctx.guild.id || role.managed) return ctx.fail('@everyone and integration/bot-managed roles cannot be used as auto-roles.');
            const me = ctx.guild.members.me;
            if (!me || me.roles.highest.comparePositionTo(role) <= 0) {
                return ctx.fail(`I can't assign ${role.name} because it is higher than (or equal to) my highest role. Move my role above it first.`);
            }
            if (list.includes(role.id)) return ctx.fail(`${role.name} is already in the ${group} auto-role list.`);
            if (list.length >= 10) return ctx.fail('You can set at most 10 auto-roles per group.');
            list.push(role.id);
            save();
            return ctx.ok(`Added ${role.name} to ${group} auto-roles.${cfg.enabled ? '' : ' (The module is disabled — run `autorole enable` to turn it on.)'}`);
        }
        case 'remove': {
            if (!o.roleId || !list.includes(o.roleId)) return ctx.fail(`That role is not in the ${group} auto-role list.`);
            cfg[rolesKey] = list.filter(id => id !== o.roleId);
            save();
            return ctx.ok(`Removed the role from ${group} auto-roles.`);
        }
        case 'reset':
            cfg[rolesKey] = [];
            save();
            return ctx.ok(`Reset ${group} auto-roles.`);
        case 'show':
            return ctx.send({ embeds: [new EmbedBuilder()
                .setTitle(`${humans ? 'Human' : 'Bot'} Auto-Roles ${cfg[enabledKey] ? '✅' : '❌'}`)
                .setDescription(rolesText(list))
                .setColor('#2b2d31')] });
        case 'enable':
            cfg[enabledKey] = true;
            save();
            return ctx.ok(`${humans ? 'Human' : 'Bot'} auto-roles enabled.`);
        case 'disable':
            cfg[enabledKey] = false;
            save();
            return ctx.ok(`${humans ? 'Human' : 'Bot'} auto-roles disabled.`);
        default:
            return ctx.fail('Unknown subcommand.');
    }
}
