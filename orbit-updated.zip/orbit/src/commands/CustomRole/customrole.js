const { EmbedBuilder, PermissionFlagsBits: P } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { makeCommand, UserError } = require('../../functions/commandKit');

const DATA_PATH = path.join(__dirname, '../../data/customrole.json');

/** key -> label / default role name used by `setup create` */
const ROLE_KINDS = {
    staff: { label: 'Staff', roleName: 'Staff' },
    vip: { label: 'VIP', roleName: 'VIP' },
    guest: { label: 'Guest', roleName: 'Guest' },
    friend: { label: 'Friend', roleName: 'Friend' },
    girl: { label: 'Girl', roleName: 'Girl' }
};

/** Roles carrying any of these can only be handed out by admins / owners. */
const DANGEROUS = [
    P.Administrator, P.ManageGuild, P.ManageRoles, P.ManageChannels,
    P.ManageWebhooks, P.BanMembers, P.KickMembers
];

// ------------------------------------------------------------------ storage
function readAll() {
    try {
        if (fs.existsSync(DATA_PATH)) return JSON.parse(fs.readFileSync(DATA_PATH, 'utf8')) || {};
    } catch (e) { /* fall through to empty */ }
    return {};
}

const blankConfig = () => ({
    reqRoles: [], staffRole: null, vipRole: null, guestRole: null, friendRole: null, girlRole: null, createdRoles: []
});

function getConfig(guildId) {
    const cfg = { ...blankConfig(), ...(readAll()[guildId] || {}) };
    if (!Array.isArray(cfg.reqRoles)) cfg.reqRoles = [];
    if (!Array.isArray(cfg.createdRoles)) cfg.createdRoles = [];
    return cfg;
}

function saveConfig(guildId, cfg) {
    const all = readAll();
    all[guildId] = cfg;
    fs.mkdirSync(path.dirname(DATA_PATH), { recursive: true });
    fs.writeFileSync(DATA_PATH, JSON.stringify(all, null, 2));
}

function deleteConfig(guildId) {
    const all = readAll();
    delete all[guildId];
    fs.writeFileSync(DATA_PATH, JSON.stringify(all, null, 2));
}

// ------------------------------------------------------------------ helpers
const roleMention = (id) => (id ? `<@&${id}>` : '*Not set*');

function configEmbed(guild) {
    const cfg = getConfig(guild.id);
    const lines = [
        `**Required Roles:** ${cfg.reqRoles.length ? cfg.reqRoles.map(roleMention).join(', ') : '*None*'}`,
        ...Object.entries(ROLE_KINDS).map(([key, { label }]) => `**${label} Role:** ${roleMention(cfg[`${key}Role`])}`)
    ];
    return new EmbedBuilder().setTitle('🎭 Custom Role Setup').setColor('#5865F2').setDescription(lines.join('\n'));
}

/** Who may hand out the custom roles. */
function canAssign(ctx, cfg) {
    if (ctx.isPrivileged() || ctx.member.permissions.has(P.Administrator)) return true;
    if (cfg.reqRoles.length) return cfg.reqRoles.some(id => ctx.member.roles.cache.has(id));
    return ctx.member.permissions.has(P.ManageRoles);
}

function blockEveryone(role) {
    if (role.id === role.guild.id) throw new UserError('You cannot use the @everyone role here.');
}

// ------------------------------------------------------------------ `setup`
const setRoleSub = (key) => ({
    description: `Configure ${ROLE_KINDS[key].label.toLowerCase()} role`,
    options: [{ name: 'role', type: 'role', description: 'Role', required: true }],
    async run(ctx, p) {
        ctx.checkRole(p.role, 'set');
        const cfg = getConfig(ctx.guild.id);
        cfg[`${key}Role`] = p.role.id;
        saveConfig(ctx.guild.id, cfg);
        await ctx.success(`${p.role} set as **${key}** role.`);
    }
});

const setup = makeCommand({
    name: 'setup',
    description: 'Configure custom roles for the server',
    perms: [P.ManageGuild],
    help:
        '» **setup reqrole set/remove/show [@role]**\n› Manage the roles allowed to hand out custom roles.\n\n' +
        '» **setup staff/vip/guest/friend/girl @role**\n› Choose the role behind each custom command.\n\n' +
        '» **setup create**\n› Create the missing roles automatically.\n\n' +
        '» **setup delete**\n› Delete this setup (and roles made by `setup create`).\n\n' +
        '» **setup list**\n› View all custom role setups.\n\n' +
        '» **setup reset**\n› Reset all custom role settings.',
    subs: {
        staff: setRoleSub('staff'),
        vip: setRoleSub('vip'),
        guest: setRoleSub('guest'),
        friend: setRoleSub('friend'),
        girl: setRoleSub('girl'),
        reset: {
            description: 'Reset custom role settings',
            async run(ctx) {
                saveConfig(ctx.guild.id, blankConfig());
                await ctx.success('Custom role setup has been reset.');
            }
        },
        create: {
            description: 'Create a custom role setup',
            botPerms: [P.ManageRoles],
            async run(ctx) {
                await ctx.defer();
                const cfg = getConfig(ctx.guild.id);
                const made = [];
                for (const [key, { roleName }] of Object.entries(ROLE_KINDS)) {
                    const current = cfg[`${key}Role`];
                    if (current && ctx.guild.roles.cache.has(current)) continue;
                    const role = await ctx.guild.roles.create({
                        name: roleName, mentionable: false, permissions: [], reason: `Custom role setup by ${ctx.member.user.tag}`
                    });
                    cfg[`${key}Role`] = role.id;
                    cfg.createdRoles.push(role.id);
                    made.push(role);
                }
                saveConfig(ctx.guild.id, cfg);
                await ctx.success(made.length
                    ? `Created and configured ${made.map(String).join(', ')}.\nMove them below my top role if you want me to assign them.`
                    : 'Every custom role is already configured — nothing to create.');
            }
        },
        delete: {
            description: 'Delete custom role setup',
            async run(ctx) {
                const cfg = getConfig(ctx.guild.id);
                const configured = Object.keys(ROLE_KINDS).some(k => cfg[`${k}Role`]) || cfg.reqRoles.length || cfg.createdRoles.length;
                if (!configured) throw new UserError('There is no custom role setup to delete.');
                await ctx.defer();
                let removed = 0, failed = 0;
                for (const id of cfg.createdRoles) {
                    const role = ctx.guild.roles.cache.get(id);
                    if (!role) continue;
                    try { await role.delete('Custom role setup deleted'); removed++; } catch (e) { failed++; }
                }
                deleteConfig(ctx.guild.id);
                await ctx.success('Custom role setup has been deleted.' +
                    (removed ? `\nDeleted **${removed}** role(s) that were created by \`setup create\`.` : '') +
                    (failed ? `\n⚠️ I could not delete **${failed}** role(s) — remove them manually.` : ''));
            }
        },
        list: {
            description: 'List all custom role setups',
            async run(ctx) { await ctx.send({ embeds: [configEmbed(ctx.guild)] }); }
        }
    },
    groups: {
        reqrole: {
            description: 'Manage required roles',
            subs: {
                show: {
                    description: 'Show required roles',
                    async run(ctx) {
                        const { reqRoles } = getConfig(ctx.guild.id);
                        await ctx.info(`**Required Roles:** ${reqRoles.length ? reqRoles.map(roleMention).join(', ') : '*None*'}`);
                    }
                },
                remove: {
                    description: 'Remove a required role',
                    options: [{ name: 'role', type: 'role', description: 'Role', required: true }],
                    async run(ctx, p) {
                        const cfg = getConfig(ctx.guild.id);
                        if (!cfg.reqRoles.includes(p.role.id)) throw new UserError(`${p.role} is not a required role.`);
                        cfg.reqRoles = cfg.reqRoles.filter(id => id !== p.role.id);
                        saveConfig(ctx.guild.id, cfg);
                        await ctx.success(`${p.role} removed from required roles.`);
                    }
                },
                set: {
                    description: 'Set a required role',
                    options: [{ name: 'role', type: 'role', description: 'Role', required: true }],
                    async run(ctx, p) {
                        blockEveryone(p.role);
                        const cfg = getConfig(ctx.guild.id);
                        if (cfg.reqRoles.includes(p.role.id)) throw new UserError(`${p.role} is already a required role.`);
                        cfg.reqRoles.push(p.role.id);
                        saveConfig(ctx.guild.id, cfg);
                        await ctx.success(`${p.role} added as required role.`);
                    }
                }
            }
        }
    }
});

// ------------------------------------------------------------------ /staff /vip /guest /friend /girl
function toggleCommand(key) {
    const { label } = ROLE_KINDS[key];
    return makeCommand({
        name: key,
        description: `Assign or remove ${label} role`,
        options: [{ name: 'user', type: 'user', description: 'The user', required: true }],
        async run(ctx, p) {
            const cfg = getConfig(ctx.guild.id);
            const roleId = cfg[`${key}Role`];
            if (!roleId) throw new UserError(`${label} role not configured. Use \`setup ${key} @role\` first.`);

            // access: owners / admins / holders of a required role (or Manage Roles when none are set)
            if (!canAssign(ctx, cfg)) throw new UserError('❌ No access');

            const role = ctx.guild.roles.cache.get(roleId);
            if (!role) throw new UserError(`Configured ${label} role no longer exists. Set it again with \`setup ${key} @role\`.`);
            ctx.requireBotPerms([P.ManageRoles]);
            if (role.managed) throw new UserError('That role is managed by an integration and cannot be assigned manually.');
            if (ctx.guild.members.me.roles.highest.comparePositionTo(role) <= 0) {
                throw new UserError(`I can't manage ${role} — it is equal to or higher than my top role.`);
            }
            const trusted = ctx.isPrivileged() || ctx.member.permissions.has(P.Administrator);
            if (!trusted && DANGEROUS.some(flag => role.permissions.has(flag))) {
                throw new UserError(`${role} has moderation permissions, so only the owner or administrators can hand it out.`);
            }

            const target = p.user.member;
            if (!target) throw new UserError('That user is not in this server.');

            if (target.roles.cache.has(role.id)) {
                await target.roles.remove(role, `${label} role removed by ${ctx.member.user.tag}`);
                await ctx.success(`Removed ${role} from ${target}.`);
            } else {
                await target.roles.add(role, `${label} role added by ${ctx.member.user.tag}`);
                await ctx.success(`Added ${role} to ${target}.`);
            }
        }
    });
}

module.exports = [setup, ...Object.keys(ROLE_KINDS).map(toggleCommand)];
