const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const embedHelper = require('../../functions/embedHelper');
const antinuke = require('../../functions/antinukeManager');
const permit = require('../../functions/permitManager');

const SUBCOMMANDS = ['add', 'remove', 'show', 'reset'];

function helpEmbed(user) {
    return new EmbedBuilder()
        .setTitle('Orbit™ mainrole [4]')
        .setDescription(
            '```\n<..> <required> | [..] [optional]\n```\n\n' +
            '» **mainrole add <role>**\n› Add a main role.\n\n' +
            '» **mainrole remove <role>**\n› Remove a main role.\n\n' +
            '» **mainrole show**\n› Show all main roles.\n\n' +
            '» **mainrole reset**\n› Reset all main roles.'
        )
        .setColor('#2b2d31')
        .setFooter({ text: `Page 1/1 | Requested by ${user.username}`, iconURL: user.displayAvatarURL() });
}

// Shared logic for slash + prefix. Returns an embed.
function run(guildId, subcommand, role) {
    const config = antinuke.getConfig(guildId);
    const mainRoles = Array.isArray(config.mainRoles) ? config.mainRoles : [];

    if (subcommand === 'show') {
        if (!mainRoles.length) return embedHelper.info('No main roles configured.');
        return embedHelper.info(`Main roles: ${mainRoles.map(id => `<@&${id}>`).join(', ')}`);
    }
    if (subcommand === 'reset') {
        antinuke.setConfig(guildId, { mainRoles: [] });
        return embedHelper.success('All main roles have been reset.');
    }
    if (!role) {
        return embedHelper.error(`Please provide a role to ${subcommand}.`);
    }
    if (subcommand === 'add') {
        if (mainRoles.includes(role.id)) return embedHelper.info('This role is already a main role.');
        antinuke.setConfig(guildId, { mainRoles: [...mainRoles, role.id] });
        return embedHelper.success(`Added ${role} as a main role.`);
    }
    // remove
    if (!mainRoles.includes(role.id)) return embedHelper.info('This role is not a main role.');
    antinuke.setConfig(guildId, { mainRoles: mainRoles.filter(id => id !== role.id) });
    return embedHelper.success(`Removed ${role} from main roles.`);
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('mainrole')
        .setDescription('Security: Configure main roles for the server')
        .addSubcommand(sub => sub.setName('add').setDescription('Add a main role').addRoleOption(opt => opt.setName('role').setDescription('The role to add').setRequired(true)))
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove a main role').addRoleOption(opt => opt.setName('role').setDescription('The role to remove').setRequired(true)))
        .addSubcommand(sub => sub.setName('show').setDescription('Show all main roles'))
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset all main roles')),

    async execute(interaction) {
        // Only server owner or extra owners can use security commands
        const isOwner = interaction.user.id === interaction.guild.ownerId;
        const isEO = permit.isExtraOwner(interaction.guild.id, interaction.user.id);
        if (!isOwner && !isEO) {
            return interaction.reply({ content: '❌ No access - Only server owner or extra owners can use this command', flags: MessageFlags.Ephemeral });
        }

        const subcommand = interaction.options.getSubcommand(false);
        if (!subcommand) return interaction.reply({ embeds: [helpEmbed(interaction.user)] });

        const role = interaction.options.getRole('role');
        return interaction.reply({ embeds: [run(interaction.guild.id, subcommand, role)] });
    },

    async executeMessage(message, args) {
        // Only server owner or extra owners can use security commands
        const isOwner = message.author.id === message.guild.ownerId;
        const isEO = permit.isExtraOwner(message.guild.id, message.author.id);
        if (!isOwner && !isEO) {
            return message.reply({ embeds: [embedHelper.error('❌ No access - Only server owner or extra owners can use this command')] });
        }

        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        if (!SUBCOMMANDS.includes(subcommand)) {
            return message.reply({ embeds: [helpEmbed(message.author)] });
        }

        // role can be a mention, a raw ID, or a role name
        let role = message.mentions.roles.first();
        if (!role && args[1]) {
            const raw = args[1].replace(/[<@&>]/g, '');
            role = message.guild.roles.cache.get(raw)
                || message.guild.roles.cache.find(r => r.name.toLowerCase() === args.slice(1).join(' ').toLowerCase());
        }
        return message.reply({ embeds: [run(message.guild.id, subcommand, role)] });
    }
};
