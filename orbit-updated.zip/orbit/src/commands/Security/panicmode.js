const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const embedHelper = require('../../functions/embedHelper');
const antinuke = require('../../functions/antinukeManager');
const permit = require('../../functions/permitManager');

const SUBCOMMANDS = ['enable', 'disable', 'set', 'reset'];

function helpEmbed(user) {
    return new EmbedBuilder()
        .setDescription(
            '```\n<..> <required> | [..] [optional]\n```\n\n' +
            '» **panicmode enable**\n› Enable panic mode.\n\n' +
            '» **panicmode disable**\n› Disable panic mode.\n\n' +
            '» **panicmode set <threshold> [duration seconds]**\n› Configure settings.\n\n' +
            '» **panicmode reset**\n› Reset settings.'
        )
        .setColor('#2b2d31')
        .setFooter({ text: `Page 1/1 | Requested by ${user.username}`, iconURL: user.displayAvatarURL() });
}

function settingsText(cfg) {
    return `• Threshold: ${cfg.thresholdHeat}\n• Duration: ${cfg.panicDuration || antinuke.DEFAULT_CONFIG.panicDuration}s\n• Decay Rate: ${cfg.decayAmount}/min`;
}

// Shared logic for slash + prefix. Returns an embed.
function run(guildId, client, subcommand, threshold, duration) {
    const config = antinuke.getConfig(guildId);
    const footer = { text: 'Orbit™ Panic System', iconURL: client.user.displayAvatarURL() };

    if (!config.enabled) {
        return embedHelper.error('Antinuke system is disabled. You must enable it first to use Panic Mode.');
    }

    if (subcommand === 'enable') {
        antinuke.setConfig(guildId, { panicMode: true });
        return new EmbedBuilder()
            .setDescription(`✅ **Panic Mode System Enabled**\nThe bot will now automatically trigger Z+ mode if server heat exceeds the threshold.\n\n**Settings Configured:**\n${settingsText(antinuke.getConfig(guildId))}`)
            .setColor('#00ff00').setFooter(footer);
    }

    if (subcommand === 'disable') {
        antinuke.setConfig(guildId, { panicMode: false });
        return new EmbedBuilder()
            .setDescription('✅ **Panic Mode System Disabled**\nThe automated panic mode system has been turned off.')
            .setColor('#ff0000').setFooter(footer);
    }

    if (subcommand === 'set') {
        if (!threshold && !duration) {
            return embedHelper.info(`**Current panic mode settings**\n${settingsText(config)}\n\nUsage: \`panicmode set <threshold> [duration seconds]\``);
        }
        const partial = {};
        if (threshold) partial.thresholdHeat = threshold;
        if (duration) partial.panicDuration = duration;
        antinuke.setConfig(guildId, partial);
        return new EmbedBuilder()
            .setDescription(`✅ **Panic Mode Settings Updated**\n\n${settingsText(antinuke.getConfig(guildId))}`)
            .setColor('#00ff00').setFooter(footer);
    }

    // reset
    antinuke.setConfig(guildId, {
        panicMode: false,
        panicDuration: antinuke.DEFAULT_CONFIG.panicDuration,
        thresholdHeat: antinuke.DEFAULT_CONFIG.thresholdHeat
    });
    return embedHelper.success('Panic mode has been disabled and its settings were reset to defaults.');
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('panicmode')
        .setDescription('Security: Configure server panic mode')
        .addSubcommand(sub => sub.setName('enable').setDescription('Enable panic mode'))
        .addSubcommand(sub => sub.setName('disable').setDescription('Disable panic mode'))
        .addSubcommand(sub => sub.setName('set').setDescription('Set panic mode settings')
            .addIntegerOption(o => o.setName('threshold').setDescription('Heat threshold that triggers panic mode').setMinValue(1).setRequired(false))
            .addIntegerOption(o => o.setName('duration').setDescription('Seconds Z+ stays active after triggering').setMinValue(10).setMaxValue(86400).setRequired(false)))
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset panic mode settings')),

    async execute(interaction) {
        // Only server owner or extra owners can use security commands
        const isOwner = interaction.user.id === interaction.guild.ownerId;
        const isEO = permit.isExtraOwner(interaction.guild.id, interaction.user.id);
        if (!isOwner && !isEO) {
            return interaction.reply({ content: '❌ No access - Only server owner or extra owners can use this command', flags: MessageFlags.Ephemeral });
        }

        const subcommand = interaction.options.getSubcommand();
        const embed = run(
            interaction.guild.id, interaction.client, subcommand,
            interaction.options.getInteger('threshold'), interaction.options.getInteger('duration')
        );
        return interaction.reply({ embeds: [embed] });
    },

    async executeMessage(message, args) {
        // Only server owner or extra owners can use security commands
        const isOwner = message.author.id === message.guild.ownerId;
        const isEO = permit.isExtraOwner(message.guild.id, message.author.id);
        if (!isOwner && !isEO) {
            return message.reply({ embeds: [embedHelper.error('❌ No access - Only server owner or extra owners can use this command')] });
        }

        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        if (!SUBCOMMANDS.includes(subcommand)) {
            return message.reply({ embeds: [helpEmbed(message.author)] });
        }

        let threshold = null;
        let duration = null;
        if (subcommand === 'set') {
            threshold = parseInt(args[1], 10);
            duration = args[2] !== undefined ? parseInt(args[2], 10) : null;
            if ((args[1] !== undefined && (isNaN(threshold) || threshold < 1)) || (duration !== null && (isNaN(duration) || duration < 10))) {
                return message.reply({ embeds: [embedHelper.error('Usage: `panicmode set <threshold ≥ 1> [duration seconds ≥ 10]`')] });
            }
            if (isNaN(threshold)) threshold = null;
        }
        return message.reply({ embeds: [run(message.guild.id, message.client, subcommand, threshold, duration)] });
    }
};
