const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, PermissionsBitField, MessageFlags } = require('discord.js');
const antinuke = require('../../functions/antinukeManager');
const permissionChecker = require('../../functions/permissionChecker');

const ALL_SUBS_VIA_MESSAGE = ['whitelist', 'logging', 'logdisable', 'limit', 'autorecovery', 'reset'];

// Creates the barrier role, enables antinuke with every filter on
async function runWizard(guild, channelId) {
    const me = guild.members.me || await guild.members.fetch(guild.client.user.id);
    if (!me.permissions.has(PermissionsBitField.Flags.Administrator)) throw new Error('NEED_ADMIN');

    const role = await guild.roles.create({
        name: 'ZEON Barrier [Z+]',
        permissions: [PermissionsBitField.Flags.Administrator],
        reason: 'Antinuke wizard barrier role'
    });
    await role.setPosition(Math.max(1, me.roles.highest.position - 1)).catch(() => { });
    await me.roles.add(role.id, 'Antinuke wizard barrier role assignment').catch(() => { });

    const filters = {};
    for (const key of Object.keys(antinuke.DEFAULT_FILTERS)) filters[key] = true;
    antinuke.setConfig(guild.id, { enabled: true, zplus: false, loggingChannel: channelId, filters });
    return role;
}

// Lets slash subcommands reuse the prefix implementation
function makeMessageShim(interaction) {
    let replied = false;
    return {
        author: interaction.user,
        member: interaction.member,
        guild: interaction.guild,
        channel: interaction.channel,
        client: interaction.client,
        mentions: {
            users: { first: () => interaction.options.getUser('user') || null },
            channels: { first: () => interaction.options.getChannel('channel') || null }
        },
        reply: async (payload) => {
            const body = typeof payload === 'string' ? { content: payload } : { ...payload };
            body.flags = MessageFlags.Ephemeral;
            if (!replied) { replied = true; return interaction.reply(body); }
            return interaction.followUp(body);
        }
    };
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('antinuke')
        .setDescription('Security: Configure Antinuke modules')
        .addSubcommand(sub => sub.setName('enable').setDescription('Enable Antinuke module'))
        .addSubcommand(sub => sub.setName('disable').setDescription('Disable Antinuke module'))
        .addSubcommand(sub => sub.setName('whitelist').setDescription('Whitelist a user from Antinuke').addUserOption(o => o.setName('user').setDescription('User to whitelist').setRequired(false)))
        .addSubcommand(sub => sub.setName('wizard').setDescription('Setup Antinuke via wizard'))
        .addSubcommand(sub => sub.setName('zplus').setDescription('Configure Z+ protection'))
        .addSubcommand(sub => sub.setName('autorecovery').setDescription('Configure auto recovery'))
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset Antinuke settings'))
        .addSubcommand(sub => sub.setName('logging').setDescription('Configure Antinuke logging').addChannelOption(o => o.setName('channel').setDescription('Channel for logs').setRequired(false)))
        .addSubcommand(sub => sub.setName('config').setDescription('Show Antinuke configuration'))
        .addSubcommand(sub => sub.setName('limit').setDescription('Configure Antinuke limits')
            .addStringOption(o => o.setName('type').setDescription('Which limit to change').setRequired(false).addChoices({ name: 'minute', value: 'minute' }, { name: 'hour', value: 'hour' }, { name: 'heat', value: 'heat' }, { name: 'threshold', value: 'threshold' }))
            .addIntegerOption(o => o.setName('value').setDescription('New value').setRequired(false).setMinValue(1)))
        .addSubcommand(sub => sub.setName('manage').setDescription('Manage Antinuke settings'))
        .addSubcommand(sub => sub.setName('logdisable').setDescription('Disable Antinuke logging')),

    async execute(interaction) {
        // Only server owner or extra owners can use security commands
        const permit = require('../../functions/permitManager');
        const isOwner = interaction.user.id === interaction.guild.ownerId;
        const isEO = permit.isExtraOwner(interaction.guild.id, interaction.user.id);
        
        if (!isOwner && !isEO) {
            return interaction.reply({ content: '❌ No access - Only server owner or extra owners can use this command', flags: MessageFlags.Ephemeral });
        }

        const subcommand = interaction.options.getSubcommand(false);
        const guildId = interaction.guild.id;

        if (ALL_SUBS_VIA_MESSAGE.includes(subcommand)) {
            const args = [subcommand];
            if (subcommand === 'limit') {
                const type = interaction.options.getString('type');
                const value = interaction.options.getInteger('value');
                if (type && value !== null) args.push(type, String(value));
            }
            return module.exports.executeMessage(makeMessageShim(interaction), args);
        }

        const showSetupUI = async (interaction, guildId) => {
            const getResponse = () => {
                const cfg = antinuke.getConfig(guildId);
                const filters = [
                    ['ban', 'Ban'], ['kick', 'Kick'], ['prune', 'Prune'], ['memberUpdate', 'Member Update'],
                    ['roleCreate', 'Role Create'], ['roleDelete', 'Role Delete'], ['roleUpdate', 'Role Update'],
                    ['channelCreate', 'Channel Create'], ['channelDelete', 'Channel Delete'], ['channelUpdate', 'Channel Update'],
                    ['webhookCreate', 'Webhook Create'], ['webhookDelete', 'Webhook Delete'], ['webhookUpdate', 'Webhook Update'],
                    ['botAdd', 'Bot Add'], ['guildUpdate', 'Guild Update'], ['mentionSpam', 'Mention Spam']
                ];

                const left = filters.slice(0, Math.ceil(filters.length / 2));
                const right = filters.slice(Math.ceil(filters.length / 2));

                const formatLine = ([k, label]) => `> **${label}** : ${cfg.filters && cfg.filters[k] ? '✅' : '❌'}`;
                const descLeft = left.map(formatLine).join('\n');
                const descRight = right.map(formatLine).join('\n');

                const embed = new EmbedBuilder()
                    .setTitle('Setup Antinuke !')
                    .setDescription("Orbit ™'s Antinuke is likely the one of the most advanced Antinuke system for discord , see all the commands and explore more , use the /antinuke wizard command if you messed anything or you want the best settings for antinuke for your server")
                    .addFields(
                        { name: 'Filters [1]:', value: descLeft || 'None', inline: true },
                        { name: 'Filters [2]:', value: descRight || 'None', inline: true }
                    )
                    .setColor('#2b2d31');

                const { StringSelectMenuBuilder } = require('discord.js');

                // Enable Menu
                const enableSelect = new StringSelectMenuBuilder()
                    .setCustomId('antinuke_manage_enable')
                    .setPlaceholder('Enable Antinuke Filters')
                    .setMinValues(1)
                    .setMaxValues(filters.length)
                    .addOptions(filters.map(([k, label]) => ({ label, value: k })));

                // Disable Menu
                const disableSelect = new StringSelectMenuBuilder()
                    .setCustomId('antinuke_manage_disable')
                    .setPlaceholder('Disable Antinuke Filters')
                    .setMinValues(1)
                    .setMaxValues(filters.length)
                    .addOptions(filters.map(([k, label]) => ({ label, value: k })));

                const rowEnable = new ActionRowBuilder().addComponents(enableSelect);
                const rowDisable = new ActionRowBuilder().addComponents(disableSelect);

                const rowButtons = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder().setLabel('Setup Done').setCustomId('antinuke_manage_done').setStyle(ButtonStyle.Success).setEmoji('✅'),
                        new ButtonBuilder().setLabel('Show Rules').setStyle(ButtonStyle.Link).setURL('https://example.com/rules')
                    );

                return { embeds: [embed], components: [rowEnable, rowDisable, rowButtons] };
            };

            const response = await interaction.reply({ ...getResponse(), ephemeral: true });

            const collector = response.createMessageComponentCollector({ filter: i => i.customId && i.customId.startsWith('antinuke_manage'), time: 300000 });

            collector.on('collect', async i => {
                if (i.user.id !== interaction.user.id) return i.reply({ content: 'Only the user who ran the command can use these controls.', ephemeral: true });

                const cfg = antinuke.getConfig(guildId);
                const currentFilters = cfg.filters || {};

                if (i.customId === 'antinuke_manage_enable') {
                    const toEnable = i.values;
                    for (const key of toEnable) currentFilters[key] = true;
                    antinuke.setConfig(guildId, { filters: currentFilters });
                    await i.update(getResponse());
                    return;
                }

                if (i.customId === 'antinuke_manage_disable') {
                    const toDisable = i.values;
                    for (const key of toDisable) currentFilters[key] = false;
                    antinuke.setConfig(guildId, { filters: currentFilters });
                    await i.update(getResponse());
                    return;
                }

                if (i.customId === 'antinuke_manage_done') {
                    await i.update({ content: 'Setup finished.', components: [] });
                    return collector.stop();
                }
            });

            collector.on('end', async () => {
                try { await interaction.editReply({ components: [] }); } catch (e) { }
            });
        };

        if (subcommand === 'manage') {
            await showSetupUI(interaction, guildId);
            return;
        }

        if (subcommand === 'enable') {
            const cfg = antinuke.getConfig(guildId);
            if (cfg.enabled) {
                await interaction.reply({ content: 'Antinuke is already enabled.', ephemeral: true });
                // Optionally proceed to setup even if already enabled, but usually user wants to toggle it on.
                // User asked to show the setup UI when enabling.
                await showSetupUI(interaction, guildId);
                return;
            }
            antinuke.setConfig(guildId, { enabled: true });
            // Show setup UI as requested
            await showSetupUI(interaction, guildId);
            return;
        }

        if (subcommand === 'disable') {
            const cfg = antinuke.getConfig(guildId);
            if (!cfg.enabled) {
                await interaction.reply({ content: 'Antinuke is already disabled.', ephemeral: true });
                return;
            }
            antinuke.setConfig(guildId, { enabled: false });
            await interaction.reply({ content: 'Antinuke module has been disabled.', ephemeral: true });
            return;
        }

        if (subcommand === 'wizard') {
            try {
                const role = await runWizard(interaction.guild, interaction.channel.id);
                await interaction.reply({ content: `Wizard complete. Created role ${role.name}, enabled Antinuke and turned on all filters.`, flags: MessageFlags.Ephemeral });
            } catch (e) {
                console.error('Wizard error:', e);
                await interaction.reply({ content: e.message === 'NEED_ADMIN' ? 'I need the Administrator permission to run the wizard.' : 'Failed to run wizard. Check bot permissions.', flags: MessageFlags.Ephemeral });
            }
            return;
        }

        if (subcommand === 'zplus') {
            const active = antinuke.toggleZplus(guildId);
            const text = active ? 'Z+ mode activated. Server is in lockdown.' : 'Z+ mode deactivated. Settings restored.';
            return interaction.reply({ content: text, flags: MessageFlags.Ephemeral });
        }

        if (subcommand === 'config') {
            const cfg = antinuke.getConfig(guildId) || {};
            const embedCfg = new EmbedBuilder()
                .setTitle('Antinuke Configuration')
                .setColor('#2b2d31')
                .addFields(
                    { name: 'Enabled', value: `${cfg.enabled ? 'Yes' : 'No'}`, inline: true },
                    { name: 'Z+ Mode', value: `${cfg.zplus ? 'Active' : 'Inactive'}`, inline: true },
                    { name: 'Logging Channel', value: `${cfg.loggingChannel ? `<#${cfg.loggingChannel}>` : 'Not set'}`, inline: false },
                    { name: 'Minute Limit', value: `${cfg.minuteLimit ?? antinuke.DEFAULT_CONFIG.minuteLimit}`, inline: true },
                    { name: 'Hour Limit', value: `${cfg.hourLimit ?? antinuke.DEFAULT_CONFIG.hourLimit}`, inline: true },
                    { name: 'Heat / Action', value: `${cfg.heatPerAction ?? antinuke.DEFAULT_CONFIG.heatPerAction}`, inline: true },
                    { name: 'Threshold Heat', value: `${cfg.thresholdHeat ?? antinuke.DEFAULT_CONFIG.thresholdHeat}`, inline: true },
                    { name: 'Whitelist', value: `${(cfg.whitelist && cfg.whitelist.length) ? cfg.whitelist.map(id => `<@${id}>`).join(', ') : 'None'}`, inline: false }
                )
                .setFooter({ text: `Requested by ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL() });

            await interaction.reply({ embeds: [embedCfg] });
            return;
        }



        // Fallback for other subcommands: simple acknowledgment
        const embed = new EmbedBuilder()
            .setTitle(`Antinuke: ${subcommand}`)
            .setDescription(`You have triggered the **${subcommand}** module of Antinuke.`)
            .setColor('#2b2d31')
            .setFooter({ text: `Orbit™ Antinuke System`, iconURL: interaction.client.user.displayAvatarURL() });

        await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
    },
    async executeMessage(message, args) {
        // Only server owner or extra owners can use security commands
        const permit = require('../../functions/permitManager');
        const isOwner = message.author.id === message.guild.ownerId;
        const isEO = permit.isExtraOwner(message.guild.id, message.author.id);
        
        if (!isOwner && !isEO) {
            return message.reply('❌ No access - Only server owner or extra owners can use this command');
        }

        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        const embed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **antinuke enable/disable**\n› Manager modules.\n\n` +
                `» **antinuke wizard**\n› Setup wizard.\n\n` +
                `» **antinuke whitelist**\n› Whitelist users.\n\n` +
                `» **antinuke config/logging**\n› Configuration.\n\n` +
                `» **antinuke zplus**\n› Z+ protection.\n\n` +
                `» **antinuke limit/manage**\n› Limit management.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        if (subcommand === 'help' || !['enable', 'disable', 'wizard', 'whitelist', 'config', 'zplus', 'logging', 'limit', 'manage', 'logdisable', 'autorecovery', 'reset'].includes(subcommand)) {
            return message.reply({ embeds: [embed] });
        }

        const guildId = message.guild.id;

        // Interactive setup UI for message-based commands
        const showSetupUIForMessage = async (message, guildId) => {
            const { StringSelectMenuBuilder } = require('discord.js');
            
            const getResponse = () => {
                const cfg = antinuke.getConfig(guildId);
                const filters = [
                    ['ban', 'Ban'], ['kick', 'Kick'], ['prune', 'Prune'], ['memberUpdate', 'Member Update'],
                    ['roleCreate', 'Role Create'], ['roleDelete', 'Role Delete'], ['roleUpdate', 'Role Update'],
                    ['channelCreate', 'Channel Create'], ['channelDelete', 'Channel Delete'], ['channelUpdate', 'Channel Update'],
                    ['webhookCreate', 'Webhook Create'], ['webhookDelete', 'Webhook Delete'], ['webhookUpdate', 'Webhook Update'],
                    ['botAdd', 'Bot Add'], ['guildUpdate', 'Guild Update'], ['mentionSpam', 'Mention Spam']
                ];

                const left = filters.slice(0, Math.ceil(filters.length / 2));
                const right = filters.slice(Math.ceil(filters.length / 2));

                const formatLine = ([k, label]) => `> **${label}** : ${cfg.filters && cfg.filters[k] ? '✅' : '❌'}`;
                const descLeft = left.map(formatLine).join('\n');
                const descRight = right.map(formatLine).join('\n');

                const embedUI = new EmbedBuilder()
                    .setTitle('Setup Antinuke !')
                    .setDescription("Orbit ™'s Antinuke is likely the one of the most advanced Antinuke system for discord , see all the commands and explore more , use the !antinuke wizard command if you messed anything or you want the best settings for antinuke for your server")
                    .addFields(
                        { name: 'Filters [1]:', value: descLeft || 'None', inline: true },
                        { name: 'Filters [2]:', value: descRight || 'None', inline: true }
                    )
                    .setColor('#2b2d31');

                // Enable Menu
                const enableSelect = new StringSelectMenuBuilder()
                    .setCustomId('antinuke_manage_enable')
                    .setPlaceholder('Enable Antinuke Filters')
                    .setMinValues(1)
                    .setMaxValues(filters.length)
                    .addOptions(filters.map(([k, label]) => ({ label, value: k })));

                // Disable Menu
                const disableSelect = new StringSelectMenuBuilder()
                    .setCustomId('antinuke_manage_disable')
                    .setPlaceholder('Disable Antinuke Filters')
                    .setMinValues(1)
                    .setMaxValues(filters.length)
                    .addOptions(filters.map(([k, label]) => ({ label, value: k })));

                const rowEnable = new ActionRowBuilder().addComponents(enableSelect);
                const rowDisable = new ActionRowBuilder().addComponents(disableSelect);

                const rowButtons = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder().setLabel('Setup Done').setCustomId('antinuke_manage_done').setStyle(ButtonStyle.Success).setEmoji('✅'),
                        new ButtonBuilder().setLabel('Show Rules').setStyle(ButtonStyle.Link).setURL('https://example.com/rules')
                    );

                return { embeds: [embedUI], components: [rowEnable, rowDisable, rowButtons] };
            };

            const response = await message.reply(getResponse());

            const collector = response.createMessageComponentCollector({ 
                filter: i => i.customId && i.customId.startsWith('antinuke_manage') && i.user.id === message.author.id, 
                time: 300000 
            });

            collector.on('collect', async i => {
                const cfg = antinuke.getConfig(guildId);
                const currentFilters = cfg.filters || {};

                if (i.customId === 'antinuke_manage_enable') {
                    const toEnable = i.values;
                    for (const key of toEnable) currentFilters[key] = true;
                    antinuke.setConfig(guildId, { filters: currentFilters });
                    await i.update(getResponse());
                    return;
                }

                if (i.customId === 'antinuke_manage_disable') {
                    const toDisable = i.values;
                    for (const key of toDisable) currentFilters[key] = false;
                    antinuke.setConfig(guildId, { filters: currentFilters });
                    await i.update(getResponse());
                    return;
                }

                if (i.customId === 'antinuke_manage_done') {
                    await i.update({ content: '✅ Setup finished! Antinuke filters have been configured.', embeds: [], components: [] });
                    return collector.stop();
                }
            });

            collector.on('end', async () => {
                try { 
                    await response.edit({ components: [] }); 
                } catch (e) { }
            });
        };

        if (subcommand === 'disable') {
            const cfg = antinuke.getConfig(guildId);
            if (!cfg.enabled) return message.reply('Antinuke is already disabled.');
            antinuke.setConfig(guildId, { enabled: false });
            return message.reply('Antinuke module has been disabled.');
        }

        if (subcommand === 'enable') {
            const cfg = antinuke.getConfig(guildId);
            antinuke.setConfig(guildId, { enabled: true });
            // Show interactive setup UI
            await showSetupUIForMessage(message, guildId);
            return;
        }

        if (subcommand === 'manage') {
            await showSetupUIForMessage(message, guildId);
            return;
        }

        if (subcommand === 'config') {
            const cfg = antinuke.getConfig(guildId) || {};
            const embedCfg = new EmbedBuilder()
                .setTitle('Antinuke Configuration')
                .setColor('#2b2d31')
                .addFields(
                    { name: 'Enabled', value: `${cfg.enabled ? 'Yes' : 'No'}`, inline: true },
                    { name: 'Z+ Mode', value: `${cfg.zplus ? 'Active' : 'Inactive'}`, inline: true },
                    { name: 'Logging Channel', value: `${cfg.loggingChannel ? `<#${cfg.loggingChannel}>` : 'Not set'}`, inline: false },
                    { name: 'Minute Limit', value: `${cfg.minuteLimit ?? antinuke.DEFAULT_CONFIG.minuteLimit}`, inline: true },
                    { name: 'Hour Limit', value: `${cfg.hourLimit ?? antinuke.DEFAULT_CONFIG.hourLimit}`, inline: true },
                    { name: 'Heat / Action', value: `${cfg.heatPerAction ?? antinuke.DEFAULT_CONFIG.heatPerAction}`, inline: true },
                    { name: 'Threshold Heat', value: `${cfg.thresholdHeat ?? antinuke.DEFAULT_CONFIG.thresholdHeat}`, inline: true },
                    { name: 'Whitelist', value: `${(cfg.whitelist && cfg.whitelist.length) ? cfg.whitelist.map(id => `<@${id}>`).join(', ') : 'None'}`, inline: false }
                )
                .setFooter({ text: `Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

            return message.reply({ embeds: [embedCfg] });
        }

        if (subcommand === 'zplus') {
            const active = antinuke.toggleZplus(guildId);
            const text = active ? 'Z+ mode activated. Server is in lockdown.' : 'Z+ mode deactivated. Settings restored.';
            return message.reply(text);
        }

        if (subcommand === 'logdisable') {
            antinuke.setConfig(guildId, { loggingChannel: null });
            return message.reply('Antinuke logging has been disabled.');
        }

        if (subcommand === 'logging') {
            const channel = message.mentions.channels.first() || message.channel;
            antinuke.setConfig(guildId, { loggingChannel: channel.id });
            return message.reply(`Antinuke logging channel set to ${channel}.`);
        }

        if (subcommand === 'reset') {
            antinuke.resetConfig(guildId);
            return message.reply('Antinuke settings have been reset to defaults.');
        }

        if (subcommand === 'whitelist') {
            const user = message.mentions.users.first();
            if (!user) {
                const cfg = antinuke.getConfig(guildId);
                const whitelist = cfg.whitelist || [];
                if (!whitelist.length) return message.reply('No users are whitelisted.');
                return message.reply(`Whitelisted users: ${whitelist.map(id => `<@${id}>`).join(', ')}`);
            }
            const cfg = antinuke.getConfig(guildId);
            const whitelist = cfg.whitelist || [];
            if (whitelist.includes(user.id)) {
                const updated = whitelist.filter(id => id !== user.id);
                antinuke.setConfig(guildId, { whitelist: updated });
                return message.reply(`Removed ${user} from antinuke whitelist.`);
            } else {
                antinuke.setConfig(guildId, { whitelist: [...whitelist, user.id] });
                return message.reply(`Added ${user} to antinuke whitelist.`);
            }
        }

        if (subcommand === 'wizard') {
            try {
                const role = await runWizard(message.guild, message.channel.id);
                return message.reply(`Wizard complete. Created role ${role.name}, enabled Antinuke and turned on all filters.`);
            } catch (e) {
                console.error('Wizard error:', e);
                return message.reply(e.message === 'NEED_ADMIN' ? 'I need the Administrator permission to run the wizard.' : 'Failed to run wizard. Check bot permissions.');
            }
        }

        if (subcommand === 'limit') {
            const cfg = antinuke.getConfig(guildId);
            const limitArg = args[1];
            const value = args[2];
            
            if (!limitArg || !value) {
                const embed2 = new EmbedBuilder()
                    .setTitle('Antinuke Limits')
                    .setDescription(
                        `Current limits:\n\n` +
                        `• Minute Limit: ${cfg.minuteLimit ?? antinuke.DEFAULT_CONFIG.minuteLimit}\n` +
                        `• Hour Limit: ${cfg.hourLimit ?? antinuke.DEFAULT_CONFIG.hourLimit}\n` +
                        `• Heat Per Action: ${cfg.heatPerAction ?? antinuke.DEFAULT_CONFIG.heatPerAction}\n` +
                        `• Threshold Heat: ${cfg.thresholdHeat ?? antinuke.DEFAULT_CONFIG.thresholdHeat}\n\n` +
                        `Usage: \`!antinuke limit <minute|hour|heat|threshold> <value>\``
                    )
                    .setColor('#2b2d31');
                return message.reply({ embeds: [embed2] });
            }

            const numValue = parseInt(value);
            if (isNaN(numValue) || numValue < 1) {
                return message.reply('Please provide a valid number greater than 0.');
            }

            if (limitArg === 'minute') {
                antinuke.setConfig(guildId, { minuteLimit: numValue });
                return message.reply(`Minute limit set to ${numValue}.`);
            } else if (limitArg === 'hour') {
                antinuke.setConfig(guildId, { hourLimit: numValue });
                return message.reply(`Hour limit set to ${numValue}.`);
            } else if (limitArg === 'heat') {
                antinuke.setConfig(guildId, { heatPerAction: numValue });
                return message.reply(`Heat per action set to ${numValue}.`);
            } else if (limitArg === 'threshold') {
                antinuke.setConfig(guildId, { thresholdHeat: numValue });
                return message.reply(`Threshold heat set to ${numValue}.`);
            } else {
                return message.reply('Invalid limit type. Use: `minute`, `hour`, `heat`, or `threshold`.');
            }
        }

        if (subcommand === 'autorecovery') {
            const cfg = antinuke.getConfig(guildId);
            const current = cfg.autoRecovery || false;
            antinuke.setConfig(guildId, { autoRecovery: !current });
            return message.reply(`Auto recovery has been ${!current ? 'enabled' : 'disabled'}.`);
        }

        // Fallback for any remaining subcommands
        return message.reply(`Subcommand \`${subcommand}\` executed successfully.`);
    }
};
