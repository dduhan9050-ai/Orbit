const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const embedHelper = require('../../functions/embedHelper');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('premium')
        .setDescription('Manage premium status (Developer Only)')
        .addSubcommand(sub => sub.setName('add').setDescription('Add premium to a user/server').addStringOption(opt => opt.setName('id').setDescription('The ID').setRequired(true)))
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove premium from a user/server').addStringOption(opt => opt.setName('id').setDescription('The ID').setRequired(true)))
        .addSubcommand(sub => sub.setName('list').setDescription('List all premium users/servers'))
        .addSubcommand(sub => sub.setName('status').setDescription('Check premium status').addStringOption(opt => opt.setName('id').setDescription('The ID')))
        .addSubcommand(sub => sub.setName('transfer').setDescription('Transfer premium status').addStringOption(opt => opt.setName('from').setDescription('From ID').setRequired(true)).addStringOption(opt => opt.setName('to').setDescription('To ID').setRequired(true)))
        .addSubcommand(sub => sub.setName('trial').setDescription('Give a premium trial').addStringOption(opt => opt.setName('id').setDescription('The ID').setRequired(true))),
    async execute(interaction) {
        if (interaction.user.id !== interaction.guild.ownerId) {
            return interaction.reply({ content: '❌ No access', flags: MessageFlags.Ephemeral });
        }

        const sub = interaction.options.getSubcommand();
        await interaction.reply({
            embeds: [new EmbedBuilder().setTitle('Premium Management').setDescription(`Executed subcommand: **${sub}**`).setColor('#000000')],
            flags: MessageFlags.Ephemeral
        });
    },

    async executeMessage(message, args) {
        if (message.author.id !== message.guild.ownerId) {
            return message.reply({ embeds: [embedHelper.error('❌ No access')] });
        }

        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        const embed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **premium add/remove**\n› Manage premium status.\n\n` +
                `» **premium list/status**\n› View premium status.\n\n` +
                `» **premium transfer**\n› Transfer premium.\n\n` +
                `» **premium trial**\n› Give trial.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        if (subcommand === 'help' || !['add', 'remove', 'list', 'status', 'transfer', 'trial'].includes(subcommand)) {
            return message.reply({ embeds: [embed] });
        }

        const fs = require('fs');
        const path = require('path');
        const dataPath = path.join(__dirname, '../../data/premium.json');
        
        let data = { users: [], guilds: [] };
        try {
            if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
        } catch (e) { }

        if (subcommand === 'list') {
            return message.reply({ embeds: [embedHelper.default(`**Premium Users**: ${data.users.length}\n**Premium Guilds**: ${data.guilds.length}`)] });
        }

        if (subcommand === 'status') {
            const id = args[1];
            if (!id) return message.reply({ embeds: [embedHelper.info('Please provide an ID. Example: `!premium status 123456789`')] });
            const isPremium = data.users.includes(id) || data.guilds.includes(id);
            return message.reply({ embeds: [embedHelper.default(`ID \`${id}\` is ${isPremium ? '**Premium**' : '**not Premium**'}`)] });
        }

        if (subcommand === 'add') {
            const id = args[1];
            if (!id) return message.reply({ embeds: [embedHelper.info('Please provide an ID. Example: `!premium add 123456789`')] });
            if (data.users.includes(id) || data.guilds.includes(id)) return message.reply(`ID \`${id}\` already has premium.`);
            // Determine if it's a user or guild ID (basic check)
            if (id.length === 18 || id.length === 19) {
                data.users.push(id);
            } else {
                data.guilds.push(id);
            }
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            return message.reply({ embeds: [embedHelper.success(`Successfully added premium to ID \`${id}\`.`)] });
        }

        if (subcommand === 'remove') {
            const id = args[1];
            if (!id) return message.reply({ embeds: [embedHelper.info('Please provide an ID. Example: `!premium remove 123456789`')] });
            if (!data.users.includes(id) && !data.guilds.includes(id)) return message.reply(`ID \`${id}\` does not have premium.`);
            data.users = data.users.filter(uid => uid !== id);
            data.guilds = data.guilds.filter(gid => gid !== id);
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            return message.reply({ embeds: [embedHelper.success(`Successfully removed premium from ID \`${id}\`.`)] });
        }

        if (subcommand === 'transfer') {
            const fromId = args[1];
            const toId = args[2];
            if (!fromId || !toId) return message.reply({ embeds: [embedHelper.info('Please provide both IDs. Example: `!premium transfer 111111 222222`')] });
            if (!data.users.includes(fromId) && !data.guilds.includes(fromId)) return message.reply(`ID \`${fromId}\` does not have premium.`);
            if (data.users.includes(toId) || data.guilds.includes(toId)) return message.reply(`ID \`${toId}\` already has premium.`);
            data.users = data.users.filter(uid => uid !== fromId);
            data.guilds = data.guilds.filter(gid => gid !== fromId);
            data.users.push(toId);
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            return message.reply({ embeds: [embedHelper.success(`Successfully transferred premium from \`${fromId}\` to \`${toId}\`.`)] });
        }

        if (subcommand === 'trial') {
            const id = args[1];
            if (!id) return message.reply({ embeds: [embedHelper.info('Please provide an ID. Example: `!premium trial 123456789`')] });
            if (data.users.includes(id) || data.guilds.includes(id)) return message.reply(`ID \`${id}\` already has premium.`);
            data.users.push(id);
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            return message.reply({ embeds: [embedHelper.success(`Successfully gave premium trial to ID \`${id}\`.`)] });
        }

        return message.reply({ embeds: [embedHelper.default(`Subcommand \`${subcommand}\` executed successfully.`)] });
    }
};
