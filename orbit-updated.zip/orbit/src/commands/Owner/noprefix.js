const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const embedHelper = require('../../functions/embedHelper');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('noprefix')
        .setDescription('Manage the no-prefix list (Developer Only)')
        .addSubcommand(sub => sub.setName('add').setDescription('Add a user to the no-prefix list').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)))
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove a user from the no-prefix list').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)))
        .addSubcommand(sub => sub.setName('show').setDescription('Show the no-prefix list'))
        .addSubcommand(sub => sub.setName('status').setDescription('Check no-prefix status for a user').addUserOption(opt => opt.setName('user').setDescription('The user')))
        .addSubcommand(sub => sub.setName('claim').setDescription('Claim no-prefix status'))
        .addSubcommand(sub => sub.setName('enable').setDescription('Enable no-prefix for a user').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)))
        .addSubcommand(sub => sub.setName('disable').setDescription('Disable no-prefix for a user').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)))
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset the no-prefix list'))
        .addSubcommand(sub => sub.setName('generate').setDescription('Generate a no-prefix code'))
        .addSubcommand(sub => sub.setName('trial').setDescription('Give a trial no-prefix to a user').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true))),
    async execute(interaction) {
        if (interaction.user.id !== interaction.guild.ownerId) {
            return interaction.reply({ content: '❌ No access', flags: MessageFlags.Ephemeral });
        }

        const sub = interaction.options.getSubcommand();
        await interaction.reply({
            embeds: [new EmbedBuilder().setTitle('No-Prefix Management').setDescription(`Executed subcommand: **${sub}**`).setColor('#000000')],
            flags: MessageFlags.Ephemeral
        });
    },

    async executeMessage(message, args) {
        if (message.author.id !== message.guild.ownerId) {
            return message.reply({ embeds: [embedHelper.error('❌ No access')] });
        }

        const subcommand = args[0] ? args[0].toLowerCase() : 'help';
        const embed = new EmbedBuilder()
            .setDescription(
                `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                `» **noprefix add/remove**\n› Manage no-prefix users.\n\n` +
                `» **noprefix show/status**\n› View no-prefix status.\n\n` +
                `» **noprefix enable/disable**\n› Toggle status.\n\n` +
                `» **noprefix claim**\n› Claim status.\n\n` +
                `» **noprefix reset**\n› Reset list.`
            )
            .setColor('#2b2d31')
            .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

        if (subcommand === 'help' || !['add', 'remove', 'show', 'status', 'claim', 'enable', 'disable', 'reset', 'generate', 'trial'].includes(subcommand)) {
            return message.reply({ embeds: [embed] });
        }

        const fs = require('fs');
        const path = require('path');
        const dataPath = path.join(__dirname, '../../data/noprefix.json');
        
        let data = { users: [] };
        try {
            if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
        } catch (e) { }

        if (subcommand === 'show') {
            if (!data.users.length) return message.reply({ embeds: [embedHelper.info('No users in the no-prefix list.')] });
            return message.reply(`**No-Prefix Users**: ${data.users.map(id => `<@${id}>`).join(', ')}`);
        }

        if (subcommand === 'status') {
            const user = message.mentions.users.first() || message.author;
            const hasNoPrefix = data.users.includes(user.id);
            return message.reply({ embeds: [embedHelper.default(`${user} ${hasNoPrefix ? '**has**' : '**does not have**'} no-prefix status.`)] });
        }

        if (subcommand === 'add') {
            const user = message.mentions.users.first();
            if (!user) return message.reply({ embeds: [embedHelper.info('Please mention a user to add.')] });
            if (data.users.includes(user.id)) return message.reply(`${user} already has no-prefix status.`);
            data.users.push(user.id);
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            return message.reply({ embeds: [embedHelper.success(`Successfully added ${user} to no-prefix list.`)] });
        }

        if (subcommand === 'remove') {
            const user = message.mentions.users.first();
            if (!user) return message.reply({ embeds: [embedHelper.info('Please mention a user to remove.')] });
            if (!data.users.includes(user.id)) return message.reply(`${user} does not have no-prefix status.`);
            data.users = data.users.filter(id => id !== user.id);
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            return message.reply({ embeds: [embedHelper.success(`Successfully removed ${user} from no-prefix list.`)] });
        }

        if (subcommand === 'enable') {
            const user = message.mentions.users.first();
            if (!user) return message.reply({ embeds: [embedHelper.info('Please mention a user to enable.')] });
            if (data.users.includes(user.id)) return message.reply(`${user} already has no-prefix enabled.`);
            data.users.push(user.id);
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            return message.reply({ embeds: [embedHelper.success(`Successfully enabled no-prefix for ${user}.`)] });
        }

        if (subcommand === 'disable') {
            const user = message.mentions.users.first();
            if (!user) return message.reply({ embeds: [embedHelper.info('Please mention a user to disable.')] });
            if (!data.users.includes(user.id)) return message.reply(`${user} does not have no-prefix enabled.`);
            data.users = data.users.filter(id => id !== user.id);
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            return message.reply({ embeds: [embedHelper.success(`Successfully disabled no-prefix for ${user}.`)] });
        }

        if (subcommand === 'reset') {
            data.users = [];
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            return message.reply({ embeds: [embedHelper.success('Successfully reset the no-prefix list.')] });
        }

        if (subcommand === 'claim') {
            if (data.users.includes(message.author.id)) return message.reply({ embeds: [embedHelper.info('You already have no-prefix status.')] });
            data.users.push(message.author.id);
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
            return message.reply({ embeds: [embedHelper.success('Successfully claimed no-prefix status.')] });
        }

        return message.reply({ embeds: [embedHelper.default(`Subcommand \`${subcommand}\` executed successfully.`)] });
    }
};
