const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');

const categories = [
    { label: 'Home', value: 'Home', emoji: '🏠', description: 'Go to the home page' },
    { label: 'Security', value: 'Security', emoji: '🛡️', description: 'Shows the security commands' },
    { label: 'Permit', value: 'Permit', emoji: '🔑', description: 'Shows the permit commands' },
    { label: 'Automod', value: 'Automod', emoji: '🤖', description: 'Shows the automod commands' },
    { label: 'Moderation', value: 'Moderation', emoji: '🔨', description: 'Shows the moderation commands' },
    { label: 'General', value: 'General', emoji: '📋', description: 'Shows the general commands' },
    { label: 'Embed System', value: 'EmbedSystem', emoji: '🧩', description: 'Shows the embed system commands' },
    { label: 'Utility', value: 'Utility', emoji: '🧰', description: 'Shows the utility commands' },
    { label: 'Automations', value: 'Automations', emoji: '⚙️', description: 'Shows the automation commands' },
    { label: 'Autoresponders', value: 'Autoresponders', emoji: '💬', description: 'Shows the autoresponder commands' },
    { label: 'Greetings', value: 'Greetings', emoji: '👋', description: 'Shows the greeting commands' },
    { label: 'Fun', value: 'Fun', emoji: '🎉', description: 'Shows the fun commands' },
    { label: 'Custom Role', value: 'CustomRole', emoji: '🎨', description: 'Shows the custom role commands' },
    { label: 'Voice', value: 'Voice', emoji: '🎤', description: 'Shows the voice commands' },
    { label: 'Music', value: 'Music', emoji: '🎵', description: 'Shows the music commands' },
    { label: 'Tickets', value: 'Tickets', emoji: '🎫', description: 'Shows the ticket commands' },
    { label: 'Logging', value: 'Logging', emoji: '📜', description: 'Shows the logging commands' },
    { label: 'Counters', value: 'Counters', emoji: '🔢', description: 'Shows the counter commands' },
    { label: 'VoiceMaster', value: 'VoiceMaster', emoji: '🔊', description: 'Shows the voice master commands' },
    { label: 'Boycott', value: 'Boycott', emoji: '🚫', description: 'Shows the boycott commands' },
    { label: 'Bot Setting', value: 'BotSetting', emoji: '🔧', description: 'Shows the bot settings' },
    { label: 'Owner', value: 'Owner', emoji: '👑', description: 'Shows the owner commands' }
];

// Map to store active timeouts for help menus: MessageID -> Timeout
const activeTimeouts = new Map();

function getPrefix(guildId) {
    try {
        const file = require('path').join(__dirname, '../../data/prefix.json');
        const data = JSON.parse(require('fs').readFileSync(file, 'utf8'));
        const list = data[guildId] && data[guildId].prefixes;
        if (list && list.length) return list[0];
    } catch (e) { /* fall back to default */ }
    return process.env.PREFIX || '!';
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('Get a list of all bot commands and their details'),

    async execute(interaction) {
        // Send initial help menu and fetch response to track ID
        const payload = this.getHelpPayload(interaction.client, false, interaction.user?.username || interaction.user?.tag || interaction.user?.id || 'Unknown', interaction.guildId);
        await interaction.reply(payload);
        const response = await interaction.fetchReply();
        // Store requester ID in message for access control (using a WeakMap for runtime association)
        if (!global.orbitHelpRequesters) global.orbitHelpRequesters = new Map();
        global.orbitHelpRequesters.set(response.id, interaction.user.id);
        this.startTimeout(response);
    },

    async executeMessage(message) {
        const payload = this.getHelpPayload(message.client, false, message.author?.username || message.author?.tag || message.author?.id || 'Unknown', message.guildId);
        const response = await message.reply('Loading help menu...');
        const msg = await response.edit({ content: null, ...payload });
        if (!global.orbitHelpRequesters) global.orbitHelpRequesters = new Map();
        global.orbitHelpRequesters.set(msg.id, message.author.id);
        this.startTimeout(msg);
    },

    startTimeout(message) {
        // Clear existing timeout if present
        if (activeTimeouts.has(message.id)) {
            clearTimeout(activeTimeouts.get(message.id));
        }

        // Set new 15s timeout
        const timeout = setTimeout(async () => {
            try {
                // Fetch latest message state
                const msg = await message.channel.messages.fetch(message.id).catch(() => null);
                if (msg) {
                    // Determine requester username if available
                    let requestedByUsername = message.client.user.username;
                    if (global.orbitHelpRequesters && global.orbitHelpRequesters.has(message.id)) {
                        const originalRequesterId = global.orbitHelpRequesters.get(message.id);
                        if (message.client.users && message.client.users.cache) {
                            const userObj = message.client.users.cache.get(originalRequesterId);
                            if (userObj) requestedByUsername = userObj.username;
                        }
                    }

                    // Update message with disabled components and the requester's name
                    const payload = this.getHelpPayload(message.client, true, requestedByUsername, message.guildId);
                    await msg.edit(payload);
                }
                activeTimeouts.delete(message.id);
                if (global.orbitHelpRequesters) global.orbitHelpRequesters.delete(message.id);
            } catch (error) {
                // Ignore if message was deleted
                activeTimeouts.delete(message.id);
            }
        }, 40000); // 40 seconds

        activeTimeouts.set(message.id, timeout);
    },

    async handleComponent(interaction) {
        // Only allow the original requester to interact with the help menu
        let allowed = true;
        if (global.orbitHelpRequesters && global.orbitHelpRequesters.has(interaction.message.id)) {
            const originalRequesterId = global.orbitHelpRequesters.get(interaction.message.id);
            if (interaction.user.id !== originalRequesterId) {
                allowed = false;
            }
        }
        if (!allowed) {
            await interaction.reply({ content: 'Only the original requester can interact with this help menu.', flags: MessageFlags.Ephemeral });
            return;
        }
        // Refresh timeout on every valid interaction (reset to 0)
        this.startTimeout(interaction.message);

        if (interaction.isStringSelectMenu()) {
            if (interaction.customId === 'help_category_select_1' || interaction.customId === 'help_category_select_2') {
                const selectedCategory = interaction.values[0];
                // Get the original requester's username for the footer
                let requestedByUsername = interaction.user.username;
                if (global.orbitHelpRequesters && global.orbitHelpRequesters.has(interaction.message.id)) {
                    const originalRequesterId = global.orbitHelpRequesters.get(interaction.message.id);
                    if (interaction.client.users && interaction.client.users.cache) {
                        const userObj = interaction.client.users.cache.get(originalRequesterId);
                        if (userObj) requestedByUsername = userObj.username;
                    }
                }
                if (selectedCategory === 'Home') {
                    const payload = this.getHelpPayload(interaction.client, false, requestedByUsername, interaction.guildId);
                    await interaction.update(payload);
                } else {
                    const embed = this.getCategoryEmbed(interaction.client, selectedCategory, requestedByUsername);
                    await interaction.update({ embeds: [embed] });
                }
            }
        }

        if (interaction.isButton()) {
            const action = interaction.customId.split('_')[1];
            // Get the original requester's username for the footer
            let requestedByUsername = interaction.user.username;
            if (global.orbitHelpRequesters && global.orbitHelpRequesters.has(interaction.message.id)) {
                const originalRequesterId = global.orbitHelpRequesters.get(interaction.message.id);
                if (interaction.client.users && interaction.client.users.cache) {
                    const userObj = interaction.client.users.cache.get(originalRequesterId);
                    if (userObj) requestedByUsername = userObj.username;
                }
            }
            if (action === 'delete') {
                if (activeTimeouts.has(interaction.message.id)) {
                    clearTimeout(activeTimeouts.get(interaction.message.id));
                    activeTimeouts.delete(interaction.message.id);
                }
                await interaction.message.delete();
                return;
            }

            if (action === 'home') {
                const payload = this.getHelpPayload(interaction.client, false, requestedByUsername, interaction.guildId);
                await interaction.update(payload);
                return;
            }

            if (action === 'next' || action === 'back') {
                const currentEmbed = interaction.message.embeds[0];
                const currentCategoryLabel = currentEmbed.author ? currentEmbed.author.name : 'Home';

                let currentIndex = categories.findIndex(c => c.value === currentCategoryLabel);
                if (currentIndex === -1) currentIndex = 0;

                let newIndex;
                if (action === 'next') {
                    newIndex = currentIndex + 1;
                    if (newIndex >= categories.length) newIndex = 0;
                } else {
                    newIndex = currentIndex - 1;
                    if (newIndex < 0) newIndex = categories.length - 1;
                }

                const newCategoryValue = categories[newIndex].value;

                if (newCategoryValue === 'Home') {
                    const payload = this.getHelpPayload(interaction.client, false, requestedByUsername, interaction.guildId);
                    await interaction.update(payload);
                } else {
                    const embed = this.getCategoryEmbed(interaction.client, newCategoryValue, requestedByUsername);
                    await interaction.update({ embeds: [embed] });
                }
            }
        }
    },

    getHelpPayload(client, disabled = false, requestedByUsername = null, guildId = null) {
        const prefix = getPrefix(guildId);
        requestedByUsername = requestedByUsername || client.user.username;
        let titleText = `Hey, I'm ${client.user.username} ™`;

        const embed = new EmbedBuilder()
            .setTitle(titleText)
            .setDescription(`A multipurpose useful bot to setup your dream community\n\n` +
                `• **My prefix for this server is** ${prefix}\n` +
                `• **Type** \`${prefix}help\` **to get details**\n` +
                `• **Total commands:** 800+ \n\n` +
                `**__Bot Stats__**\n` +
                `• **Server Count :** ${client.guilds.cache.size}\n` +
                `• **Latency :** ${Math.round(client.ws.ping)}ms\n\n` +
                `[Invite me](https://discord.com) | [Support](https://discord.com) | [Vote](https://discord.com)`)
            .setThumbnail(client.user.displayAvatarURL())
            .setColor('#000000')
            .setImage('https://cdn.discordapp.com/banners/1377862789523308575/5c5d813dc889dc977ddb759c44139d73.png?size=1024')
            .setFooter({ text: `Powered By ${client.user.username} Devs`, iconURL: client.user.displayAvatarURL() });

        const row1 = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('help_category_select_1')
                .setPlaceholder('> Select Category (1 to 12)')
                .addOptions(this.getCategoryOptions(1, 12))
                .setDisabled(disabled)
        );

        const row2 = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('help_category_select_2')
                .setPlaceholder('> Select Category (13 to 22)')
                .addOptions(this.getCategoryOptions(13, 22))
                .setDisabled(disabled)
        );

        const rowButtons = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('help_home').setEmoji('🏠').setStyle(ButtonStyle.Secondary).setDisabled(disabled),
            new ButtonBuilder().setCustomId('help_back').setEmoji('◀️').setStyle(ButtonStyle.Secondary).setDisabled(disabled),
            new ButtonBuilder().setCustomId('help_next').setEmoji('▶️').setStyle(ButtonStyle.Secondary).setDisabled(disabled),
            new ButtonBuilder().setCustomId('help_delete').setEmoji('🗑️').setStyle(ButtonStyle.Secondary).setDisabled(disabled),
            new ButtonBuilder().setLabel('Orbit™').setStyle(ButtonStyle.Secondary).setCustomId('help_orbit_name').setDisabled(true)
        );

        return { embeds: [embed], components: [row1, row2, rowButtons] };
    },

    async sendHelpMenu(interaction) {
        // We reuse logic in execute for slash command interaction
        await this.execute(interaction);
    },

    getCategoryOptions(start, end) {
        const sliced = categories.slice(start - 1, end);
        return sliced.map(cat => ({
            label: cat.label,
            value: cat.value,
            emoji: cat.emoji,
            description: cat.description
        }));
    },

    getCategoryEmbed(client, cates) {
        let title = `${client.user.username} ${cates} Commands`;
        let description = `**__${cates}__**\nNo commands added yet.`;

        switch (cates) {
            case 'Security':
                title = `${client.user.username} Security Commands`;
                description = `**__Antinuke__**\n` +
                    `\`antinuke\`, \`antinuke logdisable\`, \`antinuke wizard\`,\n` +
                    `\`antinuke zplus\`, \`antinuke autorecovery\`, \`antinuke disable\`\n` +
                    `\`antinuke whitelist\`, \`antinuke reset\`, \`antinuke logging\`,\n` +
                    `\`antinuke limit\`, \`antinuke enable\`, \`antinuke manage\`\n\n` +

                    `**__Mainrole__**\n` +
                    `\`mainrole\`, \`mainrole show\`, \`mainrole reset\`, \`mainrole add\`,\n` +
                    `\`mainrole remove\`\n\n` +

                    `**__Panicmode__**\n` +
                    `\`panicmode\`, \`panicmode reset\`, \`panicmode set\`, \`panicmode\`\n` +
                    `\`disable\`, \`panicmode enable\``;
                break;

            case 'Permit':
                title = `${client.user.username} Permit Commands`;
                description = `**__Extraowner__**\n\`extraowner\`, \`extraowner add\`, \`extraowner reset\`, \`extraowner show\`, \`extraowner remove\``;
                description += `\n\n**__Trusted__**\n\`trusted\`, \`trusted show\`, \`trusted add\`, \`trusted remove\`, \`trusted reset\``;
                description += `\n\n**__Topcheck__**\n\`topcheck\`, \`topcheck enable\`, \`topcheck disable\``;
                description += `\n\n**__Ignore__**\n\`ignore\`, \`ignore channel\`, \`ignore channel reset\`, \`ignore channel add\`, \`ignore channel remove\`, \`ignore channel show\`, \`ignore bypass\`, \`ignore bypass show\`, \`ignore bypass add\`, \`ignore bypass reset\`, \`ignore bypass remove\`, \`ignore command\`, \`ignore command add\`, \`ignore command remove\`, \`ignore command show\`, \`ignore command reset\`, \`ignore user\`, \`ignore user show\`, \`ignore user remove\`, \`ignore user add\`, \`ignore user reset\`, \`ignore role\`, \`ignore role add\`, \`ignore role remove\`, \`ignore role reset\`, \`ignore role show\``;
                break;

            case 'Automod':
                title = `${client.user.username} Automod Commands`;
                description = `**__Automod__**\n\`automod\`, \`automod heat\`, \`automod heat set\`, \`automod heat filters\`, \`automod wizard\`, \`automod config\`, \`automod unignore\`, \`automod unignore user\`, \`automod unignore channel\`, \`automod unignore role\`, \`automod disable\`, \`automod reset\`, \`automod punishment\`, \`automod logging\`, \`automod ignore\`, \`automod ignore reset\`, \`automod ignore channel\`, \`automod ignore role\`, \`automod ignore show\`, \`automod ignore user\`, \`automod manage\`, \`automod automute\`, \`automod automute set\`, \`automod automute disable\`, \`automod enable\``;
                description += `\n\n**__Word Blacklist__**\n\`blword\`, \`blword punish\`, \`blword punish ban\`, \`blword punish mute\`, \`blword punish show\`, \`blword punish kick\`, \`blword punish reset\`, \`blword wlchannel\`, \`blword wlchannel show\`, \`blword wlchannel reset\`, \`blword wlchannel add\`, \`blword wlchannel remove\`, \`blword reset\`, \`blword add\`, \`blword remove\`, \`blword wlrole\`, \`blword wlrole remove\`, \`blword wlrole reset\`, \`blword wlrole show\`, \`blword wlrole add\`, \`blword show add\``;
                break;

            case 'Moderation':
                title = `${client.user.username} Moderation Commands`;
                description = `**__Basic Commands__**\n\`ban\`, \`unban\`, \`unbanall\`, \`kick\`, \`mute\`, \`unmute\`, \`nick\`, \`nuke\`, \`clone\`, \`lock\`, \`unlock\`, \`lockall\`, \`unlockall\`, \`hide\`, \`unhide\`, \`hideall\`, \`unhideall\`, \`slowmode\`, \`unslowmode\`, \`enlarge\`, \`deleteemoji\`, \`deletesticker\`, \`channel\`, \`channel deleteafter\`, \`channel transfer\`, \`channel delete\`, \`channel create\`, \`channel rename\`, \`snipe\`, \`steal\`\n\n` +
                    `**__Role Commands__**\n\`role\`, \`role bots\`, \`role temp\`, \`role all\`, \`role rename\`, \`role add\`, \`role remove\`, \`role icon\`, \`role delete\`, \`role humans\`, \`role colour\`, \`role unverified\`, \`role create\`, \`rrole\`, \`rrole humans\`, \`rrole bots\`, \`rrole unverified\`, \`rrole all\`\n\n` +
                    `**__Purge Commands__**\n\`clear\`, \`clear image\`, \`clear emoji\`, \`clear embed\`, \`clear files\`, \`clear user\`, \`clear contain\`, \`clear all\`, \`clear bots\`, \`clear mentions\`, \`clear reactions\`, \`purgeuser\`, \`purgebots\``;
                break;

            case 'General':
                title = `${client.user.username} General Commands`;
                description = `**__Basic Commands__**\n\`membercount\`, \`boostcount\`, \`status\`, \`joinedat\`, \`serverinfo\`, \`afk\`, \`choose\`, \`fmsg\`, \`avatar\`, \`banner\`, \`userinfo\`, \`servericon\`, \`serverbanner\`, \`profile\`, \`timer\`, \`vote\`\n\n` +
                    `**__Bot Stats__**\n\`stats\`, \`uptime\`, \`ping\`, \`users\`\n\n` +
                    `**__List Commands__**\n\`list\`, \`list createdat\`, \`list early\`, \`list servers\`, \`list allusers\`, \`list mods\`, \`list bans\`, \`list roles\`, \`list users\`, \`list boosters\`, \`list inrole\`, \`list activedeveloper\`, \`list emojis\`, \`list invoice\`, \`list bots\`, \`list joinedat\`, \`list admins\``;
                break;

            case 'EmbedSystem':
                title = `${client.user.username} Embed System Commands`;
                description = `**__Embed Commands__**\n\`embed\`, \`embed rename\`, \`embed send\`, \`embed delete\`, \`embed show\`, \`embed export\`, \`embed edit\`, \`embed save\`, \`embed import\`, \`embed create\`, \`embed guide\`\n\n` +
                    `**__Variable Command__**\n\`variables [module] [category]\``;
                break;

            case 'Utility':
                title = `${client.user.username} Utility Commands`;
                description = `**__Media Commands__**\n\`media\`, \`media show\`, \`media remove\`, \`media add\`, \`media reset\`, \`media bypass\`, \`media bypass show\`, \`media bypass remove\`, \`media bypass add\`, \`media bypass reset\``;
                description += `\n\n**__Sticky Message__**\n\`sticky\`, \`sticky add\`, \`sticky reset\`, \`sticky bump\`, \`sticky remove\`, \`sticky show\`, \`sticky channel\`, \`sticky channel remove\`, \`sticky channel add\``;
                description += `\n\n**__Giveaways__**\n\`gcreate\`, \`gend\`, \`greroll\`, \`glist\`, \`gdelete\``;
                break;

            case 'Automations':
                title = `${client.user.username} Automations Commands`;
                description = `**__Auto Delete__**\n\`autodelete\`, \`autodelete whitelist\`, \`autodelete whitelist add\`, \`autodelete whitelist remove\`, \`autodelete whitelist reset\`, \`autodelete whitelist show\`, \`autodelete add\`, \`autodelete reset\`, \`autodelete remove\`, \`autodelete show\`\n\n` +
                    `**__Auto Roles__**\n\`autorole\`, \`autorole enable\`, \`autorole disable\`, \`autorole humans\`, \`autorole humans reset\`, \`autorole humans disable\`, \`autorole humans show\`, \`autorole humans remove\`, \`autorole humans add\`, \`autorole humans enable\`, \`autorole bots\`, \`autorole bots disable\`, \`autorole bots enable\`, \`autorole bots add\`, \`autorole bots reset\`, \`autorole bots show\`, \`autorole bots remove\`, \`autorole show\``;
                break;

            case 'Autoresponders':
                title = `${client.user.username} Autoresponders Commands`;
                description = `**__Auto Responders__**\n\`autoresponder\`, \`autoresponder toggle\`, \`autoresponder show\`, \`autoresponder remove\`, \`autoresponder ignore\`, \`autoresponder ignore add\`, \`autoresponder ignore reset\`, \`autoresponder ignore show\`, \`autoresponder ignore remove\`, \`autoresponder edit\`, \`autoresponder disable\`, \`autoresponder enable\`, \`autoresponder add\``;
                description += `\n\n**__Auto Reactors__**\n\`autoreact\`, \`autoreact edit\`, \`autoreact disable\`, \`autoreact add\`, \`autoreact enable\`, \`autoreact show\`, \`autoreact toggle\`, \`autoreact ignore\`, \`autoreact ignore add\`, \`autoreact ignore reset\`, \`autoreact ignore show\`, \`autoreact ignore remove\`, \`autoreact remove\``;
                break;

            case 'Greetings':
                title = `${client.user.username} Greetings Commands`;
                description = `**__Welcomer__**\n\`greet\`, \`greet test\`, \`greet channel\`, \`greet channel set\`, \`greet channel reset\`, \`greet delete\`, \`greet disable\`, \`greet config\`, \`greet enable\`, \`greet create\`, \`greet style\`, \`greet autodelete\`, \`greet card\`\n\n` +
                    `**__Join DM__**\n\`joindm\`, \`joindm show\`, \`joindm set\`, \`joindm test\`, \`joindm enable\`, \`joindm reset\`, \`joindm disable\`\n\n` +
                    `**__Leave Msg__**\n\`leavemsg\`, \`leavemsg reset\`, \`leavemsg enable\`, \`leavemsg test\`, \`leavemsg disable\`, \`leavemsg set\`, \`leavemsg show\`\n\n` +
                    `**__Boost Greet__**\n\`boostgreet\`, \`boostgreet test\`, \`boostgreet set\`, \`boostgreet enable\`, \`boostgreet disable\`, \`boostgreet show\`, \`boostgreet reset\``;
                break;

            case 'Fun':
                title = `${client.user.username} Fun Commands`;
                description = `**__Fun Commands__**\n\`fhelp\`, \`mydog\`, \`ship\`, \`cat\`, \`joke\`, \`fact\`, \`truth\`, \`dare\`, \`eightball\`, \`reverse\`, \`mock\`, \`doublestruck\`, \`emojipasta\`, \`morse\`, \`biden\`, \`pikachu\`, \`oogway\`, \`drake\`, \`pooh\`, \`sadcat\`, \`factsmeme\`, \`unforgivable\`, \`caution\`, \`opinion\`, \`gun\`, \`drip\`, \`blur\`, \`invert\`, \`greyscale\`, \`advertise\`, \`mnm\`, \`spank\`, \`cute\`, \`bomb\`, \`intelligence\`, \`horny\`, \`waifu\`, \`cuddle\`, \`hug\`, \`kiss\`, \`nom\`, \`pat\`, \`poke\`, \`slap\`, \`stare\`, \`highfive\`, \`bite\`, \`punch\`, \`handholding\`, \`tickle\`, \`hold\`, \`wave\`, \`snuggle\`, \`blush\`, \`cry\`, \`dance\`, \`pout\`, \`shrug\`, \`sleepy\`, \`smile\`, \`smug\`, \`thumbsup\`, \`thinking\`, \`triggered\`, \`teehee\`, \`deredere\`, \`scoff\`, \`happy\`, \`thumbs\`, \`pray\`, \`curse\`, \`marry\`, \`pickup\`, \`showerthought\`, \`clown\`, \`jail\`, \`wanted\`, \`pet\`, \`alert\`, \`hack\`, \`token\`, \`supreme\`, \`whowouldwin\`, \`nokia\`, \`uncover\`, \`jokeoverhead\`, \`huerotate\`, \`quote\`, \`couldread\`, \`caption\`, \`colorify\``;
                break;

            case 'CustomRole':
                title = `${client.user.username} Custom Role Commands`;
                description = `**__Custom Role__**\n\`setup\`, \`setup reqrole\`, \`setup reqrole show\`, \`setup reqrole remove\`, \`setup reqrole set\`, \`setup staff\`, \`setup vip\`, \`setup reset\`, \`setup guest\`, \`setup create\`, \`setup delete\`, \`setup list\`, \`setup friend\`, \`setup girl\`, \`staff\`, \`girl\`, \`friend\`, \`vip\`, \`guest\``;
                break;

            case 'Voice':
                title = `${client.user.username} Voice Commands`;
                description = `**__Voice Commands__**\n\`vcrole\`, \`vcrole clear\`, \`vcrole show\`, \`vcrole set\`, \`voice\`, \`voice moveall\`, \`voice banlist\`, \`voice move\`, \`voice pull\`, \`voice unprivate\`, \`voice unmute\`, \`voice pullall\`, \`voice ban\`, \`voice kickall\`, \`voice kick\`, \`voice mute\`, \`voice unban\`, \`voice lock\`, \`voice unmuteall\`, \`voice deafenall\`, \`voice undeafen\`, \`voice muteall\`, \`voice undeafenall\`, \`voice unlock\`, \`voice deafen\`, \`voice private\``;
                break;

            case 'Music':
                title = `${client.user.username} Music Commands`;
                description = `**__Music Commands__**\n\`play\`, \`tts\`, \`nowplaying\`, \`queue\`, \`history\`, \`search\`, \`grab\`, \`stop\`, \`autoplay\`, \`join\`, \`leave\`, \`forcefix\`, \`pause\`, \`resume\`, \`seek\`, \`volume\`, \`replay\`, \`shuffle\`, \`clearqueue\`, \`remove\`, \`move\`, \`loop\`, \`loopqueue\`, \`skip\`, \`skipinto\`, \`filter\`, \`filter toggle\`, \`filter reset\`, \`filter show\`, \`djrole\`, \`djrole show\`, \`djrole clear\`, \`djrole set\`, \`source\`, \`source show\`, \`source set\`, \`247\`, \`247 enable\`, \`247 channel\`, \`247 disable\`, \`djmix\`, \`djmix show\`, \`djmix enable\`, \`djmix disable\`\n\n` +
                    `**__Playlist Commands__**\n\`like\`, \`playlist\`, \`playlist play\`, \`playlist delete\`, \`playlist rename\`, \`playlist view\`, \`playlist addcurrent\`, \`playlist create\`, \`playlist list\`, \`playlist import\`, \`playlist remove\`, \`playlist add\`, \`playlist export\``;
                break;

            case 'Tickets':
                title = `${client.user.username} Ticket System Commands`;
                description = `**__Ticket System__**\n\`ticket\`, \`ticket category\`, \`ticket delete\`, \`ticket remove\`, \`ticket logging\`, \`ticket transcript\`, \`ticket panel\`, \`ticket rename\`, \`ticket greetmsg\`, \`ticket autotranscript\`, \`ticket support\`, \`ticket support remove\`, \`ticket support reset\`, \`ticket support add\`, \`ticket support show\`, \`ticket list\`, \`ticket add\`, \`ticket maxtickets\`, \`ticket close\`, \`ticket reopen\`, \`ticket type\`, \`ticket type create\`, \`ticket type delete\`, \`ticket type edit\``;
                break;

            case 'Logging':
                title = `${client.user.username} Logging Commands`;
                description = `**__Logging__**\n\`logging\`, \`logging setup\`, \`logging setup clear\`, \`logging setup channel\`, \`logging setup auto\`, \`logging remove\`, \`logging status\`, \`logging wizard\`, \`logging ignore\`, \`logging ignore channel\`, \`logging ignore show\`, \`logging ignore user\`, \`logging ignore embed\`, \`logging ignore role\`, \`logging ignore voice\`, \`logging ignore remove\`, \`logging disable\`, \`logging enable\``;
                break;

            case 'Counters':
                title = `${client.user.username} Counters Commands`;
                description = `**__Message Count__**\n\`messages\`, \`message\`, \`message rolereward\`, \`message config\`, \`message lbweekly\`, \`message blchannel\`, \`message lbdaily\`, \`message add\`, \`message resetme\`, \`message rolereset\`, \`message remove\`, \`message reset\`, \`message unblchannel\`, \`message leaderboard\`\n\n` +
                    `**__VoiceTime Count__**\n\`vctime\`, \`voicetime\`, \`voicetime add\`, \`voicetime reset\`, \`voicetime unblchannel\`, \`voicetime leaderboard\`, \`voicetime rolereward\`, \`voicetime config\`, \`voicetime blchannel\`, \`voicetime resetme\`, \`voicetime rolereset\`, \`voicetime remove\`, \`voicetime lbdaily\`, \`voicetime lbweekly\`\n\n` +
                    `**__Invite Count__**\n\`invites\`, \`inviter\`, \`invited\`, \`invite\`, \`invite rolereward\`, \`invite testlogs\`, \`invite config\`, \`invite leavelogs\`, \`invite leavelogs set\`, \`invite leavelogs disable\`, \`invite leaderboard\`, \`invite fakethreshold\`, \`invite joinlogs\`, \`invite joinlogs disable\`, \`invite joinlogs set\`, \`invite reset\`, \`invite bonus\`, \`invite rolereset\`, \`invite resetme\`, \`invite remove\``;
                break;

            case 'VoiceMaster':
                title = `${client.user.username} Voice Master Commands`;
                description = `**__Temp Voice__**\n\`tempvc\`, \`tempvc name\`, \`tempvc ban\`, \`tempvc lock\`, \`tempvc unban\`, \`tempvc trust\`, \`tempvc transfer\`, \`tempvc config\`, \`tempvc limit\`, \`tempvc lobby\`, \`tempvc lobby remove\`, \`tempvc lobby add\`, \`tempvc lobby edit\`, \`tempvc claim\`, \`tempvc hide\`, \`tempvc kick\`, \`tempvc untrust\`, \`tempvc unlock\`, \`tempvc unhide\``;
                break;

            case 'Boycott':
                title = `${client.user.username} Boycott System Commands`;
                description = `**__Boycott System__**\n\`boycott\`, \`boycott list\`, \`boycott logging\`, \`boycott config\`, \`boycott ban\`, \`boycott unban\`, \`boycott reset\`, \`boycott setup\`\n\n` +
                    `**__Chat Ban__**\n\`chat\`, \`chat unban\`, \`chat ban\`, \`chat banlist\``;
                break;

            case 'BotSetting':
                title = `${client.user.username} Bot Settings Commands`;
                description = `**__Profile__**\n\`profile\`, \`bio\`, \`bio set\`, \`bio clear\`, \`badge\`, \`badge add\`, \`badge remove\`, \`badge list\`, \`branding\`\n\n` +
                    `**__Prefix__**\n\`prefix\`, \`prefix show\`, \`prefix remove\`, \`prefix reset\`, \`prefix add\``;
                break;

            case 'Owner':
                title = `${client.user.username} Owner Commands`;
                description = `**__NoPrefix__**\n\`noprefix\`, \`noprefix status\`, \`noprefix claim\`, \`noprefix enable\`, \`noprefix add\`, \`noprefix reset\`, \`noprefix disable\`, \`noprefix remove\`, \`noprefix generate\`, \`noprefix trial\`, \`noprefix show\`\n\n` +
                    `**__Premium__**\n\`premium\`, \`premium trial\`, \`premium status\`, \`premium list\`, \`premium remove\`, \`premium transfer\`, \`premium add\``;
                break;

            default:
                title = `${client.user.username} ${cates} Commands`;
                description = `**__${cates}__**\nNo commands configured yet.`;
                break;
        }

        // Accept requester's username as third argument
        let requestedBy = client.user.username;
        if (typeof arguments[2] === 'string') {
            requestedBy = arguments[2];
        }
        return new EmbedBuilder()
            .setTitle(title)
            .setAuthor({ name: cates, iconURL: client.user.displayAvatarURL() })
            .setDescription(description)
            .setColor('#000000') // Black color
            .setImage('https://cdn.discordapp.com/banners/1377862789523308575/5c5d813dc889dc977ddb759c44139d73.png?size=1024') // Placeholder banner
            .setFooter({ text: `Powered By Oʀʙɪᴛ Devs | Requested By ${requestedBy}`, iconURL: client.user.displayAvatarURL() });
    }
};
