const { SlashCommandBuilder } = require('discord.js');
const greetModule = require('../../functions/greetModule');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('greet')
        .setDescription('Configure welcomer greetings')
        .addSubcommand(sub => sub.setName('test').setDescription('Test the welcomer message'))
        .addSubcommandGroup(group => group.setName('channel').setDescription('Manage welcomer channel')
            .addSubcommand(sub => sub.setName('set').setDescription('Set welcomer channel').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
            .addSubcommand(sub => sub.setName('reset').setDescription('Reset welcomer channel')))
        .addSubcommand(sub => sub.setName('delete').setDescription('Delete welcomer configuration'))
        .addSubcommand(sub => sub.setName('disable').setDescription('Disable welcomer module'))
        .addSubcommand(sub => sub.setName('config').setDescription('Show welcomer configuration'))
        .addSubcommand(sub => sub.setName('enable').setDescription('Enable welcomer module'))
        .addSubcommand(sub => sub.setName('create').setDescription('Create a new welcomer message (vars: {user} {username} {server} {membercount})')
            .addStringOption(opt => opt.setName('message').setDescription('The welcome message').setRequired(true)))
        .addSubcommand(sub => sub.setName('style').setDescription('Change welcomer message style')
            .addStringOption(opt => opt.setName('style').setDescription('Style').setRequired(true)
                .addChoices({ name: 'text', value: 'text' }, { name: 'embed', value: 'embed' })))
        .addSubcommand(sub => sub.setName('autodelete').setDescription('Set autodelete for greeting messages')
            .addStringOption(opt => opt.setName('time').setDescription('Time (e.g. 10s, 1m) or off').setRequired(true)))
        .addSubcommand(sub => sub.setName('card').setDescription('Show a big avatar card (embed style)')
            .addBooleanOption(opt => opt.setName('enabled').setDescription('On or off (leave empty to toggle)').setRequired(false))),
    ...greetModule.create('greet'),
};
