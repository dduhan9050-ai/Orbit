const { SlashCommandBuilder } = require('discord.js');
const greetModule = require('../../functions/greetModule');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('joindm')
        .setDescription('Configure DM message sent to new members')
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset Join DM configuration'))
        .addSubcommand(sub => sub.setName('enable').setDescription('Enable Join DM module'))
        .addSubcommand(sub => sub.setName('test').setDescription('Test Join DM'))
        .addSubcommand(sub => sub.setName('disable').setDescription('Disable Join DM module'))
        .addSubcommand(sub => sub.setName('set').setDescription('Set Join DM message ({user} {server})')
            .addStringOption(opt => opt.setName('message').setDescription('The message content').setRequired(true)))
        .addSubcommand(sub => sub.setName('show').setDescription('Show current Join DM config')),
    ...greetModule.create('joindm'),
};
