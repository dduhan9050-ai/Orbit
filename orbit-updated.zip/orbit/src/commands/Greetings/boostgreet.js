const { SlashCommandBuilder } = require('discord.js');
const greetModule = require('../../functions/greetModule');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('boostgreet')
        .setDescription('Configure boost greetings')
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset boost greeting configuration'))
        .addSubcommand(sub => sub.setName('enable').setDescription('Enable boost greeting module'))
        .addSubcommand(sub => sub.setName('test').setDescription('Test boost greeting'))
        .addSubcommand(sub => sub.setName('disable').setDescription('Disable boost greeting module'))
        .addSubcommand(sub => sub.setName('set').setDescription('Set boost greeting message ({user} {server} {boostcount})')
            .addStringOption(opt => opt.setName('message').setDescription('The message content').setRequired(true)))
        .addSubcommand(sub => sub.setName('show').setDescription('Show current boost greeting config'))
        .addSubcommandGroup(group => group.setName('channel').setDescription('Manage boost greeting channel')
            .addSubcommand(sub => sub.setName('set').setDescription('Set the channel').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
            .addSubcommand(sub => sub.setName('reset').setDescription('Reset the channel'))),
    ...greetModule.create('boostgreet'),
};
