const { SlashCommandBuilder } = require('discord.js');
const greetModule = require('../../functions/greetModule');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('leavemsg')
        .setDescription('Configure leave messages')
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset leave message configuration'))
        .addSubcommand(sub => sub.setName('enable').setDescription('Enable leave message module'))
        .addSubcommand(sub => sub.setName('test').setDescription('Test leave message'))
        .addSubcommand(sub => sub.setName('disable').setDescription('Disable leave message module'))
        .addSubcommand(sub => sub.setName('set').setDescription('Set leave message message ({username} {server} {membercount})')
            .addStringOption(opt => opt.setName('message').setDescription('The message content').setRequired(true)))
        .addSubcommand(sub => sub.setName('show').setDescription('Show current leave message config'))
        .addSubcommandGroup(group => group.setName('channel').setDescription('Manage leave message channel')
            .addSubcommand(sub => sub.setName('set').setDescription('Set the channel').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
            .addSubcommand(sub => sub.setName('reset').setDescription('Reset the channel'))),
    ...greetModule.create('leavemsg'),
};
