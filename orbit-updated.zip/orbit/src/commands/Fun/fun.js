// Fun module. GIFs come from Giphy (needs GIPHY_API_KEY in .env) and are shown inside embeds.
// Works as  /fun <group> <sub>,  !fun <sub>  and as direct prefix commands such as  !hug @user.
const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const giphy = require('../../functions/giphy');
const common = require('../../functions/automationCommon');

const interactionCommands = [
    'cuddle', 'hug', 'kiss', 'nom', 'pat', 'poke', 'slap', 'stare', 'highfive', 'bite',
    'punch', 'handholding', 'tickle', 'hold', 'wave', 'snuggle', 'spank', 'marry', 'pet'
];
const reactionCommands = [
    'blush', 'cry', 'dance', 'pout', 'shrug', 'sleepy', 'smile', 'smug', 'thumbsup',
    'thinking', 'triggered', 'teehee', 'deredere', 'scoff', 'happy', 'thumbs', 'pray', 'curse'
];
const simpleTextCommands = [
    'mydog', 'cat', 'joke', 'fact', 'truth', 'dare', 'eightball', 'opinion', 'mnm',
    'cute', 'intelligence', 'horny', 'waifu', 'showerthought', 'clown', 'token'
];
const textInputCommands = ['reverse', 'mock', 'doublestruck', 'emojipasta', 'morse', 'advertise', 'hack', 'caption'];
const imageGenCommands1 = [
    'biden', 'pikachu', 'oogway', 'drake', 'pooh', 'sadcat', 'factsmeme', 'unforgivable',
    'caution', 'gun', 'drip', 'blur', 'invert', 'greyscale', 'bomb', 'jail'
];
const imageGenCommands2 = [
    'wanted', 'alert', 'supreme', 'whowouldwin', 'nokia', 'uncover', 'jokeoverhead', 'huerotate',
    'quote', 'couldread', 'colorify'
];

const GROUP_OF = {};
interactionCommands.forEach(n => (GROUP_OF[n] = 'action'));
reactionCommands.forEach(n => (GROUP_OF[n] = 'react'));
[...simpleTextCommands, ...textInputCommands].forEach(n => (GROUP_OF[n] = 'text'));
imageGenCommands1.forEach(n => (GROUP_OF[n] = 'meme'));
imageGenCommands2.forEach(n => (GROUP_OF[n] = 'gen'));
['ship', 'pickup'].forEach(n => (GROUP_OF[n] = null));
const GROUPS = ['action', 'react', 'text', 'meme', 'gen'];

// ------------------------------------------------------------------ giphy search terms
const ACTION = { // [phrase shown in the embed, giphy search]
    cuddle: ['cuddles', 'anime cuddle'], hug: ['hugs', 'anime hug'], kiss: ['kisses', 'anime kiss'],
    nom: ['noms on', 'anime nom'], pat: ['pats', 'anime head pat'], poke: ['pokes', 'anime poke'],
    slap: ['slaps', 'anime slap'], stare: ['stares at', 'anime stare'], highfive: ['high-fives', 'anime high five'],
    bite: ['bites', 'anime bite'], punch: ['punches', 'anime punch'], handholding: ['holds hands with', 'anime holding hands'],
    tickle: ['tickles', 'anime tickle'], hold: ['holds', 'anime hold'], wave: ['waves at', 'anime wave'],
    snuggle: ['snuggles', 'anime snuggle'], spank: ['spanks', 'anime spank'], marry: ['marries', 'anime wedding'],
    pet: ['pets', 'anime pet'],
};
const REACT = {
    blush: ['is blushing', 'anime blush'], cry: ['is crying', 'anime cry'], dance: ['is dancing', 'anime dance'],
    pout: ['is pouting', 'anime pout'], shrug: ['shrugs', 'anime shrug'], sleepy: ['is feeling sleepy', 'anime sleepy'],
    smile: ['smiles', 'anime smile'], smug: ['looks smug', 'anime smug'], thumbsup: ['gives a thumbs up', 'anime thumbs up'],
    thinking: ['is thinking', 'anime thinking'], triggered: ['is triggered', 'anime triggered angry'],
    teehee: ['giggles', 'anime giggle'], deredere: ['is feeling deredere', 'anime happy blush'],
    scoff: ['scoffs', 'anime scoff'], happy: ['is happy', 'anime happy'], thumbs: ['gives a thumbs up', 'anime thumbs up'],
    pray: ['is praying', 'anime pray'], curse: ['is cursing', 'anime angry rage'],
};
const MEME = { // giphy search used for the image-style commands
    biden: 'joe biden meme', pikachu: 'surprised pikachu', oogway: 'master oogway', drake: 'drake hotline bling meme',
    pooh: 'tuxedo winnie the pooh', sadcat: 'sad cat', factsmeme: 'facts meme', unforgivable: 'unforgivable meme',
    caution: 'caution warning', gun: 'gun meme', drip: 'drip meme', blur: 'blurry', invert: 'inverted colors',
    greyscale: 'black and white', bomb: 'bomb explosion', jail: 'jail prison', wanted: 'wanted poster',
    alert: 'alert siren', supreme: 'supreme', whowouldwin: 'who would win meme', nokia: 'nokia',
    uncover: 'uncover reveal', jokeoverhead: 'joke over head', huerotate: 'rainbow colors', quote: 'quote',
    couldread: 'could not read meme', colorify: 'colorful',
};

// ------------------------------------------------------------------ content pools
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
const JOKES = [
    "Why don't scientists trust atoms? Because they make up everything!",
    'What do you call a bear with no teeth? A gummy bear!',
    'Why did the scarecrow win an award? He was outstanding in his field!',
    'What do you call fake spaghetti? An impasta!',
    "Why don't eggs tell jokes? They'd crack up!",
    'What did the ocean say to the beach? Nothing, it just waved!',
    'Why was the math book sad? It had too many problems!',
    'I told my computer I needed a break, and now it will not stop sending me Kit-Kat ads.',
];
const FACTS = [
    "Honey never spoils. Archaeologists found 3000-year-old honey that's still edible!",
    'Octopuses have three hearts and blue blood!',
    "Bananas are berries, but strawberries aren't!",
    "A group of flamingos is called a 'flamboyance'!",
    'The shortest war in history lasted about 38 minutes!',
    'Butterflies can taste with their feet!',
    'A day on Venus is longer than a year on Venus!',
    'Sharks existed before trees did!',
];
const TRUTHS = [
    "What's the most embarrassing thing you've ever done in public?", "What's a secret you've never told anyone here?",
    "What's the last lie you told?", 'Who in this server would you swap lives with for a day?',
    "What's the weirdest thing you've ever searched for?", "What's your biggest irrational fear?",
    "What's the most childish thing you still do?", 'Have you ever pretended to be sick to skip something?',
];
const DARES = [
    'Send the last photo in your gallery (if it is safe for work!).', 'Change your nickname to whatever the next person says.',
    'Talk in rhymes for the next 5 messages.', 'Type with your eyes closed and send the result.',
    'Send a voice message singing your favourite song.', 'Compliment everyone who is online right now.',
    'Use only emojis for the next 3 minutes.', 'Say something nice about the person above you.',
];
const EIGHTBALL = [
    'It is certain.', 'It is decidedly so.', 'Without a doubt.', 'Yes, definitely.', 'You may rely on it.',
    'Most likely.', 'Outlook good.', 'Signs point to yes.', 'Reply hazy, try again.', 'Ask again later.',
    'Better not tell you now.', 'Cannot predict now.', "Don't count on it.", 'My reply is no.',
    'My sources say no.', 'Outlook not so good.', 'Very doubtful.',
];
const OPINIONS = [
    'Pineapple on pizza is perfectly fine.', 'Cats are better than dogs. Fight me.', 'Breakfast is the best meal of the day.',
    'Rainy days are underrated.', 'Sequels are rarely better than the original.', 'Socks with sandals are a power move.',
    'Mornings are overrated.', 'Cereal counts as soup.',
];
const SHOWERTHOUGHTS = [
    "Your future self is watching you right now through memories.", 'Every ocean is touching every other ocean.',
    'The word "bed" looks like a bed.', "Nobody's ever seen a 'new' old person.",
    'You have never seen your own face, only reflections and photos.', 'Sleep is just a nightly free trial of being dead.',
    'Autocorrect has become our own generation\'s handwriting.', "Your brain named itself.",
];
const PICKUP = [
    'Are you a magician? Because whenever I look at you, everyone else disappears!', 'Do you have a map? I keep getting lost in your eyes!',
    "Are you a parking ticket? Because you've got FINE written all over you!", 'Is your name Google? Because you have everything I\'ve been searching for!',
    'Do you believe in love at first sight, or should I walk by again?', 'Are you WiFi? Because I\'m feeling a connection!',
    "If you were a vegetable, you'd be a cute-cumber!", 'Are you a camera? Because every time I look at you, I smile!',
];
const MNM = {
    red: 'Bold and confident. You walk into a room like you own it.', orange: 'Warm, social and always up for an adventure.',
    yellow: 'The sunshine of the bag. Everyone loves being around you.', green: 'Calm, cool and quietly clever.',
    blue: 'Laid back and loyal. A natural peacemaker.', brown: 'Reliable and down to earth. The classic.',
};

// ------------------------------------------------------------------ text transforms
const DOUBLE = { a: '𝕒', b: '𝕓', c: '𝕔', d: '𝕕', e: '𝕖', f: '𝕗', g: '𝕘', h: '𝕙', i: '𝕚', j: '𝕛', k: '𝕜', l: '𝕝', m: '𝕞', n: '𝕟', o: '𝕠', p: '𝕡', q: '𝕢', r: '𝕣', s: '𝕤', t: '𝕥', u: '𝕦', v: '𝕧', w: '𝕨', x: '𝕩', y: '𝕪', z: '𝕫',
    A: '𝔸', B: '𝔹', C: 'ℂ', D: '𝔻', E: '𝔼', F: '𝔽', G: '𝔾', H: 'ℍ', I: '𝕀', J: '𝕁', K: '𝕂', L: '𝕃', M: '𝕄', N: 'ℕ', O: '𝕆', P: 'ℙ', Q: 'ℚ', R: 'ℝ', S: '𝕊', T: '𝕋', U: '𝕌', V: '𝕍', W: '𝕎', X: '𝕏', Y: '𝕐', Z: 'ℤ',
    0: '𝟘', 1: '𝟙', 2: '𝟚', 3: '𝟛', 4: '𝟜', 5: '𝟝', 6: '𝟞', 7: '𝟟', 8: '𝟠', 9: '𝟡' };
const MORSE = { a: '.-', b: '-...', c: '-.-.', d: '-..', e: '.', f: '..-.', g: '--.', h: '....', i: '..', j: '.---', k: '-.-', l: '.-..', m: '--', n: '-.', o: '---', p: '.--.', q: '--.-', r: '.-.', s: '...', t: '-', u: '..-', v: '...-', w: '.--', x: '-..-', y: '-.--', z: '--..',
    0: '-----', 1: '.----', 2: '..---', 3: '...--', 4: '....-', 5: '.....', 6: '-....', 7: '--...', 8: '---..', 9: '----.', '.': '.-.-.-', ',': '--..--', '?': '..--..', '!': '-.-.--' };
const EMOJIPASTA = { fire: '🔥', hot: '🔥', love: '😍', good: '👌', great: '👌', cool: '😎', funny: '😂', lol: '😂', sad: '😢', cry: '😭', hundred: '💯', yes: '👏', no: '🙅', food: '🍔', pizza: '🍕', party: '🎉', money: '💰', sleep: '😴', angry: '😡', think: '🤔', heart: '❤️', star: '⭐', ok: '👌' };
const FILLER_EMOJI = ['😂', '👌', '🔥', '💯', '😍', '🙌', '✨', '😎'];

const transforms = {
    reverse: (t) => [...t].reverse().join(''),
    mock: (t) => { let i = 0; return [...t].map(c => (/[a-z]/i.test(c) ? (i++ % 2 ? c.toUpperCase() : c.toLowerCase()) : c)).join(''); },
    doublestruck: (t) => [...t].map(c => DOUBLE[c] || c).join(''),
    morse: (t) => [...t.toLowerCase()].map(c => (c === ' ' ? '/' : MORSE[c] || '')).filter(Boolean).join(' ') || '(nothing that can be translated)',
    emojipasta: (t) => t.split(/\s+/).map(w => {
        const key = w.toLowerCase().replace(/[^a-z]/g, '');
        return `${w} ${EMOJIPASTA[key] || (Math.random() < 0.3 ? pick(FILLER_EMOJI) : '')}`.trim();
    }).join(' '),
};

const rnd = (n) => Math.floor(Math.random() * n);
const randHex = (n) => Array.from({ length: n }, () => rnd(16).toString(16)).join('');
const fakeToken = () => {
    const b64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-';
    const part = (n) => Array.from({ length: n }, () => b64[rnd(b64.length)]).join('');
    return `${part(24)}.${part(6)}.${part(27)}`;
};

// stable 0-100 number out of a string (so "ship" gives the same % for the same pair)
const stable = (str) => { let h = 0; for (const c of str) h = (h * 31 + c.charCodeAt(0)) >>> 0; return h % 101; };
const bar = (pct) => `${'█'.repeat(Math.round(pct / 10))}${'░'.repeat(10 - Math.round(pct / 10))}`;

// ------------------------------------------------------------------ embed + gif helpers
const COLOR = '#2b2d31';

/** Embed with a Giphy GIF in it. Falls back to a plain text embed (+ a hint) if Giphy fails. */
async function gifEmbed(query, build) {
    const embed = new EmbedBuilder().setColor(COLOR);
    build(embed);
    try {
        const gif = await giphy.random(query);
        if (gif) embed.setImage(gif.url);
        else embed.setFooter({ text: 'No GIF found for this one.' });
    } catch (e) {
        if (e.code === 'NO_KEY') embed.setFooter({ text: 'GIFs are off: the bot owner needs to set GIPHY_API_KEY.' });
        else { console.error('Giphy error:', e.message); embed.setFooter({ text: 'Giphy is not reachable right now, no GIF this time.' }); }
    }
    return embed;
}
const textEmbed = (title, description) => {
    const e = new EmbedBuilder().setColor(COLOR).setDescription(description);
    return title ? e.setTitle(title) : e;
};

function helpEmbed(message) {
    return common.helpEmbed(
        `» **fun <hug/kiss/slap/pat/…> @user**\n› Action GIFs.\n\n` +
        `» **fun <blush/cry/dance/smile/…>**\n› Reaction GIFs.\n\n` +
        `» **fun joke/fact/truth/dare/eightball/cat/mydog/waifu…**\n› Random fun content.\n\n` +
        `» **fun reverse/mock/morse/doublestruck/emojipasta/hack/caption <text>**\n› Text tools.\n\n` +
        `» **fun biden/pikachu/drake/jail/wanted… [text] [@user]**\n› Meme GIFs.\n\n` +
        `» **fun ship @user1 @user2** · **fun pickup**\n\n` +
        `You can also use them directly, e.g. \`hug @user\`.\n` +
        `Slash version: \`/fun action hug\`, \`/fun react cry\`, \`/fun text joke\`…`,
        message);
}

// ------------------------------------------------------------------ the actual logic (shared by slash + prefix)
/** o = { target, user, user1, user2, text } ; me = the invoking user */
async function run(ctx, name, o) {
    const me = ctx.user;

    if (ACTION[name]) {
        if (!o.target) return ctx.fail(`Please mention a user. Usage: \`fun ${name} @user\``);
        const [verb, query] = ACTION[name];
        const self = o.target.id === me.id;
        return ctx.send({ embeds: [await gifEmbed(query, e => e.setDescription(
            self ? `${me} **${verb}** themselves... 🥲` : `${me} **${verb}** ${o.target}!`))] });
    }

    if (REACT[name]) {
        const [phrase, query] = REACT[name];
        return ctx.send({ embeds: [await gifEmbed(query, e => e.setDescription(`${me} **${phrase}**!`))] });
    }

    if (MEME[name]) {
        const subject = o.user ? `${o.user}` : null;
        return ctx.send({ embeds: [await gifEmbed(MEME[name], e => {
            e.setTitle(name.charAt(0).toUpperCase() + name.slice(1));
            const lines = [];
            if (o.text) lines.push(common.truncate(o.text, 500));
            if (subject) lines.push(`↳ ${subject}`);
            if (lines.length) e.setDescription(lines.join('\n'));
            e.setFooter({ text: `Requested by ${me.username}` });
        })] });
    }

    if (transforms[name]) {
        if (!o.text) return ctx.fail(`Please provide some text. Usage: \`fun ${name} <text>\``);
        return ctx.send({ embeds: [textEmbed(null, common.truncate(transforms[name](o.text), 4000))] });
    }

    switch (name) {
        case 'mydog':
            return ctx.send({ embeds: [await gifEmbed('cute dog', e => e.setDescription(`🐶 **${me.username}'s dog says woof!**`))] });
        case 'cat':
            return ctx.send({ embeds: [await gifEmbed('cute cat', e => e.setDescription(`🐱 **Meow!** Cats sleep for about 70% of their lives.`))] });
        case 'cute':
            return ctx.send({ embeds: [await gifEmbed('cute animals', e => e.setDescription(`🥰 Here is some cuteness for ${me}!`))] });
        case 'waifu':
            return ctx.send({ embeds: [await gifEmbed('anime girl', e => e.setDescription(`💖 ${me}, meet your waifu!`))] });
        case 'joke': return ctx.send({ embeds: [textEmbed('😂 Joke', pick(JOKES))] });
        case 'fact': return ctx.send({ embeds: [textEmbed('💡 Fact', pick(FACTS))] });
        case 'truth': return ctx.send({ embeds: [textEmbed('🫣 Truth', pick(TRUTHS))] });
        case 'dare': return ctx.send({ embeds: [textEmbed('😈 Dare', pick(DARES))] });
        case 'opinion': return ctx.send({ embeds: [textEmbed('🗣️ My opinion', pick(OPINIONS))] });
        case 'showerthought': return ctx.send({ embeds: [textEmbed('🚿 Shower thought', pick(SHOWERTHOUGHTS))] });
        case 'pickup': return ctx.send({ embeds: [textEmbed('💘 Pickup line', pick(PICKUP))] });
        case 'eightball': return ctx.send({ embeds: [textEmbed('🎱 Magic 8-ball', pick(EIGHTBALL))] });
        case 'mnm': {
            const [colour, desc] = pick(Object.entries(MNM));
            return ctx.send({ embeds: [textEmbed('🍬 Which M&M are you?', `${me} is a **${colour}** M&M!\n${desc}`)] });
        }
        case 'intelligence': {
            const iq = 60 + rnd(100);
            return ctx.send({ embeds: [textEmbed('🧠 Intelligence', `${me}'s IQ is **${iq}**!`)] });
        }
        case 'horny': {
            const p = rnd(101);
            return ctx.send({ embeds: [textEmbed('🌡️ Horny meter', `${me} is **${p}%** horny\n\`${bar(p)}\``)] });
        }
        case 'clown': {
            const p = rnd(101);
            return ctx.send({ embeds: [await gifEmbed('clown', e => e.setDescription(`🤡 ${me} is **${p}%** clown\n\`${bar(p)}\``))] });
        }
        case 'token':
            return ctx.send({ embeds: [textEmbed('🔑 Token', `\`${fakeToken()}\`\n*(totally fake, just for fun)*`)] });
        case 'ship': {
            if (!o.user1 || !o.user2) return ctx.fail('Please mention two users. Usage: `fun ship @user1 @user2`');
            const pct = stable([o.user1.id, o.user2.id].sort().join(':'));
            const verdict = pct > 80 ? 'Soulmates! 💞' : pct > 60 ? 'Looking good! 💖' : pct > 40 ? 'Could work... 💛' : pct > 20 ? 'Needs effort. 🧡' : 'Not a match. 💔';
            return ctx.send({ embeds: [await gifEmbed(pct > 50 ? 'anime love' : 'anime sad', e => e
                .setTitle('💘 Love Calculator')
                .setDescription(`${o.user1} 💕 ${o.user2}\n\n**${pct}%** \`${bar(pct)}\`\n${verdict}`))] });
        }
        default:
            return ctx.fail('Unknown fun command.');
    }
}

// advertise / hack / caption need text input and have richer output, so they live here
const textExtras = {
    advertise: async (ctx, text) => textEmbed('📢 Advertisement', `**${common.truncate(text, 200)}**\nNow available in a store near you. Terms and conditions apply, side effects include having fun.`),
    hack: async (ctx, text) => textEmbed(`💻 Hacking ${common.truncate(text, 60)}…`,
        `\`\`\`\n[▓▓▓▓▓▓▓▓▓▓] 100%\nEmail:    ${randHex(8)}@fakemail.invalid\nPassword: ${randHex(10)}\nIP:       ${rnd(223) + 1}.${rnd(256)}.${rnd(256)}.${rnd(256)}\nLast DM:  "pls dont tell anyone"\n\`\`\`\n*Everything above is 100% fake.*`),
    caption: async (ctx, text) => gifEmbed(text, e => e.setDescription(common.truncate(text, 300)).setFooter({ text: `Requested by ${ctx.user.username}` })),
};

async function dispatch(ctx, name, o) {
    if (textExtras[name]) {
        if (!o.text) return ctx.fail(`Please provide some text. Usage: \`fun ${name} <text>\``);
        return ctx.send({ embeds: [await textExtras[name](ctx, o.text)] });
    }
    return run(ctx, name, o);
}

// ------------------------------------------------------------------ slash definition
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
const imgSub = (name) => (sub) => sub.setName(name).setDescription(`${cap(name)} meme GIF`)
    .addStringOption(opt => opt.setName('text').setDescription('Text').setRequired(false))
    .addUserOption(opt => opt.setName('user').setDescription('User').setRequired(false));

const command = {
    data: new SlashCommandBuilder()
        .setName('fun')
        .setDescription('A variety of fun commands')
        .addSubcommandGroup(group => {
            group.setName('action').setDescription('Interaction commands');
            interactionCommands.forEach(name => group.addSubcommand(sub => sub.setName(name).setDescription(`${cap(name)} someone`)
                .addUserOption(opt => opt.setName('target').setDescription('User').setRequired(true))));
            return group;
        })
        .addSubcommandGroup(group => {
            group.setName('react').setDescription('Reaction commands');
            reactionCommands.forEach(name => group.addSubcommand(sub => sub.setName(name).setDescription(`React: ${name}`)));
            return group;
        })
        .addSubcommandGroup(group => {
            group.setName('text').setDescription('Text-based fun commands');
            simpleTextCommands.forEach(name => group.addSubcommand(sub => sub.setName(name).setDescription(`Random ${name}`)));
            textInputCommands.forEach(name => group.addSubcommand(sub => sub.setName(name).setDescription(`${cap(name)} some text`)
                .addStringOption(opt => opt.setName('text').setDescription('Text').setRequired(true))));
            return group;
        })
        .addSubcommandGroup(group => {
            group.setName('meme').setDescription('Meme GIF commands (1)');
            imageGenCommands1.forEach(name => group.addSubcommand(imgSub(name)));
            return group;
        })
        .addSubcommandGroup(group => {
            group.setName('gen').setDescription('Meme GIF commands (2)');
            imageGenCommands2.forEach(name => group.addSubcommand(imgSub(name)));
            return group;
        })
        .addSubcommand(sub => sub.setName('ship').setDescription('Ship two users together')
            .addUserOption(opt => opt.setName('user1').setDescription('First user').setRequired(true))
            .addUserOption(opt => opt.setName('user2').setDescription('Second user').setRequired(true)))
        .addSubcommand(sub => sub.setName('pickup').setDescription('Get a random pickup line'))
        .addSubcommand(sub => sub.setName('help').setDescription('Show help for fun commands')),

    async execute(interaction) {
        const sub = interaction.options.getSubcommand();
        if (sub === 'help') return interaction.reply({ embeds: [helpEmbed({ author: interaction.user })] });

        // Giphy can take a moment; defer so Discord does not time the interaction out
        await interaction.deferReply();
        const ctx = common.fromInteraction(interaction);
        await dispatch(ctx, sub, {
            target: interaction.options.getUser('target'),
            user: interaction.options.getUser('user'),
            user1: interaction.options.getUser('user1'),
            user2: interaction.options.getUser('user2'),
            text: interaction.options.getString('text'),
        });
    },

    /** !fun <name> ...   (also reached through the direct aliases below) */
    async executeMessage(message, args) {
        args = [...args];
        if (args[0] && GROUPS.includes(args[0].toLowerCase())) args.shift();
        const name = args[0] ? args[0].toLowerCase() : 'help';
        if (name === 'help' || !(name in GROUP_OF)) return message.reply({ embeds: [helpEmbed(message)] });

        const ctx = common.fromMessage(message);
        const rest = args.slice(1);
        const mentioned = [...message.mentions.users.values()];
        const textArg = rest.join(' ').trim();
        // anything that is not a mention counts as text
        const plainText = rest.filter(w => !/^<@!?\d+>$/.test(w)).join(' ').trim();

        await message.channel.sendTyping().catch(() => {});
        return dispatch(ctx, name, {
            target: mentioned[0],
            user: mentioned[0],
            user1: mentioned[0],
            user2: mentioned[1],
            text: GROUP_OF[name] === 'text' ? textArg : plainText,
        });
    },
};

// Direct prefix aliases:  !hug @user, !joke, !ship @a @b ...   (prefix only, no extra slash commands)
const aliases = Object.keys(GROUP_OF).map(name => ({
    name,
    executeMessage: (message, args) => command.executeMessage(message, [name, ...args]),
}));
// fhelp is the name the help menu already advertises
aliases.push({ name: 'fhelp', executeMessage: (message) => message.reply({ embeds: [helpEmbed(message)] }) });

module.exports = [command, ...aliases];
