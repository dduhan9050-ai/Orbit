const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const embedHelper = require('../../functions/embedHelper');

module.exports = [
    {
        data: new SlashCommandBuilder()
            .setName('embed')
            .setDescription('Embed management commands')
            .addSubcommand(sub => sub.setName('rename').setDescription('Rename an embed').addStringOption(opt => opt.setName('name').setDescription('Current name').setRequired(true)).addStringOption(opt => opt.setName('newname').setDescription('New name').setRequired(true)))
            .addSubcommand(sub => sub.setName('send').setDescription('Send an embed').addStringOption(opt => opt.setName('name').setDescription('Embed name').setRequired(true)).addChannelOption(opt => opt.setName('channel').setDescription('Target channel')))
            .addSubcommand(sub => sub.setName('delete').setDescription('Delete an embed').addStringOption(opt => opt.setName('name').setDescription('Embed name').setRequired(true)))
            .addSubcommand(sub => sub.setName('show').setDescription('Show an embed').addStringOption(opt => opt.setName('name').setDescription('Embed name').setRequired(true)))
            .addSubcommand(sub => sub.setName('export').setDescription('Export an embed JSON').addStringOption(opt => opt.setName('name').setDescription('Embed name').setRequired(true)))
            .addSubcommand(sub => sub.setName('edit').setDescription('Edit an existing embed').addStringOption(opt => opt.setName('name').setDescription('Embed name').setRequired(true)))
            .addSubcommand(sub => sub.setName('save').setDescription('Save current embed').addStringOption(opt => opt.setName('name').setDescription('Embed name').setRequired(true)))
            .addSubcommand(sub => sub.setName('import').setDescription('Import an embed from JSON').addStringOption(opt => opt.setName('json').setDescription('JSON data').setRequired(true)).addStringOption(opt => opt.setName('name').setDescription('Name for the embed').setRequired(true)))
            .addSubcommand(sub => sub.setName('create').setDescription('Create a new embed').addStringOption(opt => opt.setName('name').setDescription('Name for the embed').setRequired(true)))
            .addSubcommand(sub => sub.setName('guide').setDescription('Show embed builder guide')),
        async execute(interaction) {
            if (!interaction.member.permissions.has('ManageGuild')) {
                return interaction.reply({ content: '❌ No access', flags: MessageFlags.Ephemeral });
            }

            const sub = interaction.options.getSubcommand();
            await interaction.reply({ embeds: [new EmbedBuilder().setTitle('Embed System').setDescription(`Executed embed sub-command: **${sub}**`).setColor('#000000')] });
        },
        async executeMessage(message, args) {
            if (!message.member.permissions.has('ManageGuild')) {
                return message.reply({ embeds: [embedHelper.error('❌ No access')] });
            }

            const subcommand = args[0] ? args[0].toLowerCase() : 'help';
            const embed = new EmbedBuilder()
                .setDescription(
                    `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                    `» **embed create <name>**\n› Create a new embed.\n\n` +
                    `» **embed delete <name>**\n› Delete an embed.\n\n` +
                    `» **embed rename <name> <newname>**\n› Rename an embed.\n\n` +
                    `» **embed show <name>**\n› Display an embed.\n\n` +
                    `» **embed send <name> [#channel]**\n› Send embed to a channel.\n\n` +
                    `» **embed guide**\n› Show detailed guide.`
                )
                .setColor('#2b2d31')
                .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

            if (subcommand === 'help' || !['create', 'delete', 'rename', 'show', 'send', 'guide'].includes(subcommand)) {
                return message.reply({ embeds: [embed] });
            }

            const fs = require('fs');
            const path = require('path');
            const dataPath = path.join(__dirname, '../../data/embeds.json');
            
            let data = {};
            try {
                if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            } catch (e) { }
            
            const guildId = message.guild.id;
            if (!data[guildId]) data[guildId] = { embeds: {} };

            if (subcommand === 'guide') {
                const guideEmbed = new EmbedBuilder()
                    .setTitle('📚 Embed Builder Guide')
                    .setDescription('Use `/embed create <name>` for the interactive builder.\n\nPrefix commands:\n• `!embed create <name>` - Create new embed\n• `!embed delete <name>` - Delete embed\n• `!embed rename <old> <new>` - Rename\n• `!embed show <name>` - Display embed\n• `!embed send <name> #channel` - Send to channel')
                    .setColor('#5865F2')
                    .setFooter({ text: 'Use slash commands for full editing capabilities' });
                return message.reply({ embeds: [guideEmbed] });
            }

            if (subcommand === 'create') {
                const embedName = args[1];
                if (!embedName) return message.reply({ embeds: [embedHelper.error('Please provide an embed name. Example: `!embed create welcome`')] });
                if (data[guildId].embeds[embedName]) return message.reply({ embeds: [embedHelper.error(`Embed "${embedName}" already exists.`)] });
                
                data[guildId].embeds[embedName] = {
                    title: 'New Embed',
                    description: 'Edit this embed using /embed edit',
                    color: '#5865F2',
                    timestamp: false,
                    footer: { text: '' },
                    author: { name: '' },
                    fields: []
                };
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`Embed "${embedName}" created! Use \`/embed edit ${embedName}\` to customize it.`)] });
            }

            if (subcommand === 'delete') {
                const embedName = args[1];
                if (!embedName) return message.reply({ embeds: [embedHelper.error('Please provide an embed name. Example: `!embed delete welcome`')] });
                if (!data[guildId].embeds[embedName]) return message.reply({ embeds: [embedHelper.error(`Embed "${embedName}" not found.`)] });
                delete data[guildId].embeds[embedName];
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`Embed "${embedName}" has been deleted.`)] });
            }

            if (subcommand === 'rename') {
                const oldName = args[1];
                const newName = args[2];
                if (!oldName || !newName) return message.reply({ embeds: [embedHelper.error('Usage: `!embed rename <oldname> <newname>`')] });
                if (!data[guildId].embeds[oldName]) return message.reply({ embeds: [embedHelper.error(`Embed "${oldName}" not found.`)] });
                if (data[guildId].embeds[newName]) return message.reply({ embeds: [embedHelper.error(`Embed "${newName}" already exists.`)] });
                
                data[guildId].embeds[newName] = data[guildId].embeds[oldName];
                delete data[guildId].embeds[oldName];
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`Embed renamed from "${oldName}" to "${newName}".`)] });
            }

            if (subcommand === 'show') {
                const embedName = args[1];
                if (!embedName) return message.reply({ embeds: [embedHelper.error('Please provide an embed name. Example: `!embed show welcome`')] });
                const embedData = data[guildId].embeds[embedName];
                if (!embedData) return message.reply({ embeds: [embedHelper.error(`Embed "${embedName}" not found.`)] });
                
                const displayEmbed = new EmbedBuilder()
                    .setTitle(embedData.title || null)
                    .setDescription(embedData.description || null)
                    .setColor(embedData.color || '#5865F2');
                
                if (embedData.author?.name) displayEmbed.setAuthor({ name: embedData.author.name, iconURL: embedData.author.icon_url });
                if (embedData.footer?.text) displayEmbed.setFooter({ text: embedData.footer.text, iconURL: embedData.footer.icon_url });
                if (embedData.thumbnail) displayEmbed.setThumbnail(embedData.thumbnail);
                if (embedData.image) displayEmbed.setImage(embedData.image);
                if (embedData.timestamp) displayEmbed.setTimestamp();
                if (embedData.fields) embedData.fields.forEach(f => displayEmbed.addFields({ name: f.name, value: f.value, inline: f.inline || false }));
                
                return message.reply({ embeds: [displayEmbed] });
            }

            if (subcommand === 'send') {
                const embedName = args[1];
                if (!embedName) return message.reply({ embeds: [embedHelper.error('Please provide an embed name. Example: `!embed send welcome #channel`')] });
                const embedData = data[guildId].embeds[embedName];
                if (!embedData) return message.reply({ embeds: [embedHelper.error(`Embed "${embedName}" not found.`)] });
                
                const targetChannel = message.mentions.channels.first() || message.channel;
                
                const sendEmbed = new EmbedBuilder()
                    .setTitle(embedData.title || null)
                    .setDescription(embedData.description || null)
                    .setColor(embedData.color || '#5865F2');
                
                if (embedData.author?.name) sendEmbed.setAuthor({ name: embedData.author.name, iconURL: embedData.author.icon_url });
                if (embedData.footer?.text) sendEmbed.setFooter({ text: embedData.footer.text, iconURL: embedData.footer.icon_url });
                if (embedData.thumbnail) sendEmbed.setThumbnail(embedData.thumbnail);
                if (embedData.image) sendEmbed.setImage(embedData.image);
                if (embedData.timestamp) sendEmbed.setTimestamp();
                if (embedData.fields) embedData.fields.forEach(f => sendEmbed.addFields({ name: f.name, value: f.value, inline: f.inline || false }));
                
                try {
                    await targetChannel.send({ embeds: [sendEmbed] });
                    return message.reply({ embeds: [embedHelper.success(`Embed "${embedName}" sent to ${targetChannel}.`)] });
                } catch (error) {
                    return message.reply({ embeds: [embedHelper.error(`Failed to send embed. Check bot permissions in ${targetChannel}.`)] });
                }
            }

            return message.reply({ embeds: [embed] });
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('variables')
            .setDescription('Show available variables for modules')
            .addStringOption(opt => opt.setName('module').setDescription('The module to check variables for').setRequired(true))
            .addStringOption(opt => opt.setName('category').setDescription('The category to check variables for').setRequired(true)),
        async execute(interaction) {
            const moduleName = interaction.options.getString('module');
            const category = interaction.options.getString('category');
            const embed = new EmbedBuilder()
                .setTitle('Variables Helper')
                .setDescription(`Showing variables for Module: **${moduleName}**, Category: **${category}**\n\n` +
                    `• \`{user}\` - Mentions the user\n` +
                    `• \`{user.name}\` - User's name\n` +
                    `• \`{guild.name}\` - Server name\n` +
                    `• \`{member.count}\` - Total members`)
                .setColor('#000000');
            await interaction.reply({ embeds: [embed] });
        },
        async executeMessage(message, args) {
            const moduleName = args[0] || 'greet';
            const category = args[1] || 'welcome';
            
            const embed = new EmbedBuilder()
                .setTitle('📝 Variables Helper')
                .setDescription(`Available variables for modules:\n\n` +
                    `**User Variables:**\n` +
                    `• \`{user}\` - Mentions the user\n` +
                    `• \`{user.name}\` - User's username\n` +
                    `• \`{user.tag}\` - User's tag (name#0000)\n` +
                    `• \`{user.id}\` - User's ID\n\n` +
                    `**Server Variables:**\n` +
                    `• \`{guild.name}\` - Server name\n` +
                    `• \`{guild.id}\` - Server ID\n` +
                    `• \`{member.count}\` - Total member count\n\n` +
                    `**Channel Variables:**\n` +
                    `• \`{channel}\` - Mentions the channel\n` +
                    `• \`{channel.name}\` - Channel name\n\n` +
                    `Use these in greet, boost, leave messages and embeds!`)
                .setColor('#5865F2')
                .setFooter({ text: `Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });
            
            return message.reply({ embeds: [embed] });
        }
    }
];
