const { PermissionFlagsBits: P } = require('discord.js');
const { makeCommand, UserError, parseDuration, formatDuration, sendTemp } = require('../../functions/commandKit');
const tempRoles = require('../../functions/tempRoleManager');

const ROLE_PERMS = { perms: [P.ManageRoles], botPerms: [P.ManageRoles] };

const roleOpt = { name: 'role', type: 'role', description: 'The role', required: true };
const userOpt = { name: 'user', type: 'user', description: 'The user', required: true };

const GROUPS = {
    humans: { label: 'all humans', test: (m) => !m.user.bot },
    bots: { label: 'all bots', test: (m) => m.user.bot },
    all: { label: 'everyone', test: () => true },
    // members with no roles other than @everyone (and the role being handled)
    unverified: { label: 'all unverified members (no roles)', test: (m, role) => m.roles.cache.filter(r => r.id !== m.guild.id && r.id !== role.id).size === 0 }
};

async function massRole(ctx, groupName, role, action) {
    ctx.checkRole(role, action === 'add' ? 'assign' : 'remove');
    const group = GROUPS[groupName];
    await ctx.defer();
    const members = await ctx.guild.members.fetch();
    const targets = members.filter(m => group.test(m, role) && (action === 'add' ? !m.roles.cache.has(role.id) : m.roles.cache.has(role.id)));
    if (targets.size === 0) throw new UserError(`Nobody in **${group.label}** needs this change.`);
    let ok = 0, failed = 0;
    for (const m of targets.values()) {
        try {
            if (action === 'add') await m.roles.add(role, `Mass role by ${ctx.member.user.tag}`);
            else await m.roles.remove(role, `Mass role removal by ${ctx.member.user.tag}`);
            ok++;
        } catch (e) { failed++; }
    }
    await ctx.success(`✅ ${action === 'add' ? 'Added' : 'Removed'} ${role} ${action === 'add' ? 'to' : 'from'} **${ok}** member(s) (${group.label})${failed ? ` - ${failed} failed` : ''}.`);
}

const massSub = (groupName, defaultAction) => ({
    description: `${defaultAction === 'add' ? 'Add' : 'Remove'} a role ${defaultAction === 'add' ? 'to' : 'from'} ${GROUPS[groupName].label}`,
    options: [roleOpt],
    async run(ctx, p) { await massRole(ctx, groupName, p.role, defaultAction); }
});

module.exports = [
    makeCommand({
        name: 'role',
        description: 'Role management commands',
        ...ROLE_PERMS,
        subs: {
            add: {
                description: 'Add a role to a user',
                options: [userOpt, roleOpt],
                async run(ctx, p) {
                    ctx.checkRole(p.role, 'assign');
                    const member = p.user.member;
                    if (!member) throw new UserError('That user is not in this server.');
                    if (member.roles.cache.has(p.role.id)) throw new UserError(`${member} already has ${p.role}.`);
                    await member.roles.add(p.role, `Added by ${ctx.member.user.tag}`);
                    await sendTemp(ctx, 'success', `✅ Added ${p.role} to ${member}`);
                }
            },
            remove: {
                description: 'Remove a role from a user',
                options: [userOpt, roleOpt],
                async run(ctx, p) {
                    ctx.checkRole(p.role, 'remove');
                    const member = p.user.member;
                    if (!member) throw new UserError('That user is not in this server.');
                    if (!member.roles.cache.has(p.role.id)) throw new UserError(`${member} does not have ${p.role}.`);
                    await member.roles.remove(p.role, `Removed by ${ctx.member.user.tag}`);
                    await sendTemp(ctx, 'success', `✅ Removed ${p.role} from ${member}`);
                }
            },
            create: {
                description: 'Create a new role',
                options: [{ name: 'name', type: 'rest', description: 'Role name', required: true }],
                async run(ctx, p) {
                    const role = await ctx.guild.roles.create({ name: p.name, reason: `Created by ${ctx.member.user.tag}` });
                    await sendTemp(ctx, 'success', `✅ Created role ${role}`);
                }
            },
            delete: {
                description: 'Delete a role',
                options: [{ name: 'role', type: 'role', description: 'The role to delete', required: true }],
                async run(ctx, p) {
                    ctx.checkRole(p.role, 'delete');
                    const name = p.role.name;
                    await p.role.delete(`Deleted by ${ctx.member.user.tag}`);
                    await sendTemp(ctx, 'success', `✅ Deleted role **${name}**`);
                }
            },
            rename: {
                description: 'Rename a role',
                options: [{ name: 'role', type: 'role', description: 'The role', required: true }, { name: 'name', type: 'rest', description: 'New name', required: true }],
                async run(ctx, p) {
                    ctx.checkRole(p.role, 'rename');
                    await p.role.setName(p.name, `Renamed by ${ctx.member.user.tag}`);
                    await sendTemp(ctx, 'success', `✅ Renamed role to **${p.name}**`);
                }
            },
            colour: {
                description: 'Change a role colour',
                options: [{ name: 'role', type: 'role', description: 'The role', required: true }, { name: 'colour', type: 'string', description: 'Hex code, e.g. #FF5555', required: true }],
                async run(ctx, p) {
                    if (!/^#?[0-9a-f]{6}$/i.test(p.colour)) throw new UserError('Please provide a valid hex colour, e.g. `#FF5555`.');
                    ctx.checkRole(p.role, 'edit');
                    const hex = p.colour.startsWith('#') ? p.colour : `#${p.colour}`;
                    await p.role.setColor(hex, `Colour changed by ${ctx.member.user.tag}`);
                    await sendTemp(ctx, 'success', `✅ Changed the colour of ${p.role} to **${hex.toUpperCase()}**`);
                }
            },
            icon: {
                description: 'Change a role icon (needs server boost level 2)',
                options: [{ name: 'role', type: 'role', description: 'The role', required: true }, { name: 'icon', type: 'string', description: 'Image URL or emoji', required: true }],
                async run(ctx, p) {
                    ctx.checkRole(p.role, 'edit');
                    await p.role.setIcon(p.icon, `Icon changed by ${ctx.member.user.tag}`);
                    await sendTemp(ctx, 'success', `✅ Updated the icon of ${p.role}`);
                }
            },
            temp: {
                description: 'Add a temporary role to a user',
                options: [userOpt, roleOpt, { name: 'time', type: 'string', description: 'Duration, e.g. 1h, 1d', required: true }],
                async run(ctx, p) {
                    const ms = parseDuration(p.time);
                    if (!ms) throw new UserError('Invalid time. Examples: `30m`, `2h`, `1d`.');
                    ctx.checkRole(p.role, 'assign');
                    const member = p.user.member;
                    if (!member) throw new UserError('That user is not in this server.');
                    await member.roles.add(p.role, `Temp role (${formatDuration(ms)}) by ${ctx.member.user.tag}`);
                    tempRoles.add(ctx.guild.id, member.id, p.role.id, Date.now() + ms);
                    await sendTemp(ctx, 'success', `⏳ Added ${p.role} to ${member} for **${formatDuration(ms)}**`);
                }
            },
            humans: massSub('humans', 'add'),
            bots: massSub('bots', 'add'),
            all: massSub('all', 'add'),
            unverified: massSub('unverified', 'add')
        }
    }),

    // rrole: remove a role from a whole group (counterpart of `role humans/bots/all/unverified`)
    makeCommand({
        name: 'rrole',
        description: 'Remove a role from everyone in a group',
        ...ROLE_PERMS,
        subs: {
            humans: massSub('humans', 'remove'),
            bots: massSub('bots', 'remove'),
            unverified: massSub('unverified', 'remove'),
            all: massSub('all', 'remove')
        }
    })
];
