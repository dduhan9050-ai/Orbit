const { PermissionFlagsBits: P } = require('discord.js');
const { makeCommand, UserError, sendTemp } = require('../../functions/commandKit');

const EMOJI_RE = /<a?:\w+:\d+>|\p{Extended_Pictographic}/u;

const FILTERS = {
    all: () => true,
    bots: (m) => m.author.bot,
    image: (m) => [...m.attachments.values()].some(a => (a.contentType || '').startsWith('image/')) || m.embeds.some(e => e.image || e.thumbnail),
    embed: (m) => m.embeds.length > 0,
    files: (m) => m.attachments.size > 0,
    emoji: (m) => EMOJI_RE.test(m.content),
    mentions: (m) => m.mentions.users.size > 0 || m.mentions.roles.size > 0 || m.mentions.everyone,
    reactions: (m) => m.reactions.cache.size > 0
};

async function purge(ctx, amount, predicate, label) {
    if (amount === null || amount === undefined) amount = 100;
    if (!amount || amount < 1 || amount > 100) throw new UserError('Please provide an amount between 1 and 100.');
    if (ctx.deleteInvocation) await ctx.deleteInvocation();
    else await ctx.defer(true);
    const fetched = await ctx.channel.messages.fetch({ limit: amount });
    const matches = fetched.filter(m => !m.pinned && predicate(m));
    if (matches.size === 0) {
        throw new UserError('No matching messages found (messages older than 14 days cannot be bulk deleted).');
    }
    const deleted = await ctx.channel.bulkDelete(matches, true);
    if (deleted.size === 0) throw new UserError('No messages could be deleted (they may be older than 14 days).');
    await sendTemp(ctx, 'success', `✅ Deleted **${deleted.size}** message(s)${label ? ` ${label}` : ''}.`, 3000);
}

const amountOpt = (desc = 'Amount of messages to check (1-100, default 100)') => ({ name: 'amount', type: 'integer', description: desc, required: false, min: 1, max: 100 });

const sub = (description, label, predicateFor, extra = []) => ({
    description,
    options: [...extra, amountOpt()],
    async run(ctx, p) { await purge(ctx, p.amount, predicateFor(p), label); }
});

const BASE_PERMS = { perms: [P.ManageMessages], botPerms: [P.ManageMessages, P.ReadMessageHistory] };

module.exports = [
    makeCommand({
        name: 'clear',
        description: 'Clear messages in this channel',
        ...BASE_PERMS,
        subs: {
            all: sub('Clear all messages', '', () => FILTERS.all),
            image: sub('Clear messages containing images', 'with images', () => FILTERS.image),
            emoji: sub('Clear messages containing emojis', 'with emojis', () => FILTERS.emoji),
            embed: sub('Clear messages containing embeds', 'with embeds', () => FILTERS.embed),
            files: sub('Clear messages containing files', 'with files', () => FILTERS.files),
            user: sub('Clear messages from a specific user', 'from that user', (p) => (m) => m.author.id === p.target.user.id,
                [{ name: 'target', type: 'user', description: 'The user', required: true }]),
            contain: sub('Clear messages containing specific text', 'containing that text', (p) => (m) => m.content.toLowerCase().includes(p.text.toLowerCase()),
                [{ name: 'text', type: 'rest', description: 'The text to search for', required: true }]),
            bots: sub('Clear messages from bots', 'from bots', () => FILTERS.bots),
            mentions: sub('Clear messages containing mentions', 'with mentions', () => FILTERS.mentions),
            reactions: sub('Clear messages containing reactions', 'with reactions', () => FILTERS.reactions)
        }
    }),

    makeCommand({
        name: 'purgeuser',
        description: 'Purge messages from a specific user',
        ...BASE_PERMS,
        options: [
            { name: 'target', type: 'user', description: 'The user to purge', required: true },
            amountOpt()
        ],
        async run(ctx, p) { await purge(ctx, p.amount, (m) => m.author.id === p.target.user.id, 'from that user'); }
    }),

    makeCommand({
        name: 'purgebots',
        description: 'Purge messages from all bots',
        ...BASE_PERMS,
        options: [amountOpt()],
        async run(ctx, p) { await purge(ctx, p.amount, FILTERS.bots, 'from bots'); }
    })
];
