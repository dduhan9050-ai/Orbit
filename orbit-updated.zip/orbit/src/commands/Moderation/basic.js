const { EmbedBuilder, PermissionFlagsBits: P, ChannelType } = require('discord.js');
const { makeCommand, UserError, parseDuration, formatDuration, sendTemp, idFrom } = require('../../functions/commandKit');
const snipeStore = require('../../functions/snipeStore');

const MAX_TIMEOUT_MS = 28 * 24 * 60 * 60 * 1000;
const reasonOf = (r, ctx) => `${r || 'No reason provided'} | By ${ctx.member.user.tag}`;

const TEXT_TYPES = [ChannelType.GuildText, ChannelType.GuildAnnouncement];
const VOICE_TYPES = [ChannelType.GuildVoice, ChannelType.GuildStageVoice];
const isTextish = (ch) => TEXT_TYPES.includes(ch.type);
const isVoiceish = (ch) => VOICE_TYPES.includes(ch.type);

const optChannel = { name: 'channel', type: 'channel', description: 'Channel (defaults to the current one)' };

/** Edit the @everyone overwrite of a channel. `lockPerm` differs for text vs voice. */
async function setEveryone(ctx, channel, mode, value) {
    const everyone = ctx.guild.roles.everyone;
    let perms;
    if (mode === 'lock') {
        if (isTextish(channel)) perms = { SendMessages: value ? false : null, SendMessagesInThreads: value ? false : null };
        else if (isVoiceish(channel)) perms = { Connect: value ? false : null };
        else if (channel.type === ChannelType.GuildForum) perms = { SendMessages: value ? false : null };
        else throw new UserError('That channel type cannot be locked.');
    } else {
        perms = { ViewChannel: value ? false : null };
    }
    await channel.permissionOverwrites.edit(everyone, perms, { reason: `${mode} by ${ctx.member.user.tag}` });
}

const SINGLE_TOGGLES = [
    ['lock', 'Lock a channel', 'lock', true, '🔒 Locked'],
    ['unlock', 'Unlock a channel', 'lock', false, '🔓 Unlocked'],
    ['hide', 'Hide a channel', 'hide', true, '👁️ Hidden'],
    ['unhide', 'Unhide a channel', 'hide', false, '👁️ Unhidden']
].map(([name, description, mode, value, label]) => makeCommand({
    name, description,
    perms: [P.ManageChannels],
    botPerms: [P.ManageChannels],
    options: [optChannel],
    async run(ctx, p) {
        const channel = p.channel || ctx.channel;
        await setEveryone(ctx, channel, mode, value);
        await sendTemp(ctx, 'success', `${label} ${channel}`);
    }
}));

const ALL_TOGGLES = [
    ['lockall', 'Lock all channels', 'lock', true, '🔒 Locked'],
    ['unlockall', 'Unlock all channels', 'lock', false, '🔓 Unlocked'],
    ['hideall', 'Hide all channels', 'hide', true, '👁️ Hidden'],
    ['unhideall', 'Unhide all channels', 'hide', false, '👁️ Unhidden']
].map(([name, description, mode, value, label]) => makeCommand({
    name, description,
    perms: [P.ManageChannels],
    botPerms: [P.ManageChannels],
    async run(ctx) {
        await ctx.defer();
        const channels = ctx.guild.channels.cache.filter(ch => (mode === 'lock' ? (isTextish(ch) || isVoiceish(ch)) : (isTextish(ch) || isVoiceish(ch) || ch.type === ChannelType.GuildForum)));
        let done = 0, failed = 0;
        for (const ch of channels.values()) {
            try { await setEveryone(ctx, ch, mode, value); done++; } catch (e) { failed++; }
        }
        await sendTemp(ctx, 'success', `${label} **${done}** channel(s)${failed ? ` (${failed} failed - check my permissions)` : ''}.`, 6000);
    }
}));

// ---- emoji / sticker helpers
const CUSTOM_EMOJI_RE = /<(a?):(\w{2,32}):(\d{15,22})>/g;
const emojiUrl = (id, animated) => `https://cdn.discordapp.com/emojis/${id}.${animated ? 'gif' : 'png'}?size=512`;

function parseEmojis(text) {
    const out = [];
    let m;
    const re = new RegExp(CUSTOM_EMOJI_RE.source, 'g');
    while ((m = re.exec(text || '')) !== null) out.push({ animated: m[1] === 'a', name: m[2], id: m[3] });
    return out;
}

module.exports = [
    // ------------------------------------------------------------ members
    makeCommand({
        name: 'ban',
        description: 'Ban a member from the server',
        perms: [P.BanMembers],
        botPerms: [P.BanMembers],
        options: [
            { name: 'target', type: 'user', description: 'The member (or user ID) to ban', required: true },
            { name: 'reason', type: 'rest', description: 'The reason for banning' }
        ],
        async run(ctx, p) {
            const { user, member } = p.target;
            ctx.checkTarget(member || (user.id === ctx.member.id ? ctx.member : null), 'ban');
            if (!member && user.id === ctx.guild.ownerId) throw new UserError('You cannot ban the server owner.');
            const existing = await ctx.guild.bans.fetch(user.id).catch(() => null);
            if (existing) throw new UserError(`**${user.tag}** is already banned.`);
            await ctx.guild.members.ban(user.id, { reason: reasonOf(p.reason, ctx) });
            await sendTemp(ctx, 'success', `🔨 Banned **${user.tag}**\n› Reason: ${p.reason || 'No reason provided'}`);
        }
    }),

    makeCommand({
        name: 'unban',
        description: 'Unban a user from the server',
        perms: [P.BanMembers],
        botPerms: [P.BanMembers],
        options: [{ name: 'userid', type: 'string', description: 'The ID of the user to unban', required: true }],
        async run(ctx, p) {
            const id = idFrom(p.userid) || p.userid.replace(/\D/g, '');
            if (!/^\d{15,22}$/.test(id)) throw new UserError('Please provide a valid user ID.');
            const ban = await ctx.guild.bans.fetch(id).catch(() => null);
            if (!ban) throw new UserError('That user is not banned.');
            await ctx.guild.bans.remove(id, `Unbanned by ${ctx.member.user.tag}`);
            await sendTemp(ctx, 'success', `✅ Unbanned **${ban.user.tag}** (${id})`);
        }
    }),

    makeCommand({
        name: 'unbanall',
        description: 'Unban all users from the server',
        perms: [P.Administrator],
        botPerms: [P.BanMembers],
        async run(ctx) {
            await ctx.defer();
            const bans = await ctx.guild.bans.fetch();
            if (bans.size === 0) throw new UserError('There are no banned users.');
            let done = 0;
            for (const ban of bans.values()) {
                try { await ctx.guild.bans.remove(ban.user.id, `Mass unban by ${ctx.member.user.tag}`); done++; } catch (e) { /* skip */ }
            }
            await ctx.success(`✅ Unbanned **${done}/${bans.size}** user(s).`);
        }
    }),

    makeCommand({
        name: 'kick',
        description: 'Kick a member from the server',
        perms: [P.KickMembers],
        botPerms: [P.KickMembers],
        options: [
            { name: 'target', type: 'user', description: 'The member to kick', required: true },
            { name: 'reason', type: 'rest', description: 'The reason for kicking' }
        ],
        async run(ctx, p) {
            const { user, member } = p.target;
            if (!member) throw new UserError('That user is not in this server.');
            ctx.checkTarget(member, 'kick');
            await member.kick(reasonOf(p.reason, ctx));
            await sendTemp(ctx, 'success', `👢 Kicked **${user.tag}**\n› Reason: ${p.reason || 'No reason provided'}`);
        }
    }),

    makeCommand({
        name: 'mute',
        description: 'Mute (timeout) a member',
        perms: [P.ModerateMembers],
        botPerms: [P.ModerateMembers],
        options: [
            { name: 'target', type: 'user', description: 'The member to mute', required: true },
            { name: 'duration', type: 'duration', description: 'e.g. 10m, 2h, 1d (default/max 28d)' },
            { name: 'reason', type: 'rest', description: 'The reason for muting' }
        ],
        async run(ctx, p) {
            const { user, member } = p.target;
            if (!member) throw new UserError('That user is not in this server.');
            ctx.checkTarget(member, 'mute');
            if (member.permissions.has(P.Administrator) && !ctx.isPrivileged()) throw new UserError('You cannot mute an administrator.');
            const ms = Math.min(p.duration ? p.duration.ms : MAX_TIMEOUT_MS, MAX_TIMEOUT_MS);
            if (!member.moderatable) throw new UserError('I cannot mute that member (administrator or higher role).');
            await member.timeout(ms, reasonOf(p.reason, ctx));
            await sendTemp(ctx, 'success', `🔇 Muted **${user.tag}** for **${formatDuration(ms)}**\n› Reason: ${p.reason || 'No reason provided'}`);
        }
    }),

    makeCommand({
        name: 'unmute',
        description: 'Unmute (remove timeout from) a member',
        perms: [P.ModerateMembers],
        botPerms: [P.ModerateMembers],
        options: [{ name: 'target', type: 'user', description: 'The member to unmute', required: true }],
        async run(ctx, p) {
            const { user, member } = p.target;
            if (!member) throw new UserError('That user is not in this server.');
            if (!member.isCommunicationDisabled()) throw new UserError('That member is not muted.');
            await member.timeout(null, `Unmuted by ${ctx.member.user.tag}`);
            await sendTemp(ctx, 'success', `🔊 Unmuted **${user.tag}**`);
        }
    }),

    makeCommand({
        name: 'nick',
        description: "Change a member's nickname (leave empty to reset)",
        perms: [P.ManageNicknames],
        botPerms: [P.ManageNicknames],
        options: [
            { name: 'target', type: 'user', description: 'The member', required: true },
            { name: 'nickname', type: 'rest', description: 'New nickname (empty to reset)' }
        ],
        async run(ctx, p) {
            const { user, member } = p.target;
            if (!member) throw new UserError('That user is not in this server.');
            if (member.id !== ctx.member.id) ctx.checkTarget(member, 'change the nickname of');
            if (p.nickname && p.nickname.length > 32) throw new UserError('Nicknames can be at most 32 characters.');
            if (!member.manageable) throw new UserError('I cannot change that member\'s nickname.');
            await member.setNickname(p.nickname || null, `Changed by ${ctx.member.user.tag}`);
            await sendTemp(ctx, 'success', p.nickname ? `✏️ Changed **${user.tag}**'s nickname to **${p.nickname}**` : `✏️ Reset **${user.tag}**'s nickname`);
        }
    }),

    // ------------------------------------------------------------ channels
    makeCommand({
        name: 'nuke',
        description: 'Nuke a channel (clone it and delete the old one)',
        perms: [P.ManageChannels],
        botPerms: [P.ManageChannels],
        options: [optChannel],
        async run(ctx, p) {
            const channel = p.channel || ctx.channel;
            if (!channel.clone) throw new UserError('That channel cannot be nuked.');
            const position = channel.position;
            const wasCurrent = channel.id === ctx.channel.id;
            if (ctx.isSlash && wasCurrent) await ctx.success('💥 Nuking channel...');
            const fresh = await channel.clone({ reason: `Nuked by ${ctx.member.user.tag}` });
            await channel.delete(`Nuked by ${ctx.member.user.tag}`);
            await fresh.setPosition(position).catch(() => {});
            if (fresh.isTextBased()) await fresh.send({ embeds: [new EmbedBuilder().setColor('#43b581').setDescription(`💥 Channel nuked by ${ctx.member.user}`)] }).catch(() => {});
            if (!wasCurrent) await sendTemp(ctx, 'success', `💥 Nuked **#${channel.name}** -> ${fresh}`);
        }
    }),

    makeCommand({
        name: 'clone',
        description: 'Clone a channel',
        perms: [P.ManageChannels],
        botPerms: [P.ManageChannels],
        options: [optChannel],
        async run(ctx, p) {
            const channel = p.channel || ctx.channel;
            if (!channel.clone) throw new UserError('That channel cannot be cloned.');
            const cloned = await channel.clone({ reason: `Cloned by ${ctx.member.user.tag}` });
            await sendTemp(ctx, 'success', `📋 Cloned channel: ${cloned}`);
        }
    }),
    ...SINGLE_TOGGLES,
    ...ALL_TOGGLES,

    makeCommand({
        name: 'slowmode',
        description: 'Set slowmode for a channel',
        perms: [P.ManageChannels],
        botPerms: [P.ManageChannels],
        options: [
            { name: 'seconds', type: 'integer', description: 'Seconds between messages (0-21600)', required: true, min: 0, max: 21600 },
            optChannel
        ],
        async run(ctx, p) {
            if (p.seconds < 0 || p.seconds > 21600) throw new UserError('Please provide a number between 0 and 21600 seconds.');
            const channel = p.channel || ctx.channel;
            if (!channel.setRateLimitPerUser) throw new UserError('Slowmode is not available for that channel.');
            await channel.setRateLimitPerUser(p.seconds, `Slowmode by ${ctx.member.user.tag}`);
            await sendTemp(ctx, 'success', p.seconds ? `⏱️ Set slowmode in ${channel} to **${p.seconds}s**` : `⏱️ Disabled slowmode in ${channel}`);
        }
    }),

    makeCommand({
        name: 'unslowmode',
        description: 'Disable slowmode for a channel',
        perms: [P.ManageChannels],
        botPerms: [P.ManageChannels],
        options: [optChannel],
        async run(ctx, p) {
            const channel = p.channel || ctx.channel;
            if (!channel.setRateLimitPerUser) throw new UserError('Slowmode is not available for that channel.');
            await channel.setRateLimitPerUser(0, `Slowmode disabled by ${ctx.member.user.tag}`);
            await sendTemp(ctx, 'success', `⏱️ Disabled slowmode in ${channel}`);
        }
    }),

    makeCommand({
        name: 'channel',
        description: 'Channel management commands',
        perms: [P.ManageChannels],
        botPerms: [P.ManageChannels],
        subs: {
            create: {
                description: 'Create a new text channel',
                options: [{ name: 'name', type: 'rest', description: 'Channel name', required: true }],
                async run(ctx, p) {
                    const ch = await ctx.guild.channels.create({ name: p.name, type: ChannelType.GuildText, reason: `Created by ${ctx.member.user.tag}` });
                    await sendTemp(ctx, 'success', `✅ Created channel: ${ch}`);
                }
            },
            rename: {
                description: 'Rename the current channel',
                options: [{ name: 'name', type: 'rest', description: 'New name', required: true }],
                async run(ctx, p) {
                    await ctx.channel.setName(p.name, `Renamed by ${ctx.member.user.tag}`);
                    await sendTemp(ctx, 'success', `✅ Renamed channel to **${p.name}**`);
                }
            },
            delete: {
                description: 'Delete the current channel',
                async run(ctx) {
                    const ch = ctx.channel;
                    await ctx.warn('🗑️ This channel will be deleted in 3 seconds...');
                    setTimeout(() => ch.delete(`Deleted by ${ctx.member.user.tag}`).catch(() => {}), 3000);
                }
            },
            deleteafter: {
                description: 'Delete the current channel after some seconds',
                options: [{ name: 'time', type: 'integer', description: 'Time in seconds', required: true, min: 1 }],
                async run(ctx, p) {
                    if (p.time < 1) throw new UserError('Please provide a valid number of seconds.');
                    const ch = ctx.channel;
                    await ctx.warn(`⏱️ This channel will be deleted in **${p.time}** second(s)...`);
                    setTimeout(() => ch.delete(`Scheduled delete by ${ctx.member.user.tag}`).catch(() => {}), p.time * 1000);
                }
            },
            transfer: {
                description: 'Move the current channel to another category',
                options: [{ name: 'category', type: 'channel', description: 'Target category', required: true }],
                async run(ctx, p) {
                    if (p.category.type !== ChannelType.GuildCategory) throw new UserError('Please choose a **category** channel.');
                    if (!ctx.channel.setParent) throw new UserError('This channel cannot be moved.');
                    await ctx.channel.setParent(p.category.id, { lockPermissions: false, reason: `Moved by ${ctx.member.user.tag}` });
                    await sendTemp(ctx, 'success', `✅ Moved ${ctx.channel} to **${p.category.name}**`);
                }
            }
        }
    }),

    // ------------------------------------------------------------ expressions
    makeCommand({
        name: 'enlarge',
        description: 'Enlarge a custom emoji',
        options: [{ name: 'emoji', type: 'string', description: 'The custom emoji', required: true }],
        async run(ctx, p) {
            const e = parseEmojis(p.emoji)[0];
            if (!e) throw new UserError('Please provide a custom server emoji (unicode emojis are not supported).');
            const embed = new EmbedBuilder().setColor('#2b2d31').setTitle(`:${e.name}:`).setImage(emojiUrl(e.id, e.animated));
            await ctx.send({ embeds: [embed] });
        }
    }),

    makeCommand({
        name: 'deleteemoji',
        description: 'Delete an emoji from the server',
        perms: [P.ManageGuildExpressions],
        botPerms: [P.ManageGuildExpressions],
        options: [{ name: 'emoji', type: 'string', description: 'The emoji (or its ID / name)', required: true }],
        async run(ctx, p) {
            const parsed = parseEmojis(p.emoji)[0];
            const key = parsed ? parsed.id : p.emoji.replace(/:/g, '');
            const emojis = await ctx.guild.emojis.fetch();
            const emoji = emojis.get(key) || emojis.find(e => e.name.toLowerCase() === key.toLowerCase());
            if (!emoji) throw new UserError('That emoji does not belong to this server.');
            const name = emoji.name;
            await emoji.delete(`Deleted by ${ctx.member.user.tag}`);
            await sendTemp(ctx, 'success', `🗑️ Deleted emoji **${name}**`);
        }
    }),

    makeCommand({
        name: 'deletesticker',
        description: 'Delete a sticker from the server',
        perms: [P.ManageGuildExpressions],
        botPerms: [P.ManageGuildExpressions],
        options: [{ name: 'sticker', type: 'string', description: 'Sticker ID or name (prefix: or send the sticker with the command)' }],
        async run(ctx, p) {
            const stickers = await ctx.guild.stickers.fetch();
            let sticker = null;
            if (ctx.message && ctx.message.stickers.size) sticker = stickers.get(ctx.message.stickers.first().id);
            if (!sticker && p.sticker) sticker = stickers.get(p.sticker) || stickers.find(s => s.name.toLowerCase() === p.sticker.toLowerCase());
            if (!sticker) throw new UserError('Provide the ID/name of one of this server\'s stickers (or send the sticker with the command).');
            const name = sticker.name;
            await sticker.delete(`Deleted by ${ctx.member.user.tag}`);
            await sendTemp(ctx, 'success', `🗑️ Deleted sticker **${name}**`);
        }
    }),

    makeCommand({
        name: 'steal',
        description: 'Add emoji(s) or an image URL to this server as emoji',
        perms: [P.ManageGuildExpressions],
        botPerms: [P.ManageGuildExpressions],
        options: [
            { name: 'emoji', type: 'rest', description: 'Custom emoji(s) or an image URL', required: false },
            { name: 'name', type: 'string', description: 'Name when using an image URL' }
        ],
        async run(ctx, p) {
            await ctx.defer();
            const added = [];
            const failed = [];
            const text = p.emoji || '';

            // Stickers attached to the invoking message (prefix) -> add as stickers
            if (ctx.message && ctx.message.stickers.size) {
                for (const st of ctx.message.stickers.values()) {
                    try {
                        const created = await ctx.guild.stickers.create({ file: st.url, name: st.name, tags: st.tags || st.name, reason: `Stolen by ${ctx.member.user.tag}` });
                        added.push(`sticker **${created.name}**`);
                    } catch (e) { failed.push(`sticker ${st.name} (${e.message})`); }
                }
            }

            const urlMatch = text.match(/https?:\/\/\S+\.(?:png|jpe?g|gif|webp)(?:\?\S*)?/i);
            const targets = parseEmojis(text);
            if (urlMatch) {
                const raw = text.replace(urlMatch[0], '').trim().split(/\s+/)[0] || p.name || 'stolen_emoji';
                targets.push({ url: urlMatch[0], name: (p.name || raw).replace(/\W/g, '_').slice(0, 32).padEnd(2, '_') });
            }
            if (!targets.length && !added.length) throw new UserError('Provide custom emoji(s), an image URL, or send a sticker with the command.');

            for (const t of targets) {
                try {
                    const created = await ctx.guild.emojis.create({ attachment: t.url || emojiUrl(t.id, t.animated), name: t.name, reason: `Stolen by ${ctx.member.user.tag}` });
                    added.push(`${created}`);
                } catch (e) { failed.push(`${t.name} (${e.message})`); }
            }
            const lines = [];
            if (added.length) lines.push(`✅ Added: ${added.join(' ')}`);
            if (failed.length) lines.push(`❌ Failed: ${failed.join(', ')}`);
            await (added.length ? ctx.success(lines.join('\n')) : ctx.error(lines.join('\n')));
        }
    }),

    makeCommand({
        name: 'snipe',
        description: 'Show the last deleted message in this channel',
        perms: [P.ManageMessages],
        async run(ctx) {
            const entry = snipeStore.get(ctx.channel.id);
            if (!entry) throw new UserError('There is nothing to snipe here (or it was deleted more than 10 minutes ago).');
            const embed = new EmbedBuilder()
                .setColor('#2b2d31')
                .setAuthor({ name: entry.authorTag, iconURL: entry.authorAvatar || undefined })
                .setDescription(entry.content || '*No text content*')
                .setFooter({ text: `Deleted ${formatDuration(Date.now() - entry.deletedAt)} ago` });
            if (entry.attachments.length) embed.addFields({ name: 'Attachments', value: entry.attachments.slice(0, 5).join('\n') });
            await ctx.send({ embeds: [embed] });
        }
    })
];
