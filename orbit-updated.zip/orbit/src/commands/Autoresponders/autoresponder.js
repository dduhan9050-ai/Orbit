const { SlashCommandBuilder } = require('discord.js');
const triggerModule = require('../../functions/triggerModule');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('autoresponder')
        .setDescription('Configure auto-responders for the server')
        .addSubcommand(sub => sub.setName('add').setDescription('Add an auto-responder').addStringOption(opt => opt.setName('trigger').setDescription('The trigger phrase').setRequired(true)).addStringOption(opt => opt.setName('response').setDescription('The response message').setRequired(true)))
        .addSubcommand(sub => sub.setName('edit').setDescription('Edit an auto-responder').addStringOption(opt => opt.setName('trigger').setDescription('The trigger phrase').setRequired(true)).addStringOption(opt => opt.setName('response').setDescription('The new response').setRequired(true)))
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove an auto-responder').addStringOption(opt => opt.setName('trigger').setDescription('The trigger phrase').setRequired(true)))
        .addSubcommand(sub => sub.setName('toggle').setDescription('Toggle an auto-responder').addStringOption(opt => opt.setName('trigger').setDescription('The trigger phrase').setRequired(true)))
        .addSubcommand(sub => sub.setName('show').setDescription('Show all auto-responders'))
        .addSubcommand(sub => sub.setName('enable').setDescription('Enable auto-responder module'))
        .addSubcommand(sub => sub.setName('disable').setDescription('Disable auto-responder module'))
        .addSubcommandGroup(group => group.setName('ignore').setDescription('Manage auto-responder ignore list')
            .addSubcommand(sub => sub.setName('add').setDescription('Add to ignore list').addUserOption(opt => opt.setName('user').setDescription('User')).addChannelOption(opt => opt.setName('channel').setDescription('Channel')))
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove from ignore list').addUserOption(opt => opt.setName('user').setDescription('User')).addChannelOption(opt => opt.setName('channel').setDescription('Channel')))
            .addSubcommand(sub => sub.setName('reset').setDescription('Reset ignore list'))
            .addSubcommand(sub => sub.setName('show').setDescription('Show ignore list'))),
    ...triggerModule.create('autoresponder'),
};
