const { SlashCommandBuilder } = require('discord.js');
const triggerModule = require('../../functions/triggerModule');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('autoreact')
        .setDescription('Configure auto-reactions for the server')
        .addSubcommand(sub => sub.setName('add').setDescription('Add an auto-reaction').addStringOption(opt => opt.setName('trigger').setDescription('The trigger phrase').setRequired(true)).addStringOption(opt => opt.setName('emoji').setDescription('The emoji').setRequired(true)))
        .addSubcommand(sub => sub.setName('edit').setDescription('Edit an auto-reaction').addStringOption(opt => opt.setName('trigger').setDescription('The trigger phrase').setRequired(true)).addStringOption(opt => opt.setName('emoji').setDescription('The new emoji').setRequired(true)))
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove an auto-reaction').addStringOption(opt => opt.setName('trigger').setDescription('The trigger phrase').setRequired(true)))
        .addSubcommand(sub => sub.setName('toggle').setDescription('Toggle an auto-reaction').addStringOption(opt => opt.setName('trigger').setDescription('The trigger phrase').setRequired(true)))
        .addSubcommand(sub => sub.setName('show').setDescription('Show all auto-reactions'))
        .addSubcommand(sub => sub.setName('enable').setDescription('Enable autoreact module'))
        .addSubcommand(sub => sub.setName('disable').setDescription('Disable autoreact module'))
        .addSubcommandGroup(group => group.setName('ignore').setDescription('Manage autoreact ignore list')
            .addSubcommand(sub => sub.setName('add').setDescription('Add to ignore list').addUserOption(opt => opt.setName('user').setDescription('User')).addChannelOption(opt => opt.setName('channel').setDescription('Channel')))
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove from ignore list').addUserOption(opt => opt.setName('user').setDescription('User')).addChannelOption(opt => opt.setName('channel').setDescription('Channel')))
            .addSubcommand(sub => sub.setName('reset').setDescription('Reset ignore list'))
            .addSubcommand(sub => sub.setName('show').setDescription('Show ignore list'))),
    ...triggerModule.create('autoreact'),
};
