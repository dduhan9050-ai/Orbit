const { SlashCommandBuilder, EmbedBuilder, MessageFlags, PermissionFlagsBits } = require('discord.js');
const common = require('../../functions/automationCommon');
const store = require('../../functions/automationStore');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('media')
        .setDescription('Media channel management and bypass')
        .addSubcommand(sub => sub.setName('show').setDescription('Show current media channels'))
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove a media channel').addChannelOption(opt => opt.setName('channel').setDescription('The channel to remove').setRequired(true)))
        .addSubcommand(sub => sub.setName('add').setDescription('Add a media channel').addChannelOption(opt => opt.setName('channel').setDescription('The channel to add').setRequired(true)))
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset all media channels'))
        .addSubcommandGroup(group => group.setName('bypass').setDescription('Manage media bypass')
            .addSubcommand(sub => sub.setName('show').setDescription('Show bypass users/roles'))
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove bypass').addUserOption(opt => opt.setName('user').setDescription('User')).addRoleOption(opt => opt.setName('role').setDescription('Role')))
            .addSubcommand(sub => sub.setName('add').setDescription('Add bypass').addUserOption(opt => opt.setName('user').setDescription('User')).addRoleOption(opt => opt.setName('role').setDescription('Role')))
            .addSubcommand(sub => sub.setName('reset').setDescription('Reset all bypass settings'))),
    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
            return interaction.reply({ content: '❌ No access', flags: MessageFlags.Ephemeral });
        }
        const user = interaction.options.getUser('user');
        const role = interaction.options.getRole('role');
        await run(common.fromInteraction(interaction), interaction.options.getSubcommandGroup(false), interaction.options.getSubcommand(), {
            channel: interaction.options.getChannel('channel'),
            targets: [user && { type: 'user', id: user.id }, role && { type: 'role', id: role.id }].filter(Boolean),
        });
    },

    async executeMessage(message, args) {
        const first = args[0] ? args[0].toLowerCase() : 'help';
        const second = args[1] ? args[1].toLowerCase() : null;

        if (first === 'help' || !['add', 'remove', 'show', 'reset', 'bypass'].includes(first)) {
            return message.reply({ embeds: [common.helpEmbed(MAIN_HELP, message)] });
        }
        if (first === 'bypass' && !['add', 'remove', 'show', 'reset'].includes(second)) {
            return message.reply({ embeds: [common.helpEmbed(BYPASS_HELP, message)] });
        }
        const ctx = common.fromMessage(message);
        if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) return ctx.fail('No access');

        if (first === 'bypass') {
            const targets = [];
            if (second === 'add' || second === 'remove') {
                const t = await common.resolveAny(message.guild, args[2]);
                if (!t || (t.type !== 'user' && t.type !== 'role')) {
                    return ctx.fail(`Please mention a user or role. Usage: \`media bypass ${second} @user/@role\``);
                }
                targets.push(t);
            }
            return run(ctx, 'bypass', second, { targets });
        }

        const channel = args[1] ? common.resolveChannel(message.guild, args[1]) : null;
        if ((first === 'add' || first === 'remove') && !channel) {
            return ctx.fail(`Please mention a channel. Usage: \`media ${first} #channel\``);
        }
        return run(ctx, null, first, { channel });
    },
};

const MAIN_HELP =
    `» **media add #channel**\n› Make a channel media-only (text-only messages get deleted).\n\n` +
    `» **media remove #channel**\n› Remove a media-only channel.\n\n` +
    `» **media show**\n› Show media channels.\n\n` +
    `» **media reset**\n› Reset all media channels.\n\n` +
    `» **media bypass**\n› Manage bypass settings.`;

const BYPASS_HELP =
    `» **media bypass add @user/@role**\n› Add bypass for user/role.\n\n` +
    `» **media bypass remove @user/@role**\n› Remove bypass.\n\n` +
    `» **media bypass show**\n› Show all bypasses.\n\n` +
    `» **media bypass reset**\n› Reset all bypasses.`;

async function run(ctx, group, sub, o) {
    const cfg = store.get('media', ctx.guild.id);
    const save = () => store.save('media');

    if (group === 'bypass') {
        switch (sub) {
            case 'add': {
                const t = o.targets[0];
                if (!t) return ctx.fail('Please provide a user or role.');
                const key = t.type === 'role' ? 'bypassRoles' : 'bypassUsers';
                if (cfg[key].includes(t.id)) return ctx.fail(`That ${t.type} already has bypass.`);
                cfg[key].push(t.id);
                save();
                return ctx.ok(`Added ${t.type === 'role' ? `<@&${t.id}>` : `<@${t.id}>`} to media bypass.`);
            }
            case 'remove': {
                if (!o.targets.length) return ctx.fail('Please provide a user or role.');
                for (const t of o.targets) {
                    const key = t.type === 'role' ? 'bypassRoles' : 'bypassUsers';
                    cfg[key] = cfg[key].filter(id => id !== t.id);
                }
                save();
                return ctx.ok('Removed from media bypass.');
            }
            case 'show':
                return ctx.send({ embeds: [new EmbedBuilder()
                    .setTitle('Media Bypass')
                    .addFields(
                        { name: 'Users', value: common.truncate(cfg.bypassUsers.map(id => `<@${id}>`).join(', ') || 'None', 1024) },
                        { name: 'Roles', value: common.truncate(cfg.bypassRoles.map(id => `<@&${id}>`).join(', ') || 'None', 1024) }
                    )
                    .setColor('#2b2d31')] });
            case 'reset':
                cfg.bypassUsers = [];
                cfg.bypassRoles = [];
                save();
                return ctx.ok('Reset all media bypasses.');
            default:
                return ctx.fail('Unknown subcommand.');
        }
    }

    switch (sub) {
        case 'add': {
            const channel = o.channel;
            if (!common.isTextChannel(channel)) return ctx.fail('Please choose a text channel.');
            if (cfg.channels.includes(channel.id)) return ctx.fail('This channel is already a media channel.');
            cfg.channels.push(channel.id);
            save();
            const me = ctx.guild.members.me;
            const canDelete = me && channel.permissionsFor(me)?.has('ManageMessages');
            return ctx.ok(`Added ${channel} as a media-only channel.${canDelete ? '' : ' ⚠️ I am missing the Manage Messages permission there, so I cannot remove text messages yet.'}`);
        }
        case 'remove': {
            if (!o.channel || !cfg.channels.includes(o.channel.id)) return ctx.fail('That channel is not a media channel.');
            cfg.channels = cfg.channels.filter(id => id !== o.channel.id);
            save();
            return ctx.ok(`Removed ${o.channel} from the media-only list.`);
        }
        case 'show':
            return ctx.send({ embeds: [new EmbedBuilder()
                .setTitle('Media-Only Channels')
                .setDescription(common.truncate(cfg.channels.map(id => `<#${id}>`).join(', ') || 'None', 4000))
                .setColor('#2b2d31')] });
        case 'reset':
            cfg.channels = [];
            save();
            return ctx.ok('Reset all media channels.');
        default:
            return ctx.fail('Unknown subcommand.');
    }
}
