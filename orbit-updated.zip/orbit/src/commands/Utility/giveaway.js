const { SlashCommandBuilder, EmbedBuilder, MessageFlags, PermissionFlagsBits } = require('discord.js');
const common = require('../../functions/automationCommon');
const giveaways = require('../../functions/giveawayManager');

const NO_ACCESS = '❌ No access';
const canManage = (member) => member.permissions.has(PermissionFlagsBits.ManageGuild);

/** Shared "create" logic for slash + prefix. */
async function createGiveaway(ctx, durationText, winners, prize) {
    const ms = common.parseDuration(durationText);
    if (!ms) return ctx.fail('Invalid duration format. Use s (seconds), m (minutes), h (hours), d (days). Example: `1d`, `12h`, `1h30m`.');
    if (ms < 10 * 1000 || ms > 30 * 24 * 60 * 60 * 1000) return ctx.fail('Duration must be between 10 seconds and 30 days.');
    if (!Number.isInteger(winners) || winners < 1 || winners > 20) return ctx.fail('Winners must be a number between 1 and 20.');
    if (!prize || !prize.trim()) return ctx.fail('Please provide a prize.');
    try {
        await giveaways.create(ctx.channel, ctx.user.id, ms, durationText, winners, prize.trim());
    } catch (e) {
        return ctx.fail(`I couldn't start the giveaway here: ${e.message}`);
    }
    if (ctx.isSlash) return ctx.ok('Giveaway started!');
}

async function endGiveaway(ctx, messageId) {
    const res = await giveaways.end(ctx.client, ctx.guild.id, messageId);
    return res.ok ? ctx.ok('Giveaway ended!') : ctx.fail(res.error);
}

async function rerollGiveaway(ctx, messageId) {
    const res = await giveaways.reroll(ctx.client, ctx.guild.id, messageId);
    return res.ok ? ctx.ok('Giveaway rerolled!') : ctx.fail(res.error);
}

async function deleteGiveaway(ctx, messageId) {
    const res = await giveaways.remove(ctx.client, ctx.guild.id, messageId);
    return res.ok ? ctx.ok('Giveaway deleted!') : ctx.fail(res.error);
}

async function listGiveaways(ctx) {
    const active = giveaways.listActive(ctx.guild.id)
        .map(([id, g]) => `**Prize:** ${g.prize}\n**Channel:** <#${g.channelId}>\n**Ends:** <t:${Math.floor(g.endTime / 1000)}:R>\n**ID:** ${id}`);
    return ctx.send({ embeds: [new EmbedBuilder()
        .setTitle('Active Giveaways')
        .setDescription(common.truncate(active.length ? active.join('\n\n') : 'No active giveaways.', 4000))
        .setColor('#2b2d31')] });
}

/** Builds a command that takes a single <messageid>. */
function messageIdCommand(name, description, usage, handler) {
    return {
        data: new SlashCommandBuilder()
            .setName(name)
            .setDescription(description)
            .addStringOption(opt => opt.setName('messageid').setDescription('The ID of the giveaway message').setRequired(true)),
        async execute(interaction) {
            if (!canManage(interaction.member)) return interaction.reply({ content: NO_ACCESS, flags: MessageFlags.Ephemeral });
            await interaction.deferReply();
            await handler(common.fromInteraction(interaction), interaction.options.getString('messageid').trim());
        },
        async executeMessage(message, args) {
            const ctx = common.fromMessage(message);
            if (!canManage(message.member)) return ctx.fail('No access');
            if (!args[0]) return ctx.fail(`Please provide the giveaway message ID. Usage: \`${usage}\``);
            await handler(ctx, args[0]);
        },
    };
}

module.exports = [
    {
        data: new SlashCommandBuilder()
            .setName('gcreate')
            .setDescription('Create a giveaway')
            .addStringOption(opt => opt.setName('duration').setDescription('Duration (e.g. 1h, 1d)').setRequired(true))
            .addIntegerOption(opt => opt.setName('winners').setDescription('Number of winners').setRequired(true))
            .addStringOption(opt => opt.setName('prize').setDescription('Giveaway prize').setRequired(true)),
        async execute(interaction) {
            if (!canManage(interaction.member)) return interaction.reply({ content: NO_ACCESS, flags: MessageFlags.Ephemeral });
            // Reply privately first so the giveaway embed itself is the only public message
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });
            await createGiveaway(
                common.fromInteraction(interaction),
                interaction.options.getString('duration'),
                interaction.options.getInteger('winners'),
                interaction.options.getString('prize')
            );
        },
        async executeMessage(message, args) {
            const ctx = common.fromMessage(message);
            if (!canManage(message.member)) return ctx.fail('No access');
            if (args.length < 3) return ctx.fail('Usage: `!gcreate <duration> <winners> <prize>`\nExample: `!gcreate 1d 1 Discord Nitro`');
            if (!/^\d+$/.test(args[1])) return ctx.fail('Winners must be a valid number (1 or more).');
            await createGiveaway(ctx, args[0], parseInt(args[1], 10), args.slice(2).join(' '));
        },
    },
    messageIdCommand('gend', 'End a giveaway', '!gend <messageid>', endGiveaway),
    messageIdCommand('greroll', 'Reroll a giveaway', '!greroll <messageid>', rerollGiveaway),
    {
        data: new SlashCommandBuilder()
            .setName('glist')
            .setDescription('List all active giveaways'),
        async execute(interaction) {
            await listGiveaways(common.fromInteraction(interaction));
        },
        async executeMessage(message) {
            await listGiveaways(common.fromMessage(message));
        },
    },
    messageIdCommand('gdelete', 'Delete a giveaway', '!gdelete <messageid>', deleteGiveaway),
];
