const { SlashCommandBuilder, EmbedBuilder, MessageFlags, PermissionFlagsBits } = require('discord.js');
const common = require('../../functions/automationCommon');
const store = require('../../functions/automationStore');
const runtime = require('../../functions/automationRuntime');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('sticky')
        .setDescription('Sticky message management')
        .addSubcommand(sub => sub.setName('add').setDescription('Add a sticky message').addStringOption(opt => opt.setName('message').setDescription('The message').setRequired(true)).addChannelOption(opt => opt.setName('channel').setDescription('Target channel')))
        .addSubcommand(sub => sub.setName('reset').setDescription('Reset sticky messages in current or specified channel').addChannelOption(opt => opt.setName('channel').setDescription('Channel')))
        .addSubcommand(sub => sub.setName('bump').setDescription('Bump sticky message').addChannelOption(opt => opt.setName('channel').setDescription('Channel')))
        .addSubcommand(sub => sub.setName('remove').setDescription('Remove sticky message').addChannelOption(opt => opt.setName('channel').setDescription('Channel')))
        .addSubcommand(sub => sub.setName('show').setDescription('Show sticky message details').addChannelOption(opt => opt.setName('channel').setDescription('Channel')))
        .addSubcommandGroup(group => group.setName('channel').setDescription('Manage sticky message channels')
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove a channel from sticky list').addChannelOption(opt => opt.setName('channel').setDescription('Channel').setRequired(true)))
            .addSubcommand(sub => sub.setName('add').setDescription('Add a channel to sticky list').addChannelOption(opt => opt.setName('channel').setDescription('Channel').setRequired(true)))),
    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
            return interaction.reply({ content: '❌ No access', flags: MessageFlags.Ephemeral });
        }
        await interaction.deferReply();
        await run(common.fromInteraction(interaction), interaction.options.getSubcommandGroup(false), interaction.options.getSubcommand(), {
            message: interaction.options.getString('message'),
            channel: interaction.options.getChannel('channel'),
        });
    },

    async executeMessage(message, args) {
        const first = args[0] ? args[0].toLowerCase() : 'help';
        if (first === 'help' || !['add', 'remove', 'show', 'bump', 'reset', 'channel'].includes(first)) {
            return message.reply({ embeds: [common.helpEmbed(HELP, message)] });
        }
        const ctx = common.fromMessage(message);
        if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) return ctx.fail('No access');

        if (first === 'channel') {
            const sub = args[1] ? args[1].toLowerCase() : null;
            const channel = args[2] ? common.resolveChannel(message.guild, args[2]) : null;
            if (!['add', 'remove'].includes(sub) || !channel) return ctx.fail('Usage: `sticky channel <add/remove> #channel`');
            return run(ctx, 'channel', sub, { channel });
        }

        const channelArg = args.slice(1).find(a => /^<#\d+>$/.test(a));
        const channel = channelArg ? common.resolveChannel(message.guild, channelArg) : null;
        if (channelArg && !channel) return ctx.fail('Invalid channel provided.');
        const text = args.slice(1).filter(a => a !== channelArg).join(' ');
        return run(ctx, null, first, { message: text, channel });
    },
};

const HELP =
    `» **sticky add <message> [#channel]**\n› Add a sticky message (it stays at the bottom of the channel).\n\n` +
    `» **sticky remove [#channel]**\n› Remove the sticky message.\n\n` +
    `» **sticky show [#channel]**\n› Show sticky message details.\n\n` +
    `» **sticky bump [#channel]**\n› Re-post the sticky message now.\n\n` +
    `» **sticky reset [#channel]**\n› Remove sticky messages (every channel if none is given).\n\n` +
    `» **sticky channel add #channel**\n› Copy this channel's sticky message to another channel.\n\n` +
    `» **sticky channel remove #channel**\n› Remove a channel from the sticky list.`;

async function deleteOld(channel, cfg) {
    if (!cfg || !cfg.lastMessageId) return;
    const old = await channel.messages.fetch(cfg.lastMessageId).catch(() => null);
    if (old) await old.delete().catch(() => {});
}

async function run(ctx, group, sub, o) {
    const cfg = store.get('sticky', ctx.guild.id);
    const target = o.channel || ctx.channel;

    // "sticky channel add/remove"
    if (group === 'channel') {
        if (!common.isTextChannel(o.channel)) return ctx.fail('Please choose a text channel.');
        if (sub === 'remove') {
            if (!cfg[o.channel.id]) return ctx.fail(`No sticky message found in ${o.channel}`);
            await deleteOld(o.channel, cfg[o.channel.id]);
            delete cfg[o.channel.id];
            store.save('sticky');
            return ctx.ok(`Removed ${o.channel} from the sticky list.`);
        }
        const source = cfg[ctx.channel.id];
        if (!source) return ctx.fail('There is no sticky message in this channel to copy. Use `sticky add <message> [#channel]` instead.');
        cfg[o.channel.id] = { message: source.message, lastMessageId: null };
        store.save('sticky');
        try {
            await runtime.repostSticky(o.channel);
        } catch (e) {
            delete cfg[o.channel.id];
            store.save('sticky');
            return ctx.fail(`I couldn't post in ${o.channel}: ${e.message}`);
        }
        return ctx.ok(`Added ${o.channel} to the sticky list.`);
    }

    switch (sub) {
        case 'add': {
            const text = (o.message || '').trim();
            if (!text) return ctx.fail('Please provide a message. Usage: `sticky add <message> [#channel]`');
            if (text.length > 2000) return ctx.fail('The sticky message can be at most 2000 characters.');
            if (!common.isTextChannel(target)) return ctx.fail('Please choose a text channel.');
            const previous = cfg[target.id];
            if (previous) await deleteOld(target, previous);
            cfg[target.id] = { message: text, lastMessageId: null };
            store.save('sticky');
            try {
                await runtime.repostSticky(target);
            } catch (e) {
                if (previous) cfg[target.id] = previous; else delete cfg[target.id];
                store.save('sticky');
                return ctx.fail(`I couldn't post in ${target}: ${e.message}`);
            }
            return ctx.ok(`Sticky message set for ${target}`);
        }
        case 'remove': {
            if (!cfg[target.id]) return ctx.fail(`No sticky message found in ${target}`);
            await deleteOld(target, cfg[target.id]);
            delete cfg[target.id];
            store.save('sticky');
            return ctx.ok(`Removed sticky message from ${target}`);
        }
        case 'show': {
            const entry = cfg[target.id];
            if (!entry) return ctx.fail(`No sticky message found in ${target}`);
            return ctx.send({ embeds: [new EmbedBuilder()
                .setTitle('Sticky Message Details')
                .setDescription(`**Channel:** ${target}\n**Message:** ${common.truncate(entry.message, 3500)}`)
                .setColor('#2b2d31')] });
        }
        case 'bump': {
            if (!cfg[target.id]) return ctx.fail(`No sticky message found in ${target}`);
            try {
                await runtime.repostSticky(target);
            } catch (e) {
                return ctx.fail(`I couldn't post in ${target}: ${e.message}`);
            }
            return ctx.ok(`Bumped sticky message in ${target}`);
        }
        case 'reset': {
            if (o.channel) {
                if (!cfg[o.channel.id]) return ctx.fail(`No sticky message found in ${o.channel}`);
                await deleteOld(o.channel, cfg[o.channel.id]);
                delete cfg[o.channel.id];
            } else {
                for (const channelId of Object.keys(cfg)) {
                    const channel = ctx.guild.channels.cache.get(channelId);
                    if (channel) await deleteOld(channel, cfg[channelId]);
                    delete cfg[channelId];
                }
            }
            store.save('sticky');
            return ctx.ok('Reset sticky messages.');
        }
        default:
            return ctx.fail('Unknown subcommand.');
    }
}
