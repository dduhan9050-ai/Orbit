const {
    EmbedBuilder, PermissionFlagsBits: P, ChannelType, MessageFlags,
    ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, ChannelSelectMenuBuilder
} = require('discord.js');
const { makeCommand, UserError, idFrom } = require('../../functions/commandKit');
const logs = require('../../functions/loggingManager');

const { LOG_TYPES } = logs;
const TEXT_CHANNELS = [ChannelType.GuildText, ChannelType.GuildAnnouncement];
const VOICE_CHANNELS = [ChannelType.GuildVoice, ChannelType.GuildStageVoice];

const TYPE_INFO = {
    message: 'Message edits & deletions',
    member: 'Joins, leaves & member updates',
    voice: 'Voice joins, leaves, mutes',
    server: 'Channels & roles created/deleted',
    moderation: 'Bans & unbans'
};

const SETUP_PERMS = { perms: [P.Administrator] };

// ------------------------------------------------------------------ helpers
const requireType = (type) => {
    const t = String(type || '').toLowerCase();
    if (t !== 'all' && !LOG_TYPES.includes(t)) {
        throw new UserError(`Unknown log type \`${type}\`. Valid types: ${LOG_TYPES.map(x => `\`${x}\``).join(', ')}, \`all\`.`);
    }
    return t;
};

const requireTextChannel = (ch) => {
    if (!ch || !TEXT_CHANNELS.includes(ch.type)) throw new UserError('Please choose a text channel.');
    return ch;
};

const requireVoiceChannel = (ch) => {
    if (!ch || !VOICE_CHANNELS.includes(ch.type)) throw new UserError('Please choose a voice channel.');
    return ch;
};

/** Add `value` to the guild's ignore list. Returns false if already present. */
function addIgnore(guildId, value) {
    const cfg = logs.get(guildId);
    if (cfg.ignores.includes(value)) return false;
    cfg.ignores.push(value);
    logs.save(guildId, cfg);
    return true;
}

function describeIgnore(guild, entry) {
    if (entry.startsWith('voice_')) return `🎤 <#${entry.slice(6)}> *(voice)*`;
    if (entry.startsWith('embed_')) return `🧾 <#${entry.slice(6)}> *(embeds)*`;
    if (guild.channels.cache.has(entry)) return `💬 <#${entry}>`;
    if (guild.roles.cache.has(entry)) return `🏷️ <@&${entry}>`;
    return `👤 <@${entry}>`;
}

/**
 * Create (or reuse) one locked `<type>-logs` channel per log type inside a "Logs" category.
 * Returns { created, reused } counts and stores the channel ids in the config.
 */
async function autoSetup(guild, executorId) {
    const cfg = logs.get(guild.id);
    const me = guild.members.me;
    const overwrites = [
        { id: guild.id, deny: [P.ViewChannel] },
        { id: me.id, allow: [P.ViewChannel, P.SendMessages, P.EmbedLinks, P.ReadMessageHistory] }
    ];
    for (const id of new Set([guild.ownerId, executorId])) {
        if (id && id !== me.id) overwrites.push({ id, allow: [P.ViewChannel, P.ReadMessageHistory] });
    }

    let category = guild.channels.cache.find(c => c.type === ChannelType.GuildCategory && c.name === '📜 Logs');
    if (!category) {
        category = await guild.channels.create({
            name: '📜 Logs', type: ChannelType.GuildCategory, permissionOverwrites: overwrites, reason: 'Logging auto-setup'
        });
    }

    let created = 0, reused = 0;
    for (const type of LOG_TYPES) {
        const existing = cfg.channels[type] && guild.channels.cache.get(cfg.channels[type]);
        if (existing) { reused++; continue; }
        const channel = await guild.channels.create({
            name: `${type}-logs`, type: ChannelType.GuildText, parent: category.id,
            permissionOverwrites: overwrites, reason: 'Logging auto-setup'
        });
        cfg.channels[type] = channel.id;
        created++;
    }
    cfg.enabled = true;
    logs.save(guild.id, cfg);
    return { created, reused };
}

function statusEmbed(guild) {
    const cfg = logs.get(guild.id);
    const rows = LOG_TYPES.map(t => {
        const id = cfg.channels[t];
        return `**${t}** — ${id ? (guild.channels.cache.has(id) ? `<#${id}>` : `~~<#${id}>~~ *(deleted)*`) : '*not set*'}`;
    });
    const configured = LOG_TYPES.filter(t => cfg.channels[t]).length;
    return new EmbedBuilder()
        .setTitle('📜 Logging Status')
        .setColor('#2b2d31')
        .addFields(
            { name: 'Status', value: cfg.enabled ? '✅ Enabled' : '❌ Disabled', inline: true },
            { name: 'Configured', value: `${configured}/${LOG_TYPES.length}`, inline: true },
            { name: 'Ignored', value: String(cfg.ignores.length), inline: true },
            { name: 'Channels', value: rows.join('\n') }
        );
}

// ------------------------------------------------------------------ wizard
async function wizard(ctx) {
    const guild = ctx.guild;
    const userId = ctx.member.id;
    let pickType = null;

    const render = (finished = false) => {
        const cfg = logs.get(guild.id);
        const embed = statusEmbed(guild).setTitle('🧙 Logging Setup Wizard');
        if (finished) return { embeds: [embed.setFooter({ text: 'Wizard closed.' })], components: [] };

        const components = [];
        if (pickType) {
            embed.setDescription(`Pick the channel for **${pickType}** logs *(${TYPE_INFO[pickType]})*.`);
            components.push(
                new ActionRowBuilder().addComponents(
                    new ChannelSelectMenuBuilder().setCustomId('logging_wiz_chan').setPlaceholder(`Channel for ${pickType} logs`)
                        .setChannelTypes(...TEXT_CHANNELS).setMinValues(1).setMaxValues(1)
                ),
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('logging_wiz_back').setLabel('Back').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId('logging_wiz_unset').setLabel('Unset this type').setStyle(ButtonStyle.Danger)
                        .setDisabled(!cfg.channels[pickType])
                )
            );
        } else {
            embed.setDescription('Choose a log type to set its channel, or let me create everything for you.');
            components.push(
                new ActionRowBuilder().addComponents(
                    new StringSelectMenuBuilder().setCustomId('logging_wiz_type').setPlaceholder('Select a log type to configure')
                        .addOptions(LOG_TYPES.map(t => ({ label: t, value: t, description: TYPE_INFO[t] })))
                ),
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('logging_wiz_toggle').setLabel(cfg.enabled ? 'Disable logging' : 'Enable logging')
                        .setStyle(cfg.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
                    new ButtonBuilder().setCustomId('logging_wiz_auto').setLabel('Auto-create channels').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('logging_wiz_done').setLabel('Finish').setStyle(ButtonStyle.Secondary)
                )
            );
        }
        return { embeds: [embed], components };
    };

    const sent = await ctx.send(render());
    const msg = ctx.isSlash ? await ctx.interaction.fetchReply() : sent;
    if (!msg) return;

    const collector = msg.createMessageComponentCollector({ time: 180000 });
    collector.on('collect', async (i) => {
        try {
            if (i.user.id !== userId) {
                return await i.reply({ content: 'Only the person who started the wizard can use it.', flags: MessageFlags.Ephemeral });
            }
            const cfg = logs.get(guild.id);
            switch (i.customId) {
                case 'logging_wiz_type': pickType = i.values[0]; break;
                case 'logging_wiz_back': pickType = null; break;
                case 'logging_wiz_chan':
                    cfg.channels[pickType] = i.values[0];
                    logs.save(guild.id, cfg);
                    pickType = null;
                    break;
                case 'logging_wiz_unset':
                    delete cfg.channels[pickType];
                    logs.save(guild.id, cfg);
                    pickType = null;
                    break;
                case 'logging_wiz_toggle':
                    cfg.enabled = !cfg.enabled;
                    logs.save(guild.id, cfg);
                    break;
                case 'logging_wiz_auto':
                    await i.deferUpdate();
                    try {
                        const me = guild.members.me;
                        if (!me.permissions.has([P.ManageChannels, P.ManageRoles])) {
                            await i.followUp({ content: 'I need **Manage Channels** and **Manage Roles** to create the channels.', flags: MessageFlags.Ephemeral });
                        } else {
                            await autoSetup(guild, userId);
                        }
                    } catch (e) {
                        console.error('Logging wizard auto-setup error:', e);
                        await i.followUp({ content: '❌ Failed to create the channels. Check my permissions.', flags: MessageFlags.Ephemeral }).catch(() => {});
                    }
                    return await i.editReply(render());
                case 'logging_wiz_done':
                    collector.stop('done');
                    return await i.update(render(true));
                default: return;
            }
            await i.update(render());
        } catch (e) {
            console.error('Logging wizard error:', e);
        }
    });
    collector.on('end', (_c, reason) => {
        if (reason !== 'done') msg.edit(render(true)).catch(() => {});
    });
}

// ------------------------------------------------------------------ command
module.exports = makeCommand({
    name: 'logging',
    description: 'Configure server logging',
    ...SETUP_PERMS,
    subs: {
        remove: {
            description: 'Remove a logging configuration',
            async run(ctx) {
                logs.save(ctx.guild.id, { enabled: false, channels: {}, ignores: [] });
                await ctx.success('✅ Logging configuration has been removed.');
            }
        },
        status: {
            description: 'Show logging status',
            async run(ctx) { await ctx.send({ embeds: [statusEmbed(ctx.guild)] }); }
        },
        wizard: {
            description: 'Start the logging setup wizard',
            async run(ctx) { await wizard(ctx); }
        },
        disable: {
            description: 'Disable logging module',
            async run(ctx) {
                const cfg = logs.get(ctx.guild.id);
                cfg.enabled = false;
                logs.save(ctx.guild.id, cfg);
                await ctx.success('✅ Logging module has been disabled.');
            }
        },
        enable: {
            description: 'Enable logging module',
            async run(ctx) {
                const cfg = logs.get(ctx.guild.id);
                cfg.enabled = true;
                logs.save(ctx.guild.id, cfg);
                const hasChannels = LOG_TYPES.some(t => cfg.channels[t]);
                await ctx.success('✅ Logging module has been enabled.' + (hasChannels ? '' : '\n⚠️ No log channels are set yet — use `logging setup auto` or `logging wizard`.'));
            }
        }
    },
    groups: {
        setup: {
            description: 'Setup logging channels',
            subs: {
                clear: {
                    description: 'Clear logging setup',
                    async run(ctx) {
                        const cfg = logs.get(ctx.guild.id);
                        cfg.channels = {};
                        logs.save(ctx.guild.id, cfg);
                        await ctx.success('✅ Cleared all logging channel configurations.');
                    }
                },
                channel: {
                    description: 'Set a channel for a log type',
                    options: [
                        { name: 'type', type: 'string', description: `Log type (${LOG_TYPES.join(', ')}, all)`, required: true, choices: [...LOG_TYPES, 'all'] },
                        { name: 'channel', type: 'channel', description: 'Target channel', required: true, channelTypes: TEXT_CHANNELS }
                    ],
                    async run(ctx, p) {
                        const type = requireType(p.type);
                        const channel = requireTextChannel(p.channel);
                        const me = channel.permissionsFor(ctx.guild.members.me);
                        if (!me || !me.has([P.ViewChannel, P.SendMessages, P.EmbedLinks])) {
                            throw new UserError(`I need **View Channel**, **Send Messages** and **Embed Links** in ${channel}.`);
                        }
                        const cfg = logs.get(ctx.guild.id);
                        for (const t of (type === 'all' ? LOG_TYPES : [type])) cfg.channels[t] = channel.id;
                        logs.save(ctx.guild.id, cfg);
                        await ctx.success(`✅ Set ${type === 'all' ? '**all** logs' : `**${type}** logs`} to ${channel}.` +
                            (cfg.enabled ? '' : '\nℹ️ Logging is currently disabled — run `logging enable` to start logging.'));
                    }
                },
                auto: {
                    description: 'Auto-setup all logging channels',
                    botPerms: [P.ManageChannels, P.ManageRoles],
                    async run(ctx) {
                        await ctx.defer();
                        const { created, reused } = await autoSetup(ctx.guild, ctx.member.id);
                        await ctx.success(`✅ Auto-setup completed! Created **${created}** locked logging channel(s)` +
                            (reused ? ` and kept **${reused}** existing one(s)` : '') + '. Logging is now enabled.');
                    }
                }
            }
        },
        ignore: {
            description: 'Manage logging ignore list',
            subs: {
                channel: {
                    description: 'Ignore a channel',
                    options: [{ name: 'channel', type: 'channel', description: 'The channel', required: true, channelTypes: TEXT_CHANNELS }],
                    async run(ctx, p) {
                        const ch = requireTextChannel(p.channel);
                        if (!addIgnore(ctx.guild.id, ch.id)) throw new UserError('This channel is already ignored.');
                        await ctx.success(`✅ Added ${ch} to the ignore list.`);
                    }
                },
                show: {
                    description: 'Show ignore list',
                    async run(ctx) {
                        const { ignores } = logs.get(ctx.guild.id);
                        if (!ignores.length) return ctx.info('No ignores configured.');
                        const lines = ignores.map(e => `${describeIgnore(ctx.guild, e)} — \`${e}\``);
                        await ctx.send({ embeds: [new EmbedBuilder().setTitle('🙈 Logging Ignore List').setColor('#2b2d31').setDescription(lines.join('\n').slice(0, 4096))] });
                    }
                },
                user: {
                    description: 'Ignore a user',
                    options: [{ name: 'user', type: 'user', description: 'The user', required: true }],
                    async run(ctx, p) {
                        if (!addIgnore(ctx.guild.id, p.user.user.id)) throw new UserError('This user is already ignored.');
                        await ctx.success(`✅ Added ${p.user.user} to the ignore list.`);
                    }
                },
                embed: {
                    description: 'Ignore embeds in a channel',
                    options: [{ name: 'channel', type: 'channel', description: 'The channel', required: true, channelTypes: TEXT_CHANNELS }],
                    async run(ctx, p) {
                        const ch = requireTextChannel(p.channel);
                        if (!addIgnore(ctx.guild.id, `embed_${ch.id}`)) throw new UserError('Embeds in this channel are already ignored.');
                        await ctx.success(`✅ Ignoring embeds in ${ch}.`);
                    }
                },
                role: {
                    description: 'Ignore a role',
                    options: [{ name: 'role', type: 'role', description: 'The role', required: true }],
                    async run(ctx, p) {
                        if (!addIgnore(ctx.guild.id, p.role.id)) throw new UserError('This role is already ignored.');
                        await ctx.success(`✅ Added ${p.role} to the ignore list.`);
                    }
                },
                voice: {
                    description: 'Ignore voice actions in a channel',
                    options: [{ name: 'channel', type: 'channel', description: 'The channel', required: true, channelTypes: VOICE_CHANNELS }],
                    async run(ctx, p) {
                        const ch = requireVoiceChannel(p.channel);
                        if (!addIgnore(ctx.guild.id, `voice_${ch.id}`)) throw new UserError('This voice channel is already ignored.');
                        await ctx.success(`✅ Added voice channel ${ch} to the ignore list.`);
                    }
                },
                remove: {
                    description: 'Remove an ignore rule',
                    options: [{ name: 'id', type: 'string', description: 'The ID (or mention) to remove', required: true }],
                    async run(ctx, p) {
                        const id = idFrom(p.id) || p.id.trim();
                        const cfg = logs.get(ctx.guild.id);
                        const targets = [id, `voice_${id}`, `embed_${id}`];
                        const before = cfg.ignores.length;
                        cfg.ignores = cfg.ignores.filter(e => !targets.includes(e));
                        if (cfg.ignores.length === before) throw new UserError(`\`${id}\` is not in the ignore list.`);
                        logs.save(ctx.guild.id, cfg);
                        await ctx.success(`✅ Removed \`${id}\` from the ignore list.`);
                    }
                }
            }
        }
    }
});
