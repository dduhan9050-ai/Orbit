const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const embedHelper = require('../../functions/embedHelper');

module.exports = [
    {
        data: new SlashCommandBuilder()
            .setName('messages')
            .setDescription('Check your or another user\'s message count')
            .addUserOption(opt => opt.setName('user').setDescription('The user to check')),
        async execute(interaction) {
            const user = interaction.options.getUser('user') || interaction.user;
            await interaction.reply(`${user.username} has 0 messages.`);
        },
        async executeMessage(message, args) {
            const target = message.mentions.users.first() || message.author;
            const fs = require('fs');
            const path = require('path');
            const dataPath = path.join(__dirname, '../../data/messages.json');
            
            let data = {};
            try {
                if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            } catch (e) { }
            
            const guildId = message.guild.id;
            if (!data[guildId]) data[guildId] = { users: {} };
            
            const userMessages = data[guildId].users[target.id]?.messages || 0;
            return message.reply(`💬 **${target.username}** has sent **${userMessages}** messages.`);
        }
    },
    {
        data: new SlashCommandBuilder()
            .setName('message')
            .setDescription('Manage message counting system')
            .addSubcommand(sub => sub.setName('rolereward').setDescription('Configure message role rewards').addIntegerOption(opt => opt.setName('messages').setDescription('Message count').setRequired(true)).addRoleOption(opt => opt.setName('role').setDescription('Role to reward').setRequired(true)))
            .addSubcommand(sub => sub.setName('config').setDescription('Show message count configuration'))
            .addSubcommand(sub => sub.setName('lbweekly').setDescription('Show weekly message leaderboard'))
            .addSubcommand(sub => sub.setName('blchannel').setDescription('Blacklist a channel from counting messages').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
            .addSubcommand(sub => sub.setName('lbdaily').setDescription('Show daily message leaderboard'))
            .addSubcommand(sub => sub.setName('add').setDescription('Add messages to a user').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)).addIntegerOption(opt => opt.setName('amount').setDescription('Amount of messages').setRequired(true)))
            .addSubcommand(sub => sub.setName('resetme').setDescription('Reset your own message count'))
            .addSubcommand(sub => sub.setName('rolereset').setDescription('Reset all message role rewards'))
            .addSubcommand(sub => sub.setName('remove').setDescription('Remove messages from a user').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)).addIntegerOption(opt => opt.setName('amount').setDescription('Amount of messages').setRequired(true)))
            .addSubcommand(sub => sub.setName('reset').setDescription('Reset message count for a user').addUserOption(opt => opt.setName('user').setDescription('The user').setRequired(true)))
            .addSubcommand(sub => sub.setName('unblchannel').setDescription('Unblacklist a channel from counting messages').addChannelOption(opt => opt.setName('channel').setDescription('The channel').setRequired(true)))
            .addSubcommand(sub => sub.setName('leaderboard').setDescription('Show overall message leaderboard')),
        async execute(interaction) {
            const sub = interaction.options.getSubcommand();
            const configCommands = ['rolereward', 'rolereset', 'blchannel', 'unblchannel', 'add', 'remove', 'reset'];
            if (configCommands.includes(sub) && !interaction.member.permissions.has('ManageGuild')) {
                return interaction.reply({ content: '❌ No access', flags: MessageFlags.Ephemeral });
            }
            await interaction.reply({ embeds: [new EmbedBuilder().setTitle('Message Counting').setDescription(`Executed message subcommand: **${sub}**`).setColor('#000000')] });
        },
        async executeMessage(message, args) {
            const subcommand = args[0] ? args[0].toLowerCase() : 'help';
            const embed = new EmbedBuilder()
                .setDescription(
                    `\`\`\`\n<..> <required> | [..] [optional]\n\`\`\`\n\n` +
                    `» **message config**\n› Show configuration.\n\n` +
                    `» **message leaderboard/lbdaily/lbweekly**\n› Show leaderboards.\n\n` +
                    `» **message rolereward <messages> @role**\n› Set role reward.\n\n` +
                    `» **message rolereset**\n› Reset role rewards.\n\n` +
                    `» **message blchannel/unblchannel #channel**\n› Manage blacklist.\n\n` +
                    `» **message add/remove/reset @user <amount>**\n› Manage messages.`
                )
                .setColor('#2b2d31')
                .setFooter({ text: `Page 1/1 | Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

            if (subcommand === 'help' || !['config', 'leaderboard', 'rolereward', 'rolereset', 'blchannel', 'unblchannel', 'add', 'remove', 'reset', 'resetme', 'lbweekly', 'lbdaily'].includes(subcommand)) {
                return message.reply({ embeds: [embed] });
            }

            const configCommands = ['rolereward', 'rolereset', 'blchannel', 'unblchannel', 'add', 'remove', 'reset'];
            if (configCommands.includes(subcommand) && !message.member.permissions.has('ManageGuild')) {
                return message.reply({ embeds: [embedHelper.error('❌ No access')] });
            }

            const fs = require('fs');
            const path = require('path');
            const dataPath = path.join(__dirname, '../../data/messages.json');
            
            let data = {};
            try {
                if (fs.existsSync(dataPath)) data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            } catch (e) { }
            
            const guildId = message.guild.id;
            if (!data[guildId]) data[guildId] = { users: {}, roleRewards: {}, blacklist: [] };

            if (subcommand === 'config') {
                const cfg = data[guildId];
                const configEmbed = new EmbedBuilder()
                    .setTitle('📊 Message Configuration')
                    .addFields(
                        { name: 'Role Rewards', value: `${Object.keys(cfg.roleRewards || {}).length}`, inline: true },
                        { name: 'Blacklisted Channels', value: `${(cfg.blacklist || []).length}`, inline: true }
                    )
                    .setColor('#5865F2');
                return message.reply({ embeds: [configEmbed] });
            }

            if (['leaderboard', 'lbdaily', 'lbweekly'].includes(subcommand)) {
                const users = data[guildId].users || {};
                const sorted = Object.entries(users).sort((a, b) => (b[1].messages || 0) - (a[1].messages || 0)).slice(0, 10);
                const leaderboard = sorted.map((entry, i) => `${i + 1}. <@${entry[0]}> - ${entry[1].messages || 0} messages`).join('\n') || 'No data yet';
                const lbEmbed = new EmbedBuilder()
                    .setTitle(`🏆 Message Leaderboard ${subcommand === 'lbdaily' ? '(Daily)' : subcommand === 'lbweekly' ? '(Weekly)' : ''}`)
                    .setDescription(leaderboard)
                    .setColor('#FFD700');
                return message.reply({ embeds: [lbEmbed] });
            }

            if (subcommand === 'resetme') {
                if (!data[guildId].users[message.author.id]) return message.reply({ embeds: [embedHelper.info('You have no messages to reset.')] });
                data[guildId].users[message.author.id].messages = 0;
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success('✅ Your message count has been reset.')] });
            }

            if (subcommand === 'rolereward') {
                const messageCount = parseInt(args[1]);
                const role = message.mentions.roles.first();
                if (!messageCount || !role) return message.reply({ embeds: [embedHelper.info('Usage: `!message rolereward <messages> @role`')] });
                if (!data[guildId].roleRewards) data[guildId].roleRewards = {};
                data[guildId].roleRewards[messageCount] = role.id;
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ ${role} will be rewarded at ${messageCount} messages.`)] });
            }

            if (subcommand === 'rolereset') {
                data[guildId].roleRewards = {};
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success('✅ All message role rewards have been reset.')] });
            }

            if (subcommand === 'blchannel') {
                const channel = message.mentions.channels.first();
                if (!channel) return message.reply({ embeds: [embedHelper.info('Usage: `!message blchannel #channel`')] });
                if (!data[guildId].blacklist) data[guildId].blacklist = [];
                if (data[guildId].blacklist.includes(channel.id)) return message.reply(`${channel} is already blacklisted.`);
                data[guildId].blacklist.push(channel.id);
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ ${channel} blacklisted from message counting.`)] });
            }

            if (subcommand === 'unblchannel') {
                const channel = message.mentions.channels.first();
                if (!channel) return message.reply({ embeds: [embedHelper.info('Usage: `!message unblchannel #channel`')] });
                if (!data[guildId].blacklist || !data[guildId].blacklist.includes(channel.id)) {
                    return message.reply(`${channel} is not blacklisted.`);
                }
                data[guildId].blacklist = data[guildId].blacklist.filter(c => c !== channel.id);
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ ${channel} removed from blacklist.`)] });
            }

            if (subcommand === 'add') {
                const target = message.mentions.users.first();
                const amount = parseInt(args[2]);
                if (!target || !amount) return message.reply({ embeds: [embedHelper.info('Usage: `!message add @user <amount>`')] });
                if (!data[guildId].users[target.id]) data[guildId].users[target.id] = { messages: 0 };
                data[guildId].users[target.id].messages += amount;
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ Added ${amount} messages to ${target}.`)] });
            }

            if (subcommand === 'remove') {
                const target = message.mentions.users.first();
                const amount = parseInt(args[2]);
                if (!target || !amount) return message.reply({ embeds: [embedHelper.info('Usage: `!message remove @user <amount>`')] });
                if (!data[guildId].users[target.id]) data[guildId].users[target.id] = { messages: 0 };
                data[guildId].users[target.id].messages = Math.max(0, data[guildId].users[target.id].messages - amount);
                fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                return message.reply({ embeds: [embedHelper.success(`✅ Removed ${amount} messages from ${target}.`)] });
            }

            if (subcommand === 'reset') {
                const target = message.mentions.users.first();
                if (!target) return message.reply({ embeds: [embedHelper.info('Usage: `!message reset @user`')] });
                if (data[guildId].users[target.id]) {
                    data[guildId].users[target.id].messages = 0;
                    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
                }
                return message.reply({ embeds: [embedHelper.success(`✅ Reset messages for ${target}.`)] });
            }

            return message.reply({ embeds: [embed] });
        }
    }
];
